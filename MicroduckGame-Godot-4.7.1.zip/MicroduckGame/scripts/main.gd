extends Node3D
## Composition root: state, 3D world, touch interactions, UI and arcade sessions.
## Persistent rules live in State; this script coordinates their presentation.
const Hud=preload("res://scripts/ui/HUD.gd")
const PanelScreens=preload("res://scripts/ui/Panels.gd")
const U=preload("res://scripts/ui/UITheme.gd")
const ROOM_SCENES={"living":"LivingRoom","kitchen":"Kitchen","bedroom":"Bedroom","bathroom":"Bathroom","games":"GameRoom","workshop":"Workshop","garden":"Garden"}
const GAME_SCENES={"catch":"CatchChips","roller":"RollerDuck","memory":"MemoryLights","sort":"BatterySort","beat":"DuckBeat","treasure":"DuckTreasure"}
const NEED_ROOMS={"hunger":"kitchen","happiness":"games","cleanliness":"bathroom","battery":"bedroom","rest":"bedroom"}
const NEED_LABELS={"hunger":"Food","happiness":"Joy","cleanliness":"Clean","battery":"Battery","rest":"Rest"}
const NEED_HELP={"hunger":"Choose a treat in the kitchen.","happiness":"A gentle stroke or a game brings joy.","cleanliness":"Use the sponge, rinse and dry.","battery":"Connect to the charging dock.","rest":"A little sleep restores your robot."}
const TUTORIAL_STEPS=["Tap your robot to say hello.","Stroke its head with your finger.","Open Food to visit the kitchen.","Choose a treat and feed your friend.","Open Sleep to visit the bedroom.","Tap Charge to try the charging dock.","Open Games to visit the playroom.","Choose a mini-game and finish a round."]

var pet:Node3D
var room:Node3D
var camera:Camera3D
var sun:DirectionalLight3D
var environment:Environment
var hud:Control
var panels:Control
var ui_root:Control
var fade:ColorRect
var arcade:Control
var session_token=""
var active_game=""
var room_id=""
var transition_busy=false
var test_mode=false
var action_lock=0.0
var rest_tween:Tween
var rest_target=Vector3.ZERO
var food:Node3D
var food_id=""
var food_dragging=false
var food_start=Vector3.ZERO
var pointer_down=false
var pointer_origin=Vector2.ZERO
var pointer_last=Vector2.ZERO
var stroke_distance=0.0
var pointer_part=""
var quick_taps:Array=[]
var washing=false
var wash_distance=0.0
var washed_parts:Dictionary={}
var sponge:Control
var tutorial_active=false
var tutorial_skip:Button
var last_night=false
var next_thought=20.0
var next_shake=0.0
var previous_accel=Vector3.ZERO
var intro_box:Node3D

func _ready()->void:
	test_mode="--test-mode" in OS.get_cmdline_user_args()
	if test_mode:
		State.autosave_enabled=false
		State.data=State.defaults()
		State.data.completed_tutorial=true
	L.set_language(State.data.settings.language)
	Audio.apply_settings(State.data.settings)
	_build_world()
	_build_ui()
	State.changed.connect(_state_changed)
	State.notice.connect(_notice)
	State.action.connect(_state_action)
	State.cosmetics_changed.connect(_cosmetics)
	L.language_changed.connect(_language_changed)
	_load_room(State.data.current_room)
	_cosmetics()
	_state_changed()
	_apply_quality()
	get_viewport().size_changed.connect(hud.update_safe_area)
	hud.update_safe_area()
	if not State.data.completed_tutorial and not test_mode:
		if int(State.data.tutorial_step)>0:
			_start_tutorial(false)
		else:
			_arrival()
	else:
		hud.toast(L.t("Welcome home, little friend!"))

func _build_world()->void:
	var world_env=WorldEnvironment.new()
	environment=Environment.new()
	environment.background_mode=Environment.BG_COLOR
	environment.background_color=Color("dce9df")
	environment.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color=Color("fff3df")
	environment.ambient_light_energy=0.24
	environment.tonemap_mode=Environment.TONE_MAPPER_LINEAR
	world_env.environment=environment
	add_child(world_env)
	sun=DirectionalLight3D.new()
	sun.name="WarmWindowLight"
	sun.rotation_degrees=Vector3(-38,-28,0)
	sun.light_color=Color("fff3d9")
	sun.light_energy=0.48
	sun.shadow_enabled=true
	sun.directional_shadow_max_distance=24
	sun.shadow_bias=0.06
	add_child(sun)
	var fill=OmniLight3D.new()
	fill.name="SoftFill"
	fill.position=Vector3(1.6,4,5)
	fill.light_color=Color("d9f6ff")
	fill.light_energy=0.13
	fill.omni_range=10
	add_child(fill)
	pet=load("res://scenes/pet/Microduck.tscn").instantiate()
	pet.name="Microduck"
	add_child(pet)
	if pet.has_signal("sound_requested"):pet.sound_requested.connect(Audio.play)
	if pet.has_signal("thought_requested"):pet.thought_requested.connect(_notice)
	camera=Camera3D.new()
	camera.name="PortraitCamera"
	camera.projection=Camera3D.PROJECTION_ORTHOGONAL
	camera.keep_aspect=Camera3D.KEEP_HEIGHT
	camera.size=7.0
	camera.position=Vector3(0,4.5,10)
	add_child(camera)
	camera.look_at(Vector3(0,1.7,0))
	camera.current=true

func _build_ui()->void:
	var layer=CanvasLayer.new()
	add_child(layer)
	ui_root=Control.new()
	ui_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.mouse_filter=Control.MOUSE_FILTER_IGNORE
	ui_root.theme=U.theme()
	layer.add_child(ui_root)
	hud=Hud.new()
	ui_root.add_child(hud)
	hud.room_requested.connect(change_room)
	hud.panel_requested.connect(open_panel)
	hud.action_requested.connect(_context_action)
	hud.need_requested.connect(_need_tapped)
	panels=PanelScreens.new()
	ui_root.add_child(panels)
	panels.requested.connect(_panel_request)
	panels.closed.connect(func():Audio.set_room(room_id))
	fade=ColorRect.new()
	fade.color=Color("fffaf1")
	fade.modulate.a=0
	fade.mouse_filter=Control.MOUSE_FILTER_IGNORE
	fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.add_child(fade)
	var sponge_label=U.label("◉",54,U.GOLD)
	sponge_label.add_theme_stylebox_override("normal",U.style(U.GOLD,18))
	sponge_label.mouse_filter=Control.MOUSE_FILTER_IGNORE
	sponge=sponge_label
	sponge.visible=false
	ui_root.add_child(sponge)
	tutorial_skip=U.button(L.t("Skip"),func():_end_tutorial(),U.CREAM)
	tutorial_skip.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	tutorial_skip.offset_left=-155
	tutorial_skip.offset_right=-25
	tutorial_skip.offset_top=454
	tutorial_skip.offset_bottom=510
	tutorial_skip.visible=false
	ui_root.add_child(tutorial_skip)

func _load_room(id:String)->void:
	_clear_food()
	washing=false
	sponge.visible=false
	if is_instance_valid(room):
		remove_child(room)
		room.queue_free()
	room=load("res://scenes/rooms/%s.tscn" % ROOM_SCENES.get(id,"LivingRoom")).instantiate()
	add_child(room)
	move_child(room,0)
	room_id=id
	if rest_tween and rest_tween.is_valid():rest_tween.kill()
	pet.position=Vector3.ZERO
	pet.rotation.y=0
	rest_target=Vector3.ZERO
	room.decorate(State.data.furniture_choices.get(room_id,{}))
	last_night=not _is_night()
	_update_lighting()
	Audio.set_room(id)
	hud.refresh()
	_state_changed()

func change_room(id:String)->void:
	if not ROOM_SCENES.has(id) or is_instance_valid(arcade) or transition_busy:return
	if id==room_id:
		_advance_tutorial("room_"+id)
		return
	transition_busy=true
	panels.hide_panel()
	Audio.play("ui")
	fade.mouse_filter=Control.MOUSE_FILTER_STOP
	var tween=create_tween()
	tween.tween_property(fade,"modulate:a",1.0,0.14)
	tween.tween_callback(func():
		State.visit_room(id)
		_load_room(id)
		_advance_tutorial("room_"+id)
	)
	tween.tween_property(fade,"modulate:a",0.0,0.22)
	tween.tween_callback(func():
		transition_busy=false
		fade.mouse_filter=Control.MOUSE_FILTER_IGNORE
	)

func _state_changed()->void:
	if not is_instance_valid(pet) or not is_instance_valid(hud):return
	hud.refresh()
	pet.set_needs(State.data.needs)
	pet.set_sleeping(State.data.is_sleeping)
	pet.set_charging(State.data.is_charging)
	pet.set_growth(1.0+minf(float(State.data.level-1)*0.002,0.07))
	_update_lighting()
	if is_instance_valid(room):
		var target=Vector3.ZERO
		if State.data.is_sleeping:target=room.get_anchor("sleep")
		elif State.data.is_charging:target=room.get_anchor("charge")
		if not target.is_equal_approx(rest_target):
			rest_target=target
			if rest_tween and rest_tween.is_valid():rest_tween.kill()
			rest_tween=create_tween()
			rest_tween.tween_property(pet,"position",target,1.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
			if not State.data.is_sleeping:pet.play("walk")

func _cosmetics()->void:
	if pet.has_method("clear_part_colors"):pet.clear_part_colors()
	pet.set_skin(State.data.equipped_skin)
	pet.set_accessory(State.data.equipped_accessory)
	if pet.has_method("set_part_color"):
		for part in State.data.get("part_colors",{}):pet.set_part_color(part,Color(State.data.part_colors[part]))
	if is_instance_valid(room):room.decorate(State.data.furniture_choices.get(room_id,{}))

func _is_night()->bool:
	var hour=int(Time.get_time_dict_from_system().hour)
	return State.data.is_sleeping or hour<7 or hour>=20

func _update_lighting()->void:
	if not is_instance_valid(room):return
	var night=_is_night()
	if night==last_night:return
	last_night=night
	room.set_night(night)
	var tween=create_tween().set_parallel(true)
	tween.tween_property(sun,"light_energy",0.20 if night else 0.48,0.8)
	tween.tween_property(environment,"ambient_light_energy",0.20 if night else 0.24,0.8)

func _apply_quality()->void:
	var high=State.data.settings.quality=="high"
	sun.shadow_enabled=high
	get_viewport().msaa_3d=Viewport.MSAA_2X if high else Viewport.MSAA_DISABLED
	Engine.max_fps=60 if high else 30

func _language_changed()->void:
	if is_instance_valid(hud):
		hud.refresh_room()
		hud.refresh()
		_update_tutorial()
	if is_instance_valid(tutorial_skip):tutorial_skip.text=L.t("Skip")

func open_panel(id:String)->void:
	if is_instance_valid(arcade) or transition_busy:return
	Audio.play("ui")
	panels.show_screen(id)
	if id in ["shop","wardrobe","decor"]:Audio.set_room("shop")

func _panel_request(kind:String,payload:Variant)->void:
	match kind:
		"select_food":_select_food(str(payload))
		"toy":_do_care(str(payload))
		"minigame":launch_minigame(str(payload))
		"room":change_room(str(payload))
		"quality":_apply_quality()
		"tutorial":_start_tutorial(true)
		"message":hud.toast(str(payload))
		"reset":
			L.set_language(State.data.settings.language)
			Audio.apply_settings(State.data.settings)
			_load_room("living")
			_cosmetics()
			_arrival()

func _context_action(id:String)->void:
	Audio.play("ui")
	if id in ROOM_SCENES:change_room(id)
	elif id in ["food","shop_food","minigames","toys","wardrobe","decor"]:open_panel(id)
	elif id=="treasure":launch_minigame("treasure")
	elif id=="roll":
		if action_lock<=0 and not State.data.is_sleeping:
			pet.play("roll")
			Audio.play("wheels")
			action_lock=2.3
	elif id=="wash":_start_washing()
	else:_do_care(id)

func _do_care(kind:String)->bool:
	if is_instance_valid(arcade) or transition_busy:return false
	if action_lock>0 and kind not in ["wake","stop_charge","charge","sleep"]:return false
	return State.care(kind)

func _state_action(kind:String)->void:
	if not is_instance_valid(pet):return
	pet.play("celebrate" if kind=="level_up" else kind)
	Audio.play(kind)
	if kind in ["feed","wash","rinse","dry","filter","ball","duck","cube","music"]:action_lock=2.4
	if kind in ["sleep","charge","wake","stop_charge"]:action_lock=0.5
	if kind in ["pet","level_up","win"]:_burst("♥" if kind=="pet" else "✦",U.ORANGE)
	if kind in ["ball","duck","cube","music"]:_toy_visual(kind)
	if kind=="filter":_filter_visual()
	if kind=="charge":_charge_visual()
	_advance_tutorial(kind)

func _notice(text:String)->void:
	if is_instance_valid(hud):hud.toast(L.t(text))

func _need_tapped(id:String)->void:
	change_room(NEED_ROOMS[id])
	hud.toast("%s · %d/100\n%s" % [L.t(NEED_LABELS[id]),roundi(State.data.needs[id]),L.t(NEED_HELP[id])])

func _select_food(id:String)->void:
	if room_id!="kitchen":
		hud.toast(L.t("Let's eat in the kitchen."))
		change_room("kitchen")
		return
	_clear_food()
	food_id=id
	food=Node3D.new()
	food.name="TreatOnTray"
	add_child(food)
	food.position=Vector3(0,0.42,1.45)
	food_start=food.position
	var plate=CylinderMesh.new()
	plate.top_radius=0.43
	plate.bottom_radius=0.38
	plate.height=0.06
	_mesh(food,plate,Vector3.ZERO,Color("fcf5e7"))
	var treat=SphereMesh.new()
	treat.radius=0.22
	treat.height=0.24
	treat.radial_segments=20
	treat.rings=10
	_mesh(food,treat,Vector3(0,0.16,0),U.GOLD if id in ["chip","basic","cookie"] else U.ORANGE)
	for i in range(5):
		var dot=SphereMesh.new()
		dot.radius=0.026
		dot.height=0.052
		dot.radial_segments=8
		dot.rings=4
		_mesh(food,dot,Vector3(sin(i*2.4)*0.12,0.27,cos(i*2.4)*0.12),Color("7e5d43"))
	var area=Area3D.new()
	area.collision_layer=4
	area.collision_mask=0
	area.set_meta("interaction","food_pickup")
	var collider=CollisionShape3D.new()
	var shape=SphereShape3D.new()
	shape.radius=0.48
	collider.shape=shape
	area.add_child(collider)
	food.add_child(area)
	hud.toast(L.t("Drag the treat to the beak, or tap it."))

func _feed_selected()->void:
	if not is_instance_valid(food) or food_id.is_empty():return
	if not State.feed(food_id):
		pet.play("tilt")
		food.position=food_start
		return
	var eaten=food
	food=null
	food_id=""
	food_dragging=false
	var tween=create_tween()
	tween.tween_property(eaten,"global_position",pet.get_mouth_position(),0.55).set_trans(Tween.TRANS_QUAD)
	tween.parallel().tween_property(eaten,"scale",Vector3.ONE*0.35,0.55)
	tween.tween_callback(eaten.queue_free)
	_burst("✦",U.GOLD)

func _clear_food()->void:
	if is_instance_valid(food):food.queue_free()
	food=null
	food_id=""
	food_dragging=false

func _start_washing()->void:
	if room_id!="bathroom" or action_lock>0:return
	if State.wash_stage!=0:
		hud.toast(L.t("Rinse the bubbles, then dry the shell."))
		return
	washing=true
	wash_distance=0
	washed_parts.clear()
	hud.toast(L.t("Move the sponge across the head, body and feet."))
	hud.actions_title.text=L.t("Scrub gently")+" · 0%"

func _scrub(position_2d:Vector2,distance:float,part:String)->void:
	if not washing or part.is_empty():return
	sponge.visible=true
	sponge.position=position_2d-Vector2(28,28)
	wash_distance+=minf(distance,50)
	washed_parts[part]=true
	pet.play("wash")
	hud.actions_title.text=L.t("Scrub gently")+" · %d%%" % mini(100,int(wash_distance/7))
	if wash_distance>=700 and washed_parts.size()>=2:
		if State.care("wash"):
			washing=false
			sponge.visible=false
			hud.toast(L.t("All soapy! Rinse, then dry your friend."))
			hud.refresh_room()

func _ray(position_2d:Vector2)->Dictionary:
	var origin=camera.project_ray_origin(position_2d)
	var query=PhysicsRayQueryParameters3D.create(origin,origin+camera.project_ray_normal(position_2d)*40,7)
	query.collide_with_areas=true
	query.collide_with_bodies=false
	return get_world_3d().direct_space_state.intersect_ray(query)

func _unhandled_input(event:InputEvent)->void:
	if event.is_action_pressed("ui_cancel"):
		if is_instance_valid(arcade):arcade.abort()
		elif panels.visible:panels.hide_panel()
		else:open_panel("settings")
		get_viewport().set_input_as_handled()
		return
	if panels.visible or is_instance_valid(arcade) or transition_busy:return
	if event is InputEventKey and event.pressed and not event.echo and event.keycode==KEY_S:
		_do_care("shake")
	if event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT:
		if event.pressed:_pointer_press(event.position)
		else:_pointer_release(event.position)
	elif event is InputEventMouseMotion and pointer_down:
		_pointer_move(event.position)

func _input(event:InputEvent)->void:
	# Complete a world drag even if the finger crosses a UI control before release.
	if not pointer_down or panels.visible or is_instance_valid(arcade):return
	if event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT and not event.pressed:
		_pointer_release(event.position)
	elif event is InputEventMouseMotion and (food_dragging or washing):
		_pointer_move(event.position)
		get_viewport().set_input_as_handled()

func _pointer_press(pos:Vector2)->void:
	pointer_down=true
	pointer_origin=pos
	pointer_last=pos
	stroke_distance=0
	pointer_part=""
	var hit=_ray(pos)
	if hit.is_empty():return
	var collider=hit.collider
	pointer_part=str(collider.get_meta("part",""))
	var interaction=str(collider.get_meta("interaction",""))
	food_dragging=interaction=="food_pickup"
	if pointer_part.is_empty() and not food_dragging and not interaction.is_empty():
		match interaction:
			"lamp":
				last_night=not last_night
				room.set_night(last_night)
				Audio.play("ui")
			"food":open_panel("food")
			"games":open_panel("minigames")
			"wardrobe":open_panel("wardrobe")
			"stats":open_panel("collection")
			"wash":_start_washing()
			"trick":_context_action("roll")
			_:_do_care(interaction)

func _pointer_move(pos:Vector2)->void:
	var distance=pos.distance_to(pointer_last)
	pointer_last=pos
	stroke_distance+=distance
	if food_dragging and is_instance_valid(food):
		food.global_position=camera.project_position(pos,8.6)
		return
	var hit=_ray(pos)
	if hit.is_empty():return
	var part=str(hit.collider.get_meta("part",""))
	if washing:
		_scrub(pos,distance,part)
	elif part=="head" and stroke_distance>90:
		if _do_care("pet"):stroke_distance=0

func _pointer_release(pos:Vector2)->void:
	if not pointer_down:return
	pointer_down=false
	sponge.visible=false
	if food_dragging and is_instance_valid(food):
		food_dragging=false
		var mouth=camera.unproject_position(pet.get_mouth_position())
		if pos.distance_to(mouth)<130 or pos.distance_to(pointer_origin)<35:_feed_selected()
		else:
			create_tween().tween_property(food,"position",food_start,0.3)
		return
	if washing:return
	if not pointer_part.is_empty() and pos.distance_to(pointer_origin)<32:
		var now=Time.get_ticks_msec()
		quick_taps.append(now)
		while quick_taps.size()>0 and now-int(quick_taps[0])>1800:quick_taps.pop_front()
		_do_care("poke" if quick_taps.size()>=4 else pointer_part)

func launch_minigame(id:String)->void:
	if not GAME_SCENES.has(id) or is_instance_valid(arcade) or transition_busy:return
	var token=State.begin_minigame(id)
	if token.is_empty():return
	session_token=token
	active_game=id
	washing=false
	_clear_food()
	panels.hide_panel()
	hud.visible=false
	tutorial_skip.visible=false
	arcade=load("res://scenes/minigames/%s.tscn" % GAME_SCENES[id]).instantiate()
	ui_root.add_child(arcade)
	arcade.finished.connect(_finish_minigame)
	Audio.set_room("minigame")

func _finish_minigame(score:int,won:bool,aborted:bool)->void:
	var id=active_game
	var token=session_token
	session_token=""
	active_game=""
	if is_instance_valid(arcade):
		ui_root.remove_child(arcade)
		arcade.queue_free()
	arcade=null
	hud.visible=true
	var rewards=State.finish_minigame(token,score,won,aborted)
	Audio.set_room(room_id)
	_update_tutorial()
	if aborted:
		panels.show_screen("minigames")
		return
	_advance_tutorial("game_finished")
	pet.play("win" if won else "lose")
	Audio.play("win" if won else "lose")
	panels.show_results(id,score,won,rewards)

func _start_tutorial(restart:bool=true)->void:
	tutorial_active=true
	if restart:
		State.data.tutorial_step=0
		State.data.completed_tutorial=false
		State.save()
	_update_tutorial()

func _advance_tutorial(event:String)->void:
	if not tutorial_active:return
	var step=int(State.data.tutorial_step)
	var accepted=["head","beak","body","feet","poke"] if step==0 else ["pet"]
	if step==2:accepted=["room_kitchen"]
	if step==3:accepted=["feed"]
	if step==4:accepted=["room_bedroom"]
	if step==5:accepted=["charge"]
	if step==6:accepted=["room_games"]
	if step==7:accepted=["game_finished"]
	if not event in accepted:return
	State.data.tutorial_step=step+1
	State.save()
	if step+1>=TUTORIAL_STEPS.size():_end_tutorial()
	else:_update_tutorial()

func _update_tutorial()->void:
	if not is_instance_valid(hud):return
	tutorial_skip.visible=tutorial_active and not is_instance_valid(arcade)
	if tutorial_active:
		var step=clampi(int(State.data.tutorial_step),0,TUTORIAL_STEPS.size()-1)
		hud.tutorial("%d / 8 · %s" % [step+1,L.t(TUTORIAL_STEPS[step])])
	else:hud.tutorial("")

func _end_tutorial()->void:
	tutorial_active=false
	State.complete_tutorial()
	_update_tutorial()

func _arrival()->void:
	pet.visible=false
	intro_box=Node3D.new()
	add_child(intro_box)
	var box=BoxMesh.new()
	box.size=Vector3(1.7,1.5,1.25)
	_mesh(intro_box,box,Vector3(0,0.75,0),Color("dcb587"))
	var band=BoxMesh.new()
	band.size=Vector3(0.16,1.52,1.27)
	_mesh(intro_box,band,Vector3(0,0.75,0),U.ORANGE)
	var logo=Label3D.new()
	logo.text="MICRODUCK\n♡"
	logo.font_size=64
	logo.pixel_size=0.005
	logo.modulate=U.INK
	logo.position=Vector3(0,0.9,0.64)
	intro_box.add_child(logo)
	transition_busy=true
	var tween=create_tween()
	for angle in [0.04,-0.04,0.035,-0.025,0.0]:tween.tween_property(intro_box,"rotation:z",angle,0.12)
	tween.tween_interval(0.15)
	tween.tween_property(intro_box,"scale",Vector3(1.2,0.04,1.2),0.28)
	tween.tween_callback(func():
		intro_box.queue_free()
		pet.visible=true
		pet.play("surprised")
		Audio.play("happy")
	)
	tween.tween_interval(0.85)
	tween.tween_callback(func():
		transition_busy=false
		panels.show_screen("welcome")
	)

func _mesh(parent:Node3D,mesh:Mesh,pos:Vector3,color:Color)->MeshInstance3D:
	var instance=MeshInstance3D.new()
	instance.mesh=mesh
	instance.position=pos
	var material=StandardMaterial3D.new()
	material.albedo_color=color
	material.roughness=0.5
	instance.material_override=material
	parent.add_child(instance)
	return instance

func _toy_visual(kind:String)->void:
	var toy=Node3D.new()
	add_child(toy)
	toy.position=Vector3(-0.8,0.3,1.0)
	if kind=="cube":
		var cube=BoxMesh.new()
		cube.size=Vector3.ONE*0.42
		_mesh(toy,cube,Vector3.ZERO,U.LAVENDER)
	else:
		var sphere=SphereMesh.new()
		sphere.radius=0.25
		sphere.height=0.5
		_mesh(toy,sphere,Vector3.ZERO,U.GOLD if kind=="duck" else U.AQUA)
		if kind=="duck":
			var head=SphereMesh.new()
			head.radius=0.14
			head.height=0.28
			_mesh(toy,head,Vector3(0,0.28,0.12),U.GOLD)
	var tween=create_tween()
	tween.tween_property(toy,"position",Vector3(0.75,0.45,1.0),0.8).set_trans(Tween.TRANS_SINE)
	tween.tween_property(toy,"position",Vector3(-0.45,0.25,1.0),0.8).set_trans(Tween.TRANS_BOUNCE)
	tween.tween_interval(0.7)
	tween.tween_property(toy,"scale",Vector3.ZERO,0.25)
	tween.tween_callback(toy.queue_free)
	if kind=="music":_burst("♪",U.LAVENDER)

func _filter_visual()->void:
	if not is_instance_valid(room):return
	room.play_interaction("filter")
	var tween=create_tween()
	tween.tween_property(pet,"position",room.get_anchor("filter"),0.65)
	tween.tween_interval(1.7)
	tween.tween_property(pet,"position",Vector3.ZERO,0.65)

func _charge_visual()->void:
	_burst("ϟ",U.GOLD)
	# The robot's contact glow is animated by PetController; the station remains 3D.

func _burst(symbol:String,color:Color)->void:
	if not is_instance_valid(ui_root):return
	var origin=camera.unproject_position(pet.global_position+Vector3(0,2.7,0))
	for i in range(6):
		var label=U.label(symbol,26+i%3*6,color)
		label.position=origin+Vector2(randf_range(-60,60),randf_range(-20,20))
		ui_root.add_child(label)
		var tween=create_tween().set_parallel(true)
		tween.tween_property(label,"position",label.position+Vector2(randf_range(-50,50),-100-randf()*70),1.2)
		tween.tween_property(label,"modulate:a",0.0,1.2)
		tween.chain().tween_callback(label.queue_free)

func _process(delta:float)->void:
	action_lock=maxf(0,action_lock-delta)
	next_shake=maxf(0,next_shake-delta)
	if OS.has_feature("mobile"):
		var accel=Input.get_accelerometer()
		if previous_accel!=Vector3.ZERO and accel.distance_to(previous_accel)>15 and next_shake<=0:
			next_shake=5
			_do_care("shake")
		previous_accel=accel
	if not is_instance_valid(hud) or panels.visible or is_instance_valid(arcade) or transition_busy:return
	next_thought-=delta
	if next_thought<=0:
		next_thought=randf_range(35,55)
		if State.data.is_sleeping:return
		var low=""
		for key in State.data.needs:
			if float(State.data.needs[key])<25:low=key;break
		if not low.is_empty():
			hud.toast(L.t(NEED_HELP[low]))
		else:
			hud.toast(L.t(["Nice to see you!","A little playtime?","My favorite place is here with you.","Tiny wheels. Big dreams."][randi()%4]))
			pet.play("chirp")
