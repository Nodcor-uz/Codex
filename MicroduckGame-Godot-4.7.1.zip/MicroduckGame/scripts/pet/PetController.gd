extends Node3D
## Articulated mechanical pet. Every animation is a blended joint pose;
## geometry and materials are allocated once by PetModel.
signal action_finished(kind: String)
signal thought_requested(source: String)
signal sound_requested(sound: String)

const Model = preload("res://scripts/pet/PetModel.gd")
const SKINS = {
	"classic":["f6f0e7","ff782b","ffc34e","96e4e6"],
	"lavender":["c5b3e7","ffcf45","ffe795","a9e9ed"],
	"sky":["97dce5","ff783b","ffc54d","b2f4ef"],
	"graphite":["4c505a","ffd24c","d2b8ef","be9df0"],
	"mint":["b4e6cd","f2d9a7","f6e9d3","acedef"],
	"golden":["f8ead0","d9aa43","ffe196","fef1a6"],
	"neon":["363e4d","61d9cc","9ce8d8","56f0db"],
	"candy":["efb9ce","f4dbb0","fff0da","d7c4f5"]}
const DURATIONS = {
	"head":1.25,"pet":2.2,"beak":1.1,"body":1.5,"feet":1.7,
	"poke":1.4,"shake":2.4,"feed":2.6,"eat":2.6,"chew":1.7,
	"wash":2.6,"rinse":2.2,"dry":2.3,"filter":2.0,
	"ball":3.0,"duck":2.2,"cube":2.5,"music":3.3,"dance":3.3,
	"sleep":1.5,"wake":2.0,"charge":1.5,"stop_charge":1.2,
	"win":3.0,"celebrate":3.0,"lose":2.1,"sad":2.1,
	"walk":2.8,"roll":2.2,"roll_forward":2.2,"roll_backward":2.2,
	"turn":2.6,"jump":1.2,"inspect":2.3,"pick_up":2.4,
	"look_left":2.0,"look_right":2.0,"tilt":1.8,"blink":.45,
	"chirp":1.1,"step":1.5,"wobble":2.0,"hungry":2.2,
	"sleepy":2.6,"surprised":1.4,"recover":2.0}

var rig: Dictionary = {}
var model = Model.new()
var needs: Dictionary = {"hunger":85.0,"happiness":85.0,"cleanliness":100.0,"battery":85.0,"rest":85.0}
var active_action = ""
var action_time = 0.0
var action_duration = 1.0
var elapsed = 0.0
var idle_remaining = 3.0
var thought_remaining = 18.0
var is_sleeping = false
var is_charging = false
var skin = "classic"
var accessory = "none"
var part_colors: Dictionary = {}
var growth = 1.0
var eye_color = Color("96e4e6")
var emotion = "Idle"
var recent_actions: Array[String] = []
var wheel_angle = 0.0
var rng = RandomNumberGenerator.new()

func _ready() -> void:
	rng.randomize()
	rig = model.build(self)
	set_skin(skin)
	set_accessory(accessory)
	set_needs(needs)
	set_growth(growth)

func play(kind: String) -> void:
	var key = kind.to_lower()
	var aliases = {"happy":"dance","affectionate":"pet","eating":"eat","bath":"wash","bathing":"wash","celebrating":"celebrate","victory":"win","failure":"lose","startled":"poke","lowbattery":"sleepy","sleeping":"sleep","charging":"charge","recoveringbalance":"recover","turn_around":"turn","lose_balance":"shake","gentle_touch":"pet"}
	key = aliases.get(key,key)
	if is_sleeping and key not in ["wake","sleep"]:
		return
	if is_charging and key in ["ball","cube","music","walk","roll","roll_forward","roll_backward","jump","dance"]:
		return
	active_action = key
	action_time = 0.0
	action_duration = float(DURATIONS.get(key,1.8))
	idle_remaining = rng.randf_range(4.0,8.0)
	recent_actions.append(key)
	if recent_actions.size()>8:
		recent_actions.pop_front()
	if key in ["head","beak","body","feet","inspect","chirp"]:
		sound_requested.emit("beep")
	elif key in ["pet","dance","win","celebrate","ball","duck"]:
		sound_requested.emit("happy")

func set_skin(id: String) -> void:
	skin = id if SKINS.has(id) else "classic"
	if rig.is_empty():
		return
	var colors: Array = SKINS[skin]
	var mats: Dictionary = rig.materials
	mats.shell.albedo_color = Color(colors[0])
	mats.shell.metallic = .42 if skin == "golden" else .08
	mats.accent.albedo_color = Color(colors[1])
	mats.beak_color.albedo_color = Color(colors[1])
	mats.roller_color.albedo_color = Color(colors[1])
	mats.lens_color.albedo_color = Color(colors[1])
	mats.accent.metallic = .55 if skin == "golden" else .16
	mats.sole.albedo_color = Color(colors[2])
	eye_color = Color(colors[3])
	mats.glow.albedo_color = eye_color
	mats.glow.emission = eye_color
	for part in part_colors:
		set_part_color(part,part_colors[part])

func set_part_color(part: String, color: Color) -> void:
	var keys = {"lens":"lens_color","beak":"beak_color","rollers":"roller_color"}
	if not keys.has(part):
		return
	part_colors[part] = color
	if not rig.is_empty():
		rig.materials[keys[part]].albedo_color = color

func clear_part_colors() -> void:
	part_colors.clear()
	set_skin(skin)

func set_accessory(id: String) -> void:
	accessory = id
	if rig.is_empty():
		return
	for key in rig.accessories:
		rig.accessories[key].visible = key == id

func set_needs(values: Dictionary) -> void:
	for key in needs:
		if values.has(key):
			needs[key] = clampf(float(values[key]),0.0,100.0)
	if rig.is_empty():
		return
	var count = int(ceil((100.0-float(needs.cleanliness))/100.0*rig.dirt.size()))
	for i in range(rig.dirt.size()):
		rig.dirt[i].visible = i<count and needs.cleanliness<85

func set_sleeping(value: bool) -> void:
	if is_sleeping != value:
		is_sleeping = value
		play("sleep" if value else "wake")

func set_charging(value: bool) -> void:
	if is_charging != value:
		is_charging = value
		if not is_sleeping:
			play("charge" if value else "stop_charge")

func set_growth(value: float) -> void:
	growth = clampf(value,.85,1.10)
	scale = Vector3.ONE*growth

func get_mouth_position() -> Vector3:
	if rig.is_empty():
		return global_position+Vector3(0,2.4,.7)
	return rig.beak.to_global(Vector3(0,-.02,.64))

func _process(delta: float) -> void:
	if rig.is_empty():
		return
	elapsed += delta
	var p = _neutral_pose()
	var speed = .5 if needs.battery < 15 else 1.0
	var t = elapsed*speed
	p.body_rot.z = sin(t*1.5)*.014
	p.body_offset.y = sin(t*2.0)*.008
	p.head_rot.z = sin(t*.79)*.018
	p.head_rot.y = sin(t*.45)*.035
	p.neck = sin(t*1.9)*.025
	p.shutter = 1.0
	if is_sleeping:
		emotion = "Sleeping"
		p.body_offset.y = -.20+sin(elapsed*1.6)*.006
		p.neck = .24
		p.head_rot = Vector3(.51,0,.04)
		p.legs = Vector2(-.30,-.30)
		p.knees = Vector2(.58,.58)
		p.shutter = .04
		p.beak = .025
	elif is_charging:
		emotion = "Charging"
		p.head_rot.x = .06
		p.head_rot.z = sin(t)*.035
	else:
		_update_idle(delta)
		if needs.rest < 20:
			emotion = "Sleepy"
			p.neck = .10
			p.head_rot.x = .22
			p.shutter = .65
		elif needs.battery < 15:
			emotion = "LowBattery"
			p.head_rot.x = .18
			p.neck = .07
		elif needs.hunger < 25:
			emotion = "Hungry"
		elif needs.cleanliness < 25:
			emotion = "Dirty"
		elif needs.happiness < 25:
			emotion = "Bored"
			p.head_rot.x = .12
		else:
			emotion = "Idle"
	if not active_action.is_empty():
		action_time += delta
		_apply_action(p,active_action,clampf(action_time/action_duration,0.0,1.0))
		if action_time >= action_duration:
			var old = active_action
			active_action = ""
			action_finished.emit(old)
	_apply_pose(p,delta)
	_update_effects(delta)

func _neutral_pose() -> Dictionary:
	return {"body_offset":Vector3.ZERO,"body_rot":Vector3.ZERO,"head_rot":Vector3.ZERO,"neck":0.0,"beak":0.0,"legs":Vector2.ZERO,"knees":Vector2.ZERO,"feet":Vector2.ZERO,"shutter":1.0,"wheel":0.0}

func _update_idle(delta: float) -> void:
	idle_remaining -= delta
	thought_remaining -= delta
	if idle_remaining<=0.0 and active_action.is_empty():
		var options = ["look_left","look_right","wobble","inspect","blink","chirp","step","beak","tilt"]
		if needs.rest < 25:
			play("sleepy")
		elif needs.hunger < 25:
			play("hungry")
		elif needs.happiness>90 and rng.randf()<.12:
			play("dance")
		else:
			play(options[rng.randi_range(0,options.size()-1)])
	if thought_remaining<=0:
		thought_remaining = rng.randf_range(28.0,46.0)
		if needs.battery<20:
			thought_requested.emit("My battery is running low!")
		elif needs.hunger<25:
			thought_requested.emit("A little snack?")
		elif needs.rest<25:
			thought_requested.emit("Time for a little rest.")
		elif needs.happiness<40:
			thought_requested.emit("Shall we play?")
		elif needs.cleanliness<30:
			thought_requested.emit("Bubble bath, please!")
		else:
			var thoughts = ["Quack!","Ready to roll!","You are my best friend!","It is cozy here."]
			thought_requested.emit(thoughts[rng.randi_range(0,thoughts.size()-1)])

func _apply_action(p: Dictionary, key: String, u: float) -> void:
	# Smooth envelope guarantees every short pose returns to its neutral state.
	var e = sin(u*PI)
	var fast = sin(u*TAU*3.0)
	match key:
		"head","tilt","pet":
			emotion = "Affectionate" if key=="pet" else "Curious"
			p.head_rot.z += e*.22
			p.head_rot.x -= e*.10
			p.neck -= e*.05
			p.shutter = 1.0-e*.20
			p.beak = e*.045
		"beak","chirp":
			p.beak = maxf(0.0,sin(u*TAU*2.0))*.24*e
			p.head_rot.x -= e*.06
		"body","wobble","recover":
			emotion = "RecoveringBalance"
			p.body_rot.z = fast*e*.12
			p.head_rot.z = -fast*e*.12
			p.legs = Vector2(-fast,fast)*e*.08
		"feet","step":
			p.legs = Vector2(sin(u*TAU),-sin(u*TAU))*e*.25
			p.knees = Vector2(maxf(sin(u*TAU),0.0),maxf(-sin(u*TAU),0.0))*.22
			p.body_offset.x = sin(u*TAU)*e*.07
			p.wheel = e*4.0
		"poke","surprised":
			emotion = "Surprised"
			p.body_offset.z = -e*.12
			p.head_rot.x = -e*.18
			p.neck = -e*.09
			p.beak = e*.25
			p.body_rot.z = sin(u*TAU*2)*e*.10
		"shake":
			emotion = "RecoveringBalance"
			p.body_rot.z = sin(u*TAU*2.0)*e*.30
			p.body_offset.x = sin(u*TAU)*e*.15
			p.body_offset.y = -e*.12
			p.head_rot.z = -p.body_rot.z*.8
			p.legs = Vector2(sin(u*TAU*2),-sin(u*TAU*2))*e*.22
			p.knees = Vector2.ONE*e*.18
			p.beak = e*.15
		"feed","eat","chew":
			emotion = "Eating"
			p.head_rot.x = -e*.12
			p.neck = e*.05
			p.beak = sin(minf(u*2.5,1.0)*PI*.5)*.50 if u<.4 else maxf(0,sin((u-.4)*TAU*5.0))*.30*(1.0-u)
			p.head_rot.z = sin(u*TAU*2)*e*.035
			p.shutter = 1.0-e*.15
		"wash","rinse":
			emotion = "Bathing"
			p.body_rot.y = sin(u*TAU*2.0)*e*.10
			p.head_rot.z = sin(u*TAU)*e*.16
			p.beak = e*.09
			p.shutter = 1.0-e*.25
		"dry":
			emotion = "Bathing"
			p.body_rot.y = fast*e*.16
			p.head_rot.y = -fast*e*.24
			p.body_rot.z = sin(u*TAU*4.0)*e*.06
		"filter":
			p.head_rot.x = e*.34
			p.neck = e*.12
			p.head_rot.y = e*.22
		"ball","walk":
			emotion = "Playing"
			p.body_offset.z = sin(u*TAU)*.18
			p.legs = Vector2(fast,-fast)*e*.26
			p.knees = Vector2(maxf(fast,0),maxf(-fast,0))*e*.16
			p.body_rot.y = sin(u*TAU)*e*.12
			p.wheel = sin(u*TAU)*5.0
			p.head_rot.x = e*.10
		"roll","roll_forward","roll_backward":
			var direction = -1.0 if key=="roll_backward" else 1.0
			p.body_offset.z = e*.35*direction
			p.body_rot.x = -e*.06*direction
			p.wheel = cos(u*PI)*6.0*direction
			p.head_rot.y = sin(u*TAU)*e*.10
		"duck":
			emotion = "Happy"
			p.head_rot.z = e*.17
			p.beak = maxf(fast,0)*e*.22
			p.body_offset.y = absf(sin(u*TAU*2))*e*.025
		"cube","inspect","pick_up":
			emotion = "Curious"
			p.head_rot.x = e*.29
			p.head_rot.y = sin(u*TAU)*e*.26
			p.neck = e*.12
			p.beak = e*.16 if key=="pick_up" else e*.035
		"music","dance","win","celebrate":
			emotion = "Celebrating" if key in ["win","celebrate"] else "Happy"
			p.body_rot.z = sin(u*TAU*3.0)*e*.11
			p.head_rot.z = -p.body_rot.z*.7
			p.head_rot.y = sin(u*TAU*2.0)*e*.22
			p.legs = Vector2(fast,-fast)*e*.24
			p.knees = Vector2.ONE*e*.08
			p.body_offset.y = absf(sin(u*TAU*3.0))*e*.10
			p.beak = maxf(fast,0)*e*.15
			p.wheel = fast*3
		"jump":
			p.body_offset.y = pow(e,1.5)*.30
			p.knees = Vector2.ONE*e*.22
			p.beak = e*.13
		"turn":
			p.body_rot.y = TAU*smoothstep(0.0,1.0,u)
			p.wheel = 6.0
		"look_left","look_right":
			var sign_value = 1.0 if key=="look_left" else -1.0
			p.head_rot.y = e*.42*sign_value
			p.head_rot.z = -e*.045*sign_value
			p.neck = e*.025
		"blink":
			p.shutter = 1.0-pow(e,1.5)*.97
		"hungry":
			emotion = "Hungry"
			p.head_rot.x = -e*.12
			p.head_rot.z = sin(u*TAU)*e*.10
			p.beak = maxf(fast,0)*e*.22
		"sleepy":
			emotion = "Sleepy"
			p.head_rot.x = e*.28
			p.beak = pow(e,2)*.48
			p.shutter = 1.0-e*.65
		"lose","sad":
			emotion = "Sad"
			p.head_rot.x = e*.28
			p.neck = e*.10
			p.shutter = 1.0-e*.35
		"wake":
			p.head_rot.x = -e*.20
			p.neck = -e*.06
			p.beak = e*.33
			p.shutter = 1.0-e*.5
		"charge","stop_charge":
			p.head_rot.z = e*.1
			p.beak = e*.07

func _apply_pose(p: Dictionary, delta: float) -> void:
	var blend = 1.0-exp(-delta*11.0)
	rig.body.position = rig.body.position.lerp(Vector3(0,1.18,0)+p.body_offset,blend)
	var body_rotation: Vector3 = rig.body.rotation
	rig.body.rotation = Vector3(lerpf(body_rotation.x,p.body_rot.x,blend),lerp_angle(body_rotation.y,p.body_rot.y,blend),lerpf(body_rotation.z,p.body_rot.z,blend))
	rig.head.rotation = rig.head.rotation.lerp(p.head_rot,blend)
	for i in range(rig.neck.size()):
		var target = Vector3(float(p.neck)*(1.0 if i!=1 else -.65),0,0)
		rig.neck[i].rotation = rig.neck[i].rotation.lerp(target,blend)
	rig.beak.rotation.x = lerpf(rig.beak.rotation.x,float(p.beak),blend)
	var hatch_open = sin(clampf(action_time/action_duration,0.0,1.0)*PI)*-1.3 if active_action=="filter" else 0.0
	rig.filter_hatch.rotation.x = lerpf(rig.filter_hatch.rotation.x,hatch_open,blend)
	rig.shutter.scale.y = lerpf(rig.shutter.scale.y,maxf(float(p.shutter),.035),blend)
	for i in range(2):
		var leg: Dictionary = rig.legs[i]
		leg.hip.rotation.x = lerpf(leg.hip.rotation.x,p.legs[i],blend)
		leg.knee.rotation.x = lerpf(leg.knee.rotation.x,p.knees[i],blend)
		leg.foot.rotation.x = lerpf(leg.foot.rotation.x,-p.legs[i]-p.knees[i],blend)
		leg.foot.rotation.y = lerpf(leg.foot.rotation.y,p.feet[i],blend)
		for wheel in leg.wheels:
			wheel.rotation.x += float(p.wheel)*delta

func _update_effects(_delta: float) -> void:
	var m: StandardMaterial3D = rig.materials.glow
	var color = eye_color
	if needs.battery<15:
		color = Color("ff8c67")
	elif needs.hunger<20:
		color = Color("ffd176")
	if active_action in ["pet","win","celebrate","dance"]:
		color = Color("a3efcf")
	m.emission = color
	m.albedo_color = color.darkened(.78) if is_sleeping else color
	m.emission_energy_multiplier = 0.0 if is_sleeping else (.65+.4*sin(elapsed*3.0) if is_charging else .65)
	var washing = active_action in ["wash","rinse","dry"]
	for i in range(rig.bubbles.size()):
		var b: MeshInstance3D = rig.bubbles[i]
		b.visible = washing
		if washing:
			var angle = i*2.399+elapsed*.35
			b.position = Vector3(sin(angle)*(.50+(i%3)*.08),.50+fmod(elapsed*.42+i*.22,2.6),cos(angle)*.35+.27)
