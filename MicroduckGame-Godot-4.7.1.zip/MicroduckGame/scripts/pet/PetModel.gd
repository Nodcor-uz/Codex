extends RefCounted
const Kit = preload("res://scripts/pet/PetModelBuilder.gd")
var k = Kit.new()
var rig: Dictionary = {}

func build(root: Node3D) -> Dictionary:
	var cream = k.material("shell",Color("f6f0e7"),0.08,0.28)
	var orange = k.material("accent",Color("ff782b"),0.16,0.3)
	var beak_color = k.material("beak_color",Color("ff782b"),0.16,0.3)
	var roller_color = k.material("roller_color",Color("ff782b"),0.16,0.3)
	var lens_color = k.material("lens_color",Color("ff782b"),0.16,0.3)
	var gold = k.material("sole",Color("ffc34e"),0.12,0.36)
	var dark = k.material("dark",Color("30333b"),0.45,0.32)
	var black = k.material("black",Color("161a20"),0.18,0.43)
	var silver = k.material("metal",Color("afb9bd"),0.77,0.28)
	var face = k.material("face",Color("434b50"),0.32,0.43)
	var lens = k.material("lens",Color("101f29"),0.65,0.08)
	var glow = k.material("glow",Color("96e4e6"),0.24,0.20,0.65)
	var white = k.material("white",Color("fff9e8"),0.0,0.12,0.3)
	var grime_mat = k.material("grime",Color(0.40,0.31,0.23,0.66),0.0,0.95)
	var bubble_mat = k.material("bubble",Color(0.76,0.94,1.0,0.43),0.1,0.12)
	var body = k.node(root,"Body",Vector3(0,1.18,0))
	rig.body = body
	k.box(body,Vector3(0,0.03,0),Vector3(.81,.39,.53),dark,.08,"ServoCore")
	k.box(body,Vector3(0,.19,.12),Vector3(.96,.40,.66),cream,.15,"CreamChest")
	k.box(body,Vector3(0,.19,-.25),Vector3(.77,.31,.11),cream,.05,"RearAccessPanel")
	k.box(body,Vector3(0,-.13,0),Vector3(.49,.21,.40),black,.04,"HipMotor")
	k.bar(body,Vector3(-.47,-.12,0),Vector3(.47,-.12,0),.105,silver,"HipAxle")
	k.box(body,Vector3(.28,.19,.462),Vector3(.10,.045,.018),glow,.009,"StatusLED")
	for x in [-.34,.34]:
		k.screw(body,Vector3(x,.28,.43),.025,silver,black,Vector3.BACK)
	for i in range(3):
		k.box(body,Vector3(-.20+i*.12,-.015,.282),Vector3(.07,.045,.02),silver,.009,"Vent")
	# Functional front filter bay: the cover pivots open during maintenance.
	k.box(body,Vector3(-.13,.16,.45),Vector3(.35,.21,.028),dark,.02,"FilterBay")
	for row in range(4):
		k.box(body,Vector3(-.13,.09+row*.044,.47),Vector3(.28,.018,.014),silver,.005,"FilterGrid")
	var hatch = k.node(body,"FilterHatch",Vector3(-.13,.26,.49))
	k.box(hatch,Vector3(0,-.10,0),Vector3(.34,.20,.035),cream,.02,"FilterCover")
	k.box(hatch,Vector3(0,-.16,.026),Vector3(.09,.015,.009),orange,.004,"HatchGrip")
	rig.filter_hatch = hatch
	k.hit(body,"body",Vector3(0,.10,.10),Vector3(1.02,.63,.79))
	# A three-link, exposed servo neck with visible plates, screws and cable.
	var neck0 = k.node(body,"NeckLower",Vector3(0,.34,-.03))
	var neck1 = k.node(neck0,"NeckMiddle",Vector3(0,.30,0))
	var neck2 = k.node(neck1,"NeckUpper",Vector3(0,.30,0))
	for joint in [neck0,neck1,neck2]:
		k.box(joint,Vector3(0,.14,0),Vector3(.19,.30,.14),black,.025,"ServoLink")
		k.box(joint,Vector3(0,.14,.083),Vector3(.23,.27,.035),silver,.018,"NeckPlate")
		k.cylinder(joint,Vector3(0,0,.10),.095,.045,silver,Vector3.BACK,"HingeDisc")
		k.cylinder(joint,Vector3(0,0,.13),.036,.018,black,Vector3.BACK,"HingePin")
		for y in [.085,.20]:
			k.screw(joint,Vector3(0,y,.112),.025,black,silver,Vector3.BACK)
		k.bar(joint,Vector3(.115,.015,-.10),Vector3(.16,.12,-.10),.018,black,"CableLower")
		k.bar(joint,Vector3(.16,.12,-.10),Vector3(.115,.29,-.10),.018,black,"CableUpper")
	rig.neck = [neck0,neck1,neck2]
	var head = k.node(neck2,"HeadPivot",Vector3(0,.26,.01))
	rig.head = head
	k.dome(head,Vector3(0,.35,0),Vector3(1.42,.85,.89),cream,"DomeShell")
	k.dome(head,Vector3(0,.31,.425),Vector3(1.25,.65,.11),face,"GraphiteFace")
	k.box(head,Vector3(0,.02,.17),Vector3(1.43,.12,.92),beak_color,.048,"UpperBeakTrim")
	k.box(head,Vector3(0,-.015,.62),Vector3(1.48,.105,.56),beak_color,.047,"UpperBill")
	k.box(head,Vector3(0,.041,.64),Vector3(1.34,.015,.49),gold,.007,"BillHighlight")
	k.box(head,Vector3(0,-.08,.48),Vector3(1.18,.05,.52),black,.02,"MouthInterior")
	var beak = k.node(head,"BeakLower",Vector3(0,-.045,.12))
	rig.beak = beak
	k.box(beak,Vector3(0,-.10,.42),Vector3(1.43,.105,.78),beak_color,.047,"LowerBill")
	k.box(beak,Vector3(0,-.04,.41),Vector3(1.23,.035,.64),gold,.012,"LowerBillLining")
	for side in [-1,1]:
		k.cylinder(head,Vector3(side*.735,-.045,.15),.105,.055,beak_color,Vector3.RIGHT,"BillHinge")
		k.cylinder(head,Vector3(side*.768,-.045,.15),.047,.016,black,Vector3.RIGHT,"HingeSocket")
		k.cylinder(head,Vector3(side*.78,-.045,.15),.021,.02,silver,Vector3.RIGHT,"HingePin")
		k.box(head,Vector3(side*.698,.20,-.15),Vector3(.014,.28,.025),silver,.006,"ShellSeam")
		k.screw(head,Vector3(side*.71,.35,-.16),.026,black,silver,Vector3(side,0,0))
	# Single camera eye, without human sclera or iris.
	var eye = k.node(head,"CameraEye",Vector3(-.12,.34,.50))
	rig.eye = eye
	k.cylinder(eye,Vector3.ZERO,.267,.085,black,Vector3.BACK,"LensMount")
	k.ring(eye,Vector3(0,0,.051),.241,.047,lens_color,"OrangeLensRim")
	k.ring(eye,Vector3(0,0,.086),.198,.014,gold,"MachinedRim")
	var shutter = k.node(eye,"OpticalShutter",Vector3(0,0,.086))
	rig.shutter = shutter
	k.sphere(shutter,Vector3.ZERO,Vector3(.377,.377,.075),lens,"GlossyLens")
	k.ring(shutter,Vector3(0,0,.042),.127,.011,glow,"CameraStatusRing")
	k.sphere(shutter,Vector3(0,0,.039),Vector3(.205,.205,.035),black,"OpticalAperture")
	k.sphere(shutter,Vector3(-.065,.075,.063),Vector3(.069,.057,.020),white,"KeylightReflection")
	k.sphere(shutter,Vector3(.067,-.067,.059),Vector3(.024,.024,.014),glow,"LensGlint")
	k.box(head,Vector3(.39,.35,.49),Vector3(.13,.065,.024),black,.025,"SecondarySensor")
	k.sphere(head,Vector3(.415,.35,.506),Vector3(.034,.034,.012),glow,"SensorLED")
	k.hit(head,"head",Vector3(0,.42,.08),Vector3(1.47,.75,.98))
	k.hit(beak,"beak",Vector3(0,-.08,.48),Vector3(1.51,.26,.73))
	var left = _leg(body,-1,cream,roller_color,gold,dark,black,silver)
	var right = _leg(body,1,cream,roller_color,gold,dark,black,silver)
	rig.legs = [left,right]
	# Dirt and bath bubbles are pooled; no geometry is allocated during animation.
	var dirt: Array = []
	for p in [Vector3(-.30,.27,.445),Vector3(.17,.06,.448),Vector3(.35,.13,.42),Vector3(-.14,.1,.458)]:
		dirt.append(k.sphere(body,p,Vector3(.13,.07,.008),grime_mat,"DustSmudge"))
	for p in [Vector3(-.41,.50,.493),Vector3(.34,.14,.495),Vector3(.48,.44,.479)]:
		dirt.append(k.sphere(head,p,Vector3(.12,.07,.008),grime_mat,"DustSmudge"))
	rig.dirt = dirt
	var bubbles: Array = []
	for i in range(10):
		var bubble = k.sphere(root,Vector3.ZERO,Vector3.ONE*(.10+float(i%3)*.045),bubble_mat,"BathBubble")
		bubble.visible = false
		bubbles.append(bubble)
	rig.bubbles = bubbles
	var accessories = k.node(head,"Accessories")
	var cap = k.node(accessories,"Cap",Vector3(0,.74,0))
	k.sphere(cap,Vector3(0,.04,0),Vector3(.92,.37,.77),orange,"CapCrown")
	k.box(cap,Vector3(0,-.03,.34),Vector3(.96,.075,.51),orange,.035,"CapVisor")
	k.sphere(cap,Vector3(0,.225,0),Vector3(.1,.07,.1),gold,"CapButton")
	cap.visible = false
	var glasses = k.node(accessories,"Glasses",Vector3(0,.34,.65))
	for x in [-.32,.32]:
		k.ring(glasses,Vector3(x,0,0),.22,.025,dark,"GlassesFrame")
	k.bar(glasses,Vector3(-.10,0,0),Vector3(.10,0,0),.022,dark,"GlassesBridge")
	k.bar(glasses,Vector3(-.54,0,0),Vector3(-.72,0,-.32),.02,dark)
	k.bar(glasses,Vector3(.54,0,0),Vector3(.72,0,-.32),.02,dark)
	glasses.visible = false
	var bow = k.node(body,"BowTie",Vector3(0,.36,.48))
	for side in [-1,1]:
		var wing = k.sphere(bow,Vector3(side*.13,0,0),Vector3(.25,.17,.08),orange,"BowWing")
		wing.rotation.z = side*.24
	k.sphere(bow,Vector3(0,0,.025),Vector3(.1,.11,.10),gold,"BowKnot")
	bow.visible = false
	rig.accessories = {"bow":bow,"cap":cap,"glasses":glasses}
	rig.materials = k.materials
	rig.mesh_count = _count_meshes(root)
	return rig

func _leg(body: Node3D, side: int, cream: Material, orange: Material, gold: Material, dark: Material, black: Material, silver: Material) -> Dictionary:
	var hip = k.node(body,"LeftLeg" if side<0 else "RightLeg",Vector3(side*.34,-.11,0))
	k.cylinder(hip,Vector3(0,0,0),.16,.20,dark,Vector3.RIGHT,"HipServo")
	k.cylinder(hip,Vector3(side*.12,0,0),.13,.035,silver,Vector3.RIGHT,"HipCap")
	k.box(hip,Vector3(side*.06,-.20,-.06),Vector3(.26,.43,.25),black,.04,"ThighLink")
	var shell = k.box(hip,Vector3(side*.19,-.20,.005),Vector3(.16,.46,.37),cream,.075,"ThighArmor")
	shell.rotation.x = -.15
	k.cylinder(hip,Vector3(side*.29,-.30,.06),.036,.015,silver,Vector3.RIGHT,"ArmorFastener")
	var knee = k.node(hip,"KneePivot",Vector3(0,-.39,-.07))
	k.cylinder(knee,Vector3.ZERO,.105,.32,silver,Vector3.RIGHT,"KneeAxle")
	k.cylinder(knee,Vector3(side*.18,0,0),.063,.025,black,Vector3.RIGHT,"KneeSocket")
	k.box(knee,Vector3(0,-.20,.075),Vector3(.18,.39,.19),dark,.028,"LowerLegDrive")
	k.bar(knee,Vector3(side*.08,-.055,.145),Vector3(side*.08,-.35,.26),.026,silver,"AnklePiston")
	k.box(knee,Vector3(0,-.19,.195),Vector3(.13,.18,.035),silver,.013,"ShinPlate")
	for dy in [-.13,-.23]:
		k.screw(knee,Vector3(0,dy,.22),.023,black,silver,Vector3.BACK)
	var foot = k.node(knee,"RollerFoot",Vector3(0,-.45,.17))
	k.box(foot,Vector3(0,.055,.10),Vector3(.45,.18,.72),orange,.075,"OrangeRollerBoot")
	k.box(foot,Vector3(0,-.018,.10),Vector3(.46,.075,.75),gold,.03,"SunnySole")
	k.box(foot,Vector3(0,.14,-.10),Vector3(.28,.18,.26),orange,.06,"AnkleCuff")
	k.cylinder(foot,Vector3(side*.15,.13,-.12),.053,.025,silver,Vector3.RIGHT,"AnkleHinge")
	for z in [.12,.23,.33]:
		k.box(foot,Vector3(0,.153,z),Vector3(.19,.018,.023),gold,.007,"ToeTread")
	var wheels: Array = []
	for z in [-.16,.37]:
		var wheel = k.node(foot,"Wheel",Vector3(0,-.08,z))
		k.cylinder(wheel,Vector3.ZERO,.135,.49,black,Vector3.RIGHT,"RubberWheel")
		for s in [-1,1]:
			k.cylinder(wheel,Vector3(s*.251,0,0),.085,.018,dark,Vector3.RIGHT,"WheelHub")
			k.cylinder(wheel,Vector3(s*.265,0,0),.034,.018,silver,Vector3.RIGHT,"WheelBearing")
			for a in range(3):
				var theta = a*TAU/3.0
				k.sphere(wheel,Vector3(s*.268,cos(theta)*.063,sin(theta)*.063),Vector3(.012,.022,.022),orange,"HubMark")
		wheels.append(wheel)
	k.hit(foot,"feet",Vector3(0,.04,.1),Vector3(.60,.45,.86))
	return {"hip":hip,"knee":knee,"foot":foot,"wheels":wheels,"side":side}

func _count_meshes(n: Node) -> int:
	var count = 1 if n is MeshInstance3D else 0
	for child in n.get_children():
		count += _count_meshes(child)
	return count
