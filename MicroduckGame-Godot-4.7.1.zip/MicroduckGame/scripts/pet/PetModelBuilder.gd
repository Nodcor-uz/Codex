extends RefCounted
## Procedural, shared-resource hard-surface model kit. Geometry is built once.
var mesh_cache: Dictionary = {}
var materials: Dictionary = {}

func material(id: String, color: Color, metallic: float = 0.0, roughness: float = 0.4, emission: float = 0.0) -> StandardMaterial3D:
	if materials.has(id):
		return materials[id]
	var m = StandardMaterial3D.new()
	m.albedo_color = color
	m.metallic = metallic
	m.roughness = roughness
	if color.a < 0.999:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	if emission > 0.0:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = emission
	materials[id] = m
	return m

func node(parent: Node3D, title: String, pos: Vector3 = Vector3.ZERO) -> Node3D:
	var n = Node3D.new()
	n.name = title
	n.position = pos
	parent.add_child(n)
	return n

func mesh(parent: Node3D, shape: Mesh, mat: Material, pos: Vector3, title: String = "Detail") -> MeshInstance3D:
	var n = MeshInstance3D.new()
	n.name = title
	n.mesh = shape
	n.material_override = mat
	n.position = pos
	parent.add_child(n)
	return n

func box(parent: Node3D, pos: Vector3, dims: Vector3, mat: Material, radius: float = 0.04, title: String = "RoundedPanel") -> MeshInstance3D:
	var key = "box_%s_%s" % [dims, radius]
	if not mesh_cache.has(key):
		mesh_cache[key] = rounded_box(dims, minf(radius, minf(dims.x, minf(dims.y, dims.z)) * 0.49))
	return mesh(parent, mesh_cache[key], mat, pos, title)

func sphere(parent: Node3D, pos: Vector3, dims: Vector3, mat: Material, title: String = "RoundedDetail") -> MeshInstance3D:
	if not mesh_cache.has("sphere"):
		var s = SphereMesh.new()
		s.radius = 0.5
		s.height = 1.0
		s.radial_segments = 24
		s.rings = 12
		mesh_cache["sphere"] = s
	var n = mesh(parent, mesh_cache["sphere"], mat, pos, title)
	n.scale = dims
	return n

func cylinder(parent: Node3D, pos: Vector3, radius: float, height: float, mat: Material, axis: Vector3 = Vector3.UP, title: String = "Servo") -> MeshInstance3D:
	var key = "cyl_%s_%s" % [radius, height]
	if not mesh_cache.has(key):
		var c = CylinderMesh.new()
		c.top_radius = radius
		c.bottom_radius = radius
		c.height = height
		c.radial_segments = 24
		mesh_cache[key] = c
	var n = mesh(parent, mesh_cache[key], mat, pos, title)
	if axis.normalized().dot(Vector3.UP) < 0.999:
		n.quaternion = Quaternion(Vector3.UP, axis.normalized())
	return n

func bar(parent: Node3D, a: Vector3, b: Vector3, radius: float, mat: Material, title: String = "Link") -> MeshInstance3D:
	return cylinder(parent, (a+b)*0.5, radius, a.distance_to(b), mat, b-a, title)

func ring(parent: Node3D, pos: Vector3, radius: float, tube: float, mat: Material, title: String = "Ring") -> MeshInstance3D:
	var key = "torus_%s_%s" % [radius,tube]
	if not mesh_cache.has(key):
		var t = TorusMesh.new()
		t.inner_radius = radius-tube
		t.outer_radius = radius+tube
		t.rings = 32
		t.ring_segments = 10
		mesh_cache[key] = t
	var n = mesh(parent, mesh_cache[key], mat, pos, title)
	n.rotation.x = PI*0.5
	return n

func screw(parent: Node3D, pos: Vector3, radius: float, metal: Material, dark: Material, axis: Vector3 = Vector3.FORWARD) -> void:
	var n = node(parent, "Fastener", pos)
	if axis != Vector3.FORWARD:
		n.quaternion = Quaternion(Vector3.FORWARD, axis.normalized())
	cylinder(n, Vector3.ZERO, radius, radius*0.30, metal, Vector3.FORWARD, "ScrewHead")
	box(n, Vector3(0,0,-radius*0.18), Vector3(radius*1.05, radius*0.18, radius*0.13), dark, radius*0.05,"Slot")

func hit(parent: Node3D, part: String, pos: Vector3, dims: Vector3) -> Area3D:
	var area = Area3D.new()
	area.name = "Touch_"+part
	area.collision_layer = 1
	area.collision_mask = 0
	area.input_ray_pickable = true
	area.set_meta("part",part)
	area.add_to_group("pet_hit")
	area.position = pos
	var c = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = dims
	c.shape = shape
	area.add_child(c)
	parent.add_child(area)
	return area

func rounded_box(dims: Vector3, radius: float) -> ArrayMesh:
	# Project a tessellated cube to an inset box plus a spherical bevel. All
	# vertex normals are analytic so the corners remain smooth and plastic-like.
	var surface = SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	var half = dims*0.5
	var inner = half-Vector3.ONE*radius
	var steps = 8
	var frames = [
		[Vector3.RIGHT,Vector3.BACK,Vector3.UP],
		[Vector3.LEFT,Vector3.FORWARD,Vector3.UP],
		[Vector3.UP,Vector3.RIGHT,Vector3.BACK],
		[Vector3.DOWN,Vector3.RIGHT,Vector3.FORWARD],
		[Vector3.BACK,Vector3.LEFT,Vector3.UP],
		[Vector3.FORWARD,Vector3.RIGHT,Vector3.UP]]
	for f in frames:
		var normal: Vector3 = f[0]
		var u: Vector3 = f[1]
		var v: Vector3 = f[2]
		for i in range(steps):
			for j in range(steps):
				var uv = [Vector2(float(i)/steps,float(j)/steps),Vector2(float(i+1)/steps,float(j)/steps),Vector2(float(i+1)/steps,float(j+1)/steps),Vector2(float(i)/steps,float(j+1)/steps)]
				for idx in [0,1,2,0,2,3]:
					var p = (normal+u*(uv[idx].x*2.0-1.0)+v*(uv[idx].y*2.0-1.0))*half
					var core = Vector3(clampf(p.x,-inner.x,inner.x),clampf(p.y,-inner.y,inner.y),clampf(p.z,-inner.z,inner.z))
					var n = (p-core).normalized()
					surface.set_normal(n)
					surface.set_uv(uv[idx])
					surface.add_vertex(core+n*radius)
	surface.index()
	return surface.commit()

func dome(parent: Node3D, pos: Vector3, dims: Vector3, mat: Material, title: String) -> MeshInstance3D:
	# Rounded arch silhouette taken from the photographed robot shell.
	var key = "dome_%s" % dims
	if not mesh_cache.has(key):
		var contour: Array[Vector2] = []
		var half = dims.x*.5
		var base = -dims.y*.5
		var shoulder = base+dims.y*.32
		contour.append(Vector2(-half*.92,base))
		contour.append(Vector2(half*.92,base))
		contour.append(Vector2(half,base+dims.y*.07))
		for i in range(25):
			var a = PI*float(i)/24.0
			contour.append(Vector2(cos(a)*half,shoulder+sin(a)*dims.y*.68))
		contour.append(Vector2(-half,base+dims.y*.07))
		var normals: Array[Vector2] = []
		for i in range(contour.size()):
			var tangent = (contour[(i+1)%contour.size()]-contour[posmod(i-1,contour.size())]).normalized()
			normals.append(Vector2(tangent.y,-tangent.x))
		var st = SurfaceTool.new()
		st.begin(Mesh.PRIMITIVE_TRIANGLES)
		var rings = [[.93,dims.z*.5,0.60],[1.0,dims.z*.40,0.0],[1.0,-dims.z*.40,0.0],[.93,-dims.z*.5,-.60]]
		for r in range(3):
			for i in range(contour.size()):
				var j = (i+1)%contour.size()
				for pair in [[r,i],[r,j],[r+1,j],[r,i],[r+1,j],[r+1,i]]:
					var rr: Array = rings[pair[0]]
					var xy: Vector2 = contour[pair[1]]*float(rr[0])
					var nn: Vector2 = normals[pair[1]]
					st.set_normal(Vector3(nn.x,nn.y,float(rr[2])).normalized())
					st.add_vertex(Vector3(xy.x,xy.y,float(rr[1])))
		for face_index in [0,3]:
			var rr: Array = rings[face_index]
			var normal = Vector3.BACK if face_index==0 else Vector3.FORWARD
			for i in range(contour.size()):
				var j = (i+1)%contour.size()
				var inds = [j,i,-1] if face_index==0 else [i,j,-1]
				for idx in inds:
					var xy = contour[idx]*float(rr[0]) if idx>=0 else Vector2.ZERO
					st.set_normal(normal)
					st.add_vertex(Vector3(xy.x,xy.y,float(rr[1])))
		st.index()
		mesh_cache[key] = st.commit()
	return mesh(parent,mesh_cache[key],mat,pos,title)
