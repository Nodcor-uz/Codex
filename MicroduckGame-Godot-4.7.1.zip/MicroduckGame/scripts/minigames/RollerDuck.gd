extends "res://scripts/minigames/GameBoard.gd"
## Real 3D three-lane course. Simulation owns collision, so touch and desktop behave identically.
var viewport: SubViewport
var world: Node3D
var pet: Node3D
var objects: Array = []
var stripes: Array[Node3D] = []
var materials: Dictionary = {}
var lane: int = 1
var lives: int = 3
var jump_timer: float = 0.0
var jump_height: float = 0.0
var invulnerable: float = 0.0
var boost_timer: float = 0.0
var spawn_clock: float = 1.0
var roll_clock: float = 0.0
var distance_clock: float = 0.0
var pointer_start = Vector2.ZERO
var pointer_down: bool = false

func _ready() -> void:
	super._ready()
	var display = SubViewportContainer.new()
	display.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	display.mouse_filter = Control.MOUSE_FILTER_IGNORE
	display.show_behind_parent = true
	display.stretch = true
	add_child(display)
	viewport = SubViewport.new()
	viewport.size = Vector2i(640, 850)
	viewport.own_world_3d = true
	viewport.transparent_bg = false
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	viewport.msaa_3d = Viewport.MSAA_DISABLED
	display.add_child(viewport)
	world = Node3D.new()
	viewport.add_child(world)
	var environment_node = WorldEnvironment.new()
	var environment = Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color("cee9e7")
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color("fff0d9")
	environment.ambient_light_energy = 0.85
	environment_node.environment = environment
	world.add_child(environment_node)
	var sunlight = DirectionalLight3D.new()
	sunlight.rotation_degrees = Vector3(-45, -25, 0)
	sunlight.light_color = Color("fff1d4")
	sunlight.light_energy = 1.4
	world.add_child(sunlight)
	var camera = Camera3D.new()
	world.add_child(camera)
	camera.position = Vector3(0, 6.5, 9.5)
	camera.look_at(Vector3(0, 0.6, -7.0))
	camera.fov = 58
	camera.current = true
	box(world, Vector3(15, 0.35, 55), Vector3(0, -0.35, -19), Color("b8d7b1"))
	box(world, Vector3(5.5, 0.16, 48), Vector3(0, -0.12, -17), Color("747c8e"))
	for x in [-2.9, 2.9]:
		box(world, Vector3(0.3, 0.3, 48), Vector3(x, 0.02, -17), Color("f6e5c7"))
	for z in range(-40, 7, 4):
		for x in [-0.88, 0.88]:
			var stripe = box(world, Vector3(0.045, 0.02, 1.8), Vector3(x, -0.015, z), Color("e5e9e7"))
			stripes.append(stripe)
		for x in [-4.8, 4.8]:
			box(world, Vector3(0.22, 1.2, 0.22), Vector3(x, 0.45, z), Color("c99e7e"))
			var tree = MeshInstance3D.new()
			var sphere = SphereMesh.new()
			sphere.radius = 1.1
			sphere.height = 2.0
			sphere.radial_segments = 12
			sphere.rings = 6
			tree.mesh = sphere
			tree.material_override = material(Color("9ac5a8"))
			tree.position = Vector3(x, 1.6, z)
			world.add_child(tree)
	if ResourceLoader.exists("res://scenes/pet/Microduck.tscn"):
		pet = load("res://scenes/pet/Microduck.tscn").instantiate()
		world.add_child(pet)
		pet.scale = Vector3.ONE * 0.62
		pet.rotation.y = PI
		pet.position.z = 1.0
		var state = get_node_or_null("/root/State")
		if state:
			pet.set_skin(state.data.get("equipped_skin", "classic"))
		pet.play("roll")

func material(color: Color) -> StandardMaterial3D:
	var key = color.to_html()
	if materials.has(key):
		return materials[key]
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.65
	materials[key] = mat
	return mat

func box(parent: Node3D, dimensions: Vector3, pos: Vector3, color: Color) -> MeshInstance3D:
	var node = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = dimensions
	node.mesh = mesh
	node.material_override = material(color)
	node.position = pos
	parent.add_child(node)
	return node

func _reset() -> void:
	duration = 50.0
	time_left = duration
	for item in objects:
		if is_instance_valid(item.node):
			item.node.queue_free()
	objects.clear()
	lane = 1
	lives = 3
	jump_timer = 0
	jump_height = 0
	invulnerable = 0
	boost_timer = 0
	spawn_clock = 0.5
	distance_clock = 0

func _tick(delta: float) -> void:
	invulnerable = maxf(0, invulnerable - delta)
	boost_timer = maxf(0, boost_timer - delta)
	jump_timer = maxf(0, jump_timer - delta)
	jump_height = sin((1.0 - jump_timer / 0.85) * PI) * 1.15 if jump_timer > 0 else 0.0
	var speed: float = 7.2 + elapsed * 0.035
	if boost_timer > 0:
		speed *= 1.25
	if is_instance_valid(pet):
		pet.position.x = lerpf(pet.position.x, (lane - 1) * 1.76, minf(1, delta * 12))
		pet.position.y = jump_height
		pet.visible = invulnerable <= 0 or int(invulnerable * 10) % 2 == 0
		roll_clock -= delta
		if roll_clock <= 0:
			roll_clock = 2.0
			pet.play("roll")
	for stripe in stripes:
		stripe.position.z += speed * delta
		if stripe.position.z > 6:
			stripe.position.z -= 48
	spawn_clock -= delta
	if spawn_clock <= 0:
		spawn_clock = maxf(0.82, 1.4 - elapsed * 0.008)
		var chosen_lane: int = rng.randi_range(0, 2)
		var kind: String = "block" if rng.randf() < 0.5 else "barrier"
		spawn_object(kind, chosen_lane, -32)
		spawn_object("boost" if rng.randf() < 0.12 else "coin", (chosen_lane + rng.randi_range(1, 2)) % 3, -34)
	for i in range(objects.size() - 1, -1, -1):
		var item = objects[i]
		item.node.position.z += speed * delta
		if item.kind in ["coin", "boost"]:
			item.node.rotation.y += delta * 1.8
		if item.node.position.z >= 0.2 and not item.resolved:
			item.resolved = true
			if item.lane == lane:
				resolve(item.kind)
				if item.kind in ["coin", "boost"]:
					item.node.hide()
		if item.node.position.z > 8:
			item.node.queue_free()
			objects.remove_at(i)
	distance_clock += delta
	if distance_clock >= 1:
		distance_clock -= 1
		score += 2
	status = "%s %d / 3   ·   %s" % [tx("Lives"), lives, tx("Boost!") if boost_timer > 0 else tx("Swipe or use arrow keys")]

func spawn_object(kind: String, object_lane: int, z: float) -> void:
	if not is_instance_valid(world):
		return
	var root = Node3D.new()
	world.add_child(root)
	root.position = Vector3((object_lane - 1) * 1.76, 0, z)
	if kind == "block":
		box(root, Vector3(1.12, 1.7, 1.1), Vector3(0, 0.85, 0), Color("c7a8d7"))
		box(root, Vector3(1.15, 0.2, 1.14), Vector3(0, 1.2, 0), Color("f6d779"))
	elif kind == "barrier":
		for x in [-0.5, 0.5]:
			box(root, Vector3(0.15, 0.62, 0.2), Vector3(x, 0.31, 0), Color("ece8df"))
		box(root, Vector3(1.25, 0.26, 0.18), Vector3(0, 0.5, 0), Color("ff9967"))
	else:
		var sphere_node = MeshInstance3D.new()
		var mesh = CylinderMesh.new()
		mesh.top_radius = 0.32
		mesh.bottom_radius = 0.32
		mesh.height = 0.12
		mesh.radial_segments = 16
		sphere_node.mesh = mesh
		sphere_node.material_override = material(YELLOW if kind == "coin" else AQUA)
		sphere_node.rotation.x = PI / 2
		sphere_node.position.y = 0.75
		root.add_child(sphere_node)
	objects.append({"node": root, "kind": kind, "lane": object_lane, "resolved": false})

func resolve(kind: String) -> void:
	if not running:
		return
	if kind == "coin":
		score += 15
		feedback("Coin +15", "coin")
	elif kind == "boost":
		score += 20
		boost_timer = 4.0
		feedback("Boost!", "happy")
	elif (kind == "block" or jump_height < 0.52) and invulnerable <= 0:
		lives -= 1
		invulnerable = 1.3
		feedback("Careful!", "lose")
		if lives <= 0:
			finish(false)
	elif kind == "barrier" and jump_height >= 0.52:
		score += 10
		feedback("Nice jump!", "beep")

func move_lane(direction: int) -> void:
	if running:
		lane = clampi(lane + direction, 0, 2)

func jump() -> void:
	if running and jump_timer <= 0:
		jump_timer = 0.85

func _winning() -> bool:
	return lives > 0

func press_at(pos: Vector2) -> void:
	pointer_start = pos
	pointer_down = true
	if pos.y >= 735:
		if pos.x < 213:
			move_lane(-1)
		elif pos.x > 426:
			move_lane(1)
		else:
			jump()

func release_at(pos: Vector2) -> void:
	if not pointer_down:
		return
	pointer_down = false
	if pointer_start.y >= 735:
		return
	var distance = pos - pointer_start
	if distance.length() < 35:
		return
	if absf(distance.x) > absf(distance.y):
		move_lane(1 if distance.x > 0 else -1)
	elif distance.y < 0:
		jump()

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			press_at(point(event.position))
		else:
			release_at(point(event.position))
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.device != -1:
		if event.pressed:
			press_at(point(event.position))
		else:
			release_at(point(event.position))

func _unhandled_key_input(event: InputEvent) -> void:
	if not event.is_pressed() or event.is_echo():
		return
	if event.is_action_pressed("ui_left"):
		move_lane(-1)
	elif event.is_action_pressed("ui_right"):
		move_lane(1)
	elif event.is_action_pressed("ui_up") or (event is InputEventKey and event.keycode == KEY_SPACE):
		jump()

func _draw() -> void:
	draw_set_transform(Vector2.ZERO, 0, Vector2(size.x / 640, size.y / 850))
	for i in range(3):
		card(Rect2(18 + i * 211, 746, 183, 82), Color("f6f0e7"), 25)
		text_at(["<", tx("Jump"), ">"][i], Vector2(110 + i * 211, 797), 31)
	draw_feedback()
