extends "res://scripts/minigames/GameBoard.gd"
var sequence: Array[int] = []
var answer_index: int = 0
var round_number: int = 1
var phase: String = "watch"
var phase_clock: float = 0.0
var show_index: int = 0
var lit: int = -1
var answer_clock: float = 15.0
const PAD_COLORS = [Color("ff9967"), Color("9adfe8"), Color("b4a1e1"), Color("a9e2c1")]

func _reset() -> void:
	duration = 240.0
	time_left = duration
	round_number = 1
	sequence = [rng.randi_range(0, 3), rng.randi_range(0, 3)]
	begin_round()

func begin_round() -> void:
	phase = "watch"
	phase_clock = 0.65
	show_index = -1
	answer_index = 0
	lit = -1
	answer_clock = 15.0

func _tick(delta: float) -> void:
	phase_clock -= delta
	if phase == "watch":
		if phase_clock <= 0:
			if lit >= 0:
				lit = -1
				phase_clock = 0.23
			else:
				show_index += 1
				if show_index >= sequence.size():
					phase = "answer"
					phase_clock = 0
				else:
					lit = sequence[show_index]
					phase_clock = maxf(0.34, 0.65 - round_number * 0.028)
					feedback("Watch carefully", "beep")
	elif phase == "answer":
		answer_clock -= delta
		if phase_clock <= 0:
			lit = -1
		if answer_clock <= 0:
			feedback("Time is up", "lose")
			phase = "failed"
			phase_clock = 0.8
	elif phase == "between" and phase_clock <= 0:
		if round_number >= 8:
			finish(true)
		else:
			round_number += 1
			sequence.append(rng.randi_range(0, 3))
			begin_round()
	elif phase == "failed" and phase_clock <= 0:
		finish(false)
	status = "%s %d / 8   ·   %s" % [tx("Round"), round_number, tx("Watch carefully") if phase == "watch" else ("%s %ds" % [tx("Your turn"), ceili(answer_clock)])]

func choose(index: int) -> bool:
	if not running or phase != "answer" or index < 0 or index > 3:
		return false
	lit = index
	phase_clock = 0.19
	if index != sequence[answer_index]:
		lit = sequence[answer_index]
		feedback("That was the next light", "lose")
		phase = "failed"
		phase_clock = 1.2
		return false
	answer_index += 1
	feedback("Good memory!", "beep")
	if answer_index >= sequence.size():
		score += 40 * round_number
		phase = "between"
		phase_clock = 0.8
		feedback("Round complete!", "win")
	return true

func pad_rect(index: int) -> Rect2:
	return Rect2(50 + (index % 2) * 285, 220 + (index / 2) * 245, 255, 215)

func _winning() -> bool:
	# The global safety clock cannot award a win for only a partial sequence.
	return round_number >= 8 and phase == "between"

func press_at(pos: Vector2) -> void:
	for i in range(4):
		if pad_rect(i).has_point(pos):
			choose(i)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch and event.pressed:
		press_at(point(event.position))
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed and event.device != -1:
		press_at(point(event.position))

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		var keys = [KEY_1, KEY_2, KEY_3, KEY_4]
		if keys.has(event.keycode):
			choose(keys.find(event.keycode))

func _draw() -> void:
	drawing()
	for i in range(4):
		var color: Color = PAD_COLORS[i]
		if lit == i:
			card(pad_rect(i).grow(9), color.lightened(0.43), 40)
		card(pad_rect(i), color.lightened(0.25) if lit == i else color.darkened(0.08), 32)
		draw_circle(pad_rect(i).get_center(), 45, Color(1, 1, 1, 0.35 if lit == i else 0.16))
		text_at(str(i + 1), pad_rect(i).get_center() + Vector2(0, 15), 47)
	draw_duck(Vector2(320, 786), 0.64)
	text_at("%d / %d" % [answer_index, sequence.size()], Vector2(320, 164), 27, Color("747870"))
	draw_feedback()
