extends "res://scripts/minigames/GameBoard.gd"
var notes: Array = []
var combo: int = 0
var perfect: int = 0
var good: int = 0
var misses: int = 0
var lane_flash: Array[float] = [0.0, 0.0, 0.0, 0.0]
var voices: Array[AudioStreamPlayer] = []

func _ready() -> void:
	super._ready()
	for frequency in [261.63, 329.63, 392.0, 523.25]:
		var voice = AudioStreamPlayer.new()
		var wave = AudioStreamWAV.new()
		wave.format = AudioStreamWAV.FORMAT_16_BITS
		wave.mix_rate = 22050
		var samples = PackedByteArray()
		var count = 6615
		samples.resize(count * 2)
		for sample_index in range(count):
			var t: float = float(sample_index) / 22050.0
			var envelope: float = minf(t * 100, 1.0) * exp(-t * 12.0)
			var sound: float = (sin(TAU * frequency * t) + sin(TAU * frequency * 2 * t) * 0.2) * envelope * 0.4
			samples.encode_s16(sample_index * 2, int(sound * 32767))
		wave.data = samples
		voice.stream = wave
		voice.volume_db = -12
		add_child(voice)
		voices.append(voice)

func _reset() -> void:
	var audio_node = get_node_or_null("/root/Audio")
	if audio_node:
		audio_node.set_room("beat")
	duration = 45.0
	time_left = duration
	notes.clear()
	combo = 0
	perfect = 0
	good = 0
	misses = 0
	var motif = [0, 1, 2, 1, 3, 2, 1, 2, 0, 2, 3, 1, 2, 1, 0, 3]
	for i in range(70):
		notes.append({"lane": motif[i % motif.size()], "time": 2.5 + i * 0.6, "hit": false, "miss": false, "played": false})

func _exit_tree() -> void:
	for voice in voices:
		voice.stop()
		voice.stream = null
	voices.clear()

func _tick(delta: float) -> void:
	for i in range(4):
		lane_flash[i] = maxf(0, lane_flash[i] - delta)
	for note in notes:
		if elapsed >= note.time and not note.played:
			note.played = true
			play_note(note.lane)
		if elapsed > note.time + 0.25 and not note.hit and not note.miss:
			note.miss = true
			misses += 1
			combo = 0
			last_feedback = "Miss"
			flash = 0.45
	status = "%s %d   ·   %s %d   ·   %s %d" % [tx("Perfect"), perfect, tx("Good"), good, tx("Miss"), misses]

func play_note(lane: int) -> void:
	if voices.is_empty():
		return
	var volume: float = 0.5
	var state = get_node_or_null("/root/State")
	if state:
		volume = float(state.data.get("settings", {}).get("music", 0.5))
	if volume > 0:
		voices[lane].volume_db = linear_to_db(volume) - 10
		voices[lane].play()

func hit_lane(lane: int, at_time: float = -1.0) -> String:
	if not running or lane < 0 or lane > 3:
		return ""
	lane_flash[lane] = 0.2
	var current_time: float = elapsed if at_time < 0 else at_time
	var closest: int = -1
	var distance: float = 0.23
	for i in range(notes.size()):
		var note = notes[i]
		if note.lane == lane and not note.hit and not note.miss:
			var difference: float = absf(note.time - current_time)
			if difference < distance:
				closest = i
				distance = difference
	if closest < 0:
		combo = 0
		score = maxi(0, score - 2)
		misses += 1
		feedback("Miss", "ui")
		return "Miss"
	notes[closest].hit = true
	combo += 1
	var result: String = "Perfect" if distance <= 0.105 else "Good"
	if result == "Perfect":
		perfect += 1
		score += 30
	else:
		good += 1
		score += 15
	last_feedback = result
	flash = 0.5
	return result

func _winning() -> bool:
	return score >= 450

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch and event.pressed:
		hit_lane(clampi(int(point(event.position).x / 160), 0, 3))
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed and event.device != -1:
		hit_lane(clampi(int(point(event.position).x / 160), 0, 3))

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		var keys = [KEY_D, KEY_F, KEY_J, KEY_K]
		if keys.has(event.keycode):
			hit_lane(keys.find(event.keycode))

func _draw() -> void:
	drawing()
	var colors = [ORANGE, AQUA, LAVENDER, MINT]
	for lane in range(4):
		var color: Color = colors[lane]
		card(Rect2(10 + lane * 160, 22, 140, 790), color.lightened(0.77), 20)
		card(Rect2(15 + lane * 160, 720, 130, 85), color.lightened(0.3) if lane_flash[lane] > 0 else color, 20)
		text_at(["D", "F", "J", "K"][lane], Vector2(80 + lane * 160, 775), 27)
		draw_circle(Vector2(80 + lane * 160, 690), 38, Color(color, 0.25))
	draw_line(Vector2(15, 690), Vector2(625, 690), Color("ff833f"), 5)
	for note in notes:
		if note.hit or note.miss:
			continue
		var y: float = 690.0 - (note.time - elapsed) * 265.0
		if y > -25 and y < 760:
			var x: float = 80 + note.lane * 160
			card(Rect2(x - 50, y - 21, 100, 42), colors[note.lane], 15)
			draw_line(Vector2(x - 24, y), Vector2(x + 24, y), Color(1, 1, 1, 0.6), 4)
	draw_feedback()
