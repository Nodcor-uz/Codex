extends Control
signal finished(score: int, won: bool, aborted: bool)
@export var game_id: String = "catch"
const BOARDS = {
	"catch": "res://scripts/minigames/CatchChips.gd",
	"roller": "res://scripts/minigames/RollerDuck.gd",
	"memory": "res://scripts/minigames/MemoryLights.gd",
	"sort": "res://scripts/minigames/BatterySort.gd",
	"beat": "res://scripts/minigames/DuckBeat.gd",
	"treasure": "res://scripts/minigames/DuckTreasure.gd"
}
const TITLES = {"catch": "Catch the Chips", "roller": "Roller Duck", "memory": "Memory Lights", "sort": "Battery Sort", "beat": "Duck Beat", "treasure": "Duck Treasure"}
const RULES = {
	"catch": "Move the tray with your finger or arrow keys. Catch green, blue and gold chips. Avoid red chips. Five good catches make a combo!",
	"roller": "Swipe left or right to change lanes. Swipe up to jump low barriers. Avoid tall blocks, collect coins and boosters. Arrow keys and Space work too.",
	"memory": "Watch the four lights, then repeat their sequence. Each round adds one light. Complete eight rounds. You have 15 seconds to answer.",
	"sort": "Drag each battery into the bin of the same color and symbol. Correct: +15. Wrong: -5. The batteries arrive faster as you play.",
	"beat": "Tap a lane when its note reaches the glowing line. Perfect: +30. Good: +15. Use four fingers or D, F, J, K. Listen to the beat!",
	"treasure": "Remember the box with the golden gear. Watch the boxes swap places, then tap the right one. Five rounds, faster each time."
}
const GOALS = {"catch": "45 seconds · Goal: 120 points", "roller": "50 seconds · Three lives", "memory": "8 rounds · No mistakes", "sort": "40 seconds · Goal: 150 points", "beat": "45 seconds · Goal: 450 points", "treasure": "5 rounds · Find 3 treasures"}
var board: Control
var board_slot: Control
var intro: VBoxContainer
var score_label: Label
var time_label: Label
var status_label: Label
var emitted: bool = false

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	var background = ColorRect.new()
	background.color = Color("f6f0e7")
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(background)
	var margin = MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 26)
	add_child(margin)
	var column = VBoxContainer.new()
	column.add_theme_constant_override("separation", 16)
	margin.add_child(column)
	var header = HBoxContainer.new()
	column.add_child(header)
	var back = button("Exit", Color("e8e3d9"))
	back.custom_minimum_size.x = 112
	back.pressed.connect(abort)
	header.add_child(back)
	var title = label(TITLES.get(game_id, "Mini-game"), 30)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	header.add_child(title)
	var stats = HBoxContainer.new()
	stats.add_theme_constant_override("separation", 18)
	column.add_child(stats)
	score_label = label("Score", 24)
	score_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stats.add_child(score_label)
	time_label = label("Time", 24)
	stats.add_child(time_label)
	status_label = label("Ready?", 20)
	status_label.custom_minimum_size.y = 33
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(status_label)
	board_slot = Control.new()
	board_slot.size_flags_vertical = Control.SIZE_EXPAND_FILL
	column.add_child(board_slot)
	intro = VBoxContainer.new()
	intro.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	intro.alignment = BoxContainer.ALIGNMENT_CENTER
	intro.add_theme_constant_override("separation", 30)
	board_slot.add_child(intro)
	var number = label("06 / MICRODUCK ARCADE", 19)
	number.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	intro.add_child(number)
	var name_label = label(TITLES.get(game_id, "Mini-game"), 42)
	name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	intro.add_child(name_label)
	var rules = label(RULES.get(game_id, ""), 25)
	rules.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	rules.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	intro.add_child(rules)
	var goal = label(GOALS.get(game_id, ""), 22)
	goal.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	goal.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	intro.add_child(goal)
	var start_button = button("Let's play", Color("ff833f"))
	start_button.custom_minimum_size.y = 82
	start_button.pressed.connect(start_game)
	intro.add_child(start_button)
	var caption = label("Offline arcade · Play at your own pace", 18)
	caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	caption.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(caption)

func _process(_delta: float) -> void:
	if not is_instance_valid(board):
		return
	score_label.text = "%s  %04d" % [tx("Score"), board.score]
	time_label.text = "%s  %02d:%02d" % [tx("Time"), int(board.time_left) / 60, int(board.time_left) % 60]
	status_label.text = board.status

func configure(id: String) -> void:
	if not is_node_ready():
		game_id = id

func start_game() -> void:
	if is_instance_valid(board) or emitted:
		return
	intro.hide()
	board = load(BOARDS[game_id]).new()
	board.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	board_slot.add_child(board)
	board.completed.connect(_complete)
	board.start()

func _complete(points: int, won: bool) -> void:
	if emitted:
		return
	emitted = true
	# The main controller removes this scene when it receives the result.
	# Deliver after gameplay callbacks finish so no board resumes outside the tree.
	call_deferred("_deliver_result", points, won, false)

func abort() -> void:
	if emitted:
		return
	emitted = true
	if is_instance_valid(board):
		board.running = false
	call_deferred("_deliver_result", 0, false, true)

func _deliver_result(points: int, won: bool, aborted: bool) -> void:
	finished.emit(points, won, aborted)

func _unhandled_key_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		abort()
		get_viewport().set_input_as_handled()

func tx(source: String) -> String:
	var locale = get_node_or_null("/root/L")
	return locale.t(source) if locale else source

func label(source: String, font_size: int) -> Label:
	var node = Label.new()
	node.text = tx(source)
	node.add_theme_color_override("font_color", Color("33343b"))
	node.add_theme_font_size_override("font_size", font_size)
	return node

func button(source: String, color: Color) -> Button:
	var node = Button.new()
	node.text = tx(source)
	node.custom_minimum_size.y = 62
	node.add_theme_font_size_override("font_size", 24)
	for state_name in ["normal", "hover", "pressed", "focus"]:
		var style = StyleBoxFlat.new()
		style.bg_color = color.darkened(0.08) if state_name == "pressed" else color
		style.set_corner_radius_all(20)
		style.content_margin_left = 20
		style.content_margin_right = 20
		node.add_theme_stylebox_override(state_name, style)
	node.add_theme_color_override("font_color", Color("33343b"))
	node.add_theme_color_override("font_hover_color", Color("33343b"))
	node.add_theme_color_override("font_pressed_color", Color("33343b"))
	return node
