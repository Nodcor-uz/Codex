extends Control
## Shared clock, touch coordinates and drawing helpers. Rules live in each board.
signal completed(score: int, won: bool)
const INK = Color("33343b")
const CREAM = Color("f6f0e7")
const ORANGE = Color("ff833f")
const AQUA = Color("9adfe8")
const MINT = Color("a9e2c1")
const LAVENDER = Color("b4a1e1")
const YELLOW = Color("ffd45e")
const COLORS = [MINT, YELLOW, AQUA, Color("ef8f94")]
var score: int = 0
var time_left: float = 45.0
var duration: float = 45.0
var elapsed: float = 0.0
var running: bool = false
var ended: bool = false
var status: String = ""
var rng = RandomNumberGenerator.new()
var flash: float = 0.0
var last_feedback: String = ""

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	clip_contents = true
	rng.randomize()

func start() -> void:
	score = 0
	elapsed = 0.0
	time_left = duration
	ended = false
	running = true
	_reset()
	queue_redraw()

func _reset() -> void:
	pass

func _process(delta: float) -> void:
	if not running:
		return
	elapsed += delta
	time_left = maxf(0.0, time_left - delta)
	flash = maxf(0.0, flash - delta)
	_tick(delta)
	if time_left <= 0.0 and running:
		finish(_winning())
	queue_redraw()

func _tick(_delta: float) -> void:
	pass

func _winning() -> bool:
	return score > 0

func finish(won: bool) -> void:
	if ended:
		return
	ended = true
	running = false
	completed.emit(score, won)

func feedback(message: String, sound: String = "beep") -> void:
	last_feedback = message
	flash = 0.8
	var audio_node = get_node_or_null("/root/Audio") if is_inside_tree() else null
	if audio_node:
		audio_node.play(sound)

func tx(source: String) -> String:
	var locale = get_node_or_null("/root/L") if is_inside_tree() else null
	return locale.t(source) if locale else source

func point(position_in_control: Vector2) -> Vector2:
	return position_in_control * Vector2(640.0 / maxf(size.x, 1.0), 850.0 / maxf(size.y, 1.0))

func drawing() -> void:
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(size.x / 640.0, size.y / 850.0))
	card(Rect2(0, 0, 640, 850), Color("faf7f1"), 28)

func card(rect: Rect2, color: Color, radius: int = 20, border: Color = Color.TRANSPARENT) -> void:
	var style = StyleBoxFlat.new()
	style.bg_color = color
	style.corner_radius_top_left = radius
	style.corner_radius_top_right = radius
	style.corner_radius_bottom_left = radius
	style.corner_radius_bottom_right = radius
	if border.a > 0:
		style.set_border_width_all(3)
		style.border_color = border
	draw_style_box(style, rect)

func text_at(text: String, center: Vector2, font_size: int = 28, color: Color = INK) -> void:
	var font = ThemeDB.fallback_font
	var text_width = font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	draw_string(font, center - Vector2(text_width * 0.5, 0), text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, color)

func draw_chip(center: Vector2, color: Color, scale_factor: float = 1.0) -> void:
	var radius = 23.0 * scale_factor
	for i in range(3):
		var offset = (-14.0 + i * 14.0) * scale_factor
		draw_line(center + Vector2(-radius - 7, offset), center + Vector2(radius + 7, offset), Color("aaa998"), 5.0 * scale_factor)
		draw_line(center + Vector2(offset, -radius - 7), center + Vector2(offset, radius + 7), Color("aaa998"), 5.0 * scale_factor)
	card(Rect2(center - Vector2.ONE * radius, Vector2.ONE * radius * 2), color, 8)
	card(Rect2(center - Vector2.ONE * radius * 0.52, Vector2.ONE * radius * 1.04), color.darkened(0.2), 4)

func draw_duck(center: Vector2, scale_factor: float = 1.0) -> void:
	# A stylized mechanical receiver mascot. Main pet and runner remain true 3D.
	draw_line(center + Vector2(0, -10) * scale_factor, center + Vector2(0, -64) * scale_factor, INK, 12 * scale_factor)
	card(Rect2(center + Vector2(-39, -114) * scale_factor, Vector2(78, 61) * scale_factor), CREAM, 20, Color("d6d3c9"))
	card(Rect2(center + Vector2(-31, -104) * scale_factor, Vector2(62, 38) * scale_factor), INK, 15)
	draw_circle(center + Vector2(0, -85) * scale_factor, 16 * scale_factor, ORANGE)
	draw_circle(center + Vector2(0, -85) * scale_factor, 9 * scale_factor, INK)
	draw_circle(center + Vector2(-3, -90) * scale_factor, 3 * scale_factor, Color.WHITE)
	card(Rect2(center + Vector2(-42, -59) * scale_factor, Vector2(84, 12) * scale_factor), ORANGE, 6)
	card(Rect2(center + Vector2(-29, -23) * scale_factor, Vector2(58, 37) * scale_factor), CREAM, 12, Color("d6d3c9"))
	for x in [-24, 24]:
		draw_line(center + Vector2(x * 0.6, 12) * scale_factor, center + Vector2(x, 37) * scale_factor, INK, 9 * scale_factor)
		card(Rect2(center + Vector2(x - 18, 32) * scale_factor, Vector2(36, 12) * scale_factor), ORANGE, 5)
		draw_circle(center + Vector2(x - 11, 47) * scale_factor, 7 * scale_factor, INK)
		draw_circle(center + Vector2(x + 11, 47) * scale_factor, 7 * scale_factor, INK)

func draw_feedback() -> void:
	if flash > 0.0:
		var color = INK
		color.a = minf(flash * 3, 1.0)
		text_at(tx(last_feedback), Vector2(320, 90), 32, color)
