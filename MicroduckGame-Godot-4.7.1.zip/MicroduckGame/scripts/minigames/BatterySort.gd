extends "res://scripts/minigames/GameBoard.gd"
var batteries: Array = []
var spawn_clock: float = 0.0
var dragged: int = -1
var drag_position = Vector2.ZERO
var correct: int = 0
var mistakes: int = 0
const SYMBOLS = ["+", "=", "o", "x"]

func _reset() -> void:
	duration = 40.0
	time_left = duration
	batteries.clear()
	dragged = -1
	correct = 0
	mistakes = 0
	spawn_clock = 0.3
	spawn_battery()

func spawn_battery() -> void:
	if batteries.size() >= 7:
		return
	# Use vacant slots to avoid inaccessible overlapping batteries.
	var used: Array = []
	for battery in batteries:
		used.append(battery.slot)
	var slots: Array = []
	for i in range(8):
		if not used.has(i):
			slots.append(i)
	if slots.is_empty():
		return
	var slot: int = slots[rng.randi_range(0, slots.size() - 1)]
	batteries.append({"kind": rng.randi_range(0, 3), "slot": slot, "life": 0.0, "pos": Vector2(95 + (slot % 4) * 150, 240 + (slot / 4) * 180)})

func _tick(delta: float) -> void:
	spawn_clock -= delta
	if spawn_clock <= 0.0:
		spawn_clock = maxf(0.65, 1.9 - elapsed * 0.03)
		spawn_battery()
	for i in range(batteries.size() - 1, -1, -1):
		batteries[i].life += delta
		if batteries[i].life > 12.0 and i != dragged:
			batteries.remove_at(i)
			if dragged > i:
				dragged -= 1
			score = maxi(0, score - 2)
	status = "%s %d   ·   %s %d" % [tx("Sorted"), correct, tx("Mistakes"), mistakes]

func bin_rect(index: int) -> Rect2:
	return Rect2(14 + index * 157, 665, 141, 158)

func assign(index: int, bin_index: int) -> bool:
	if not running or index < 0 or index >= batteries.size() or bin_index < 0 or bin_index > 3:
		return false
	var success: bool = int(batteries[index].kind) == bin_index
	if success:
		score += 15
		correct += 1
		feedback("Perfect match!", "coin")
	else:
		score = maxi(0, score - 5)
		mistakes += 1
		feedback("Check the color", "lose")
	batteries.remove_at(index)
	dragged = -1
	return success

func press_at(pos: Vector2) -> void:
	for i in range(batteries.size() - 1, -1, -1):
		if Rect2(batteries[i].pos - Vector2(48, 69), Vector2(96, 138)).has_point(pos):
			dragged = i
			drag_position = pos
			return

func release_at(pos: Vector2) -> void:
	if dragged < 0:
		return
	for index in range(4):
		if bin_rect(index).grow(5).has_point(pos):
			assign(dragged, index)
			return
	dragged = -1

func _winning() -> bool:
	return score >= 150

func _gui_input(event: InputEvent) -> void:
	if not running:
		return
	if event is InputEventScreenTouch:
		if event.pressed:
			press_at(point(event.position))
		else:
			release_at(point(event.position))
	elif event is InputEventScreenDrag:
		drag_position = point(event.position)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.device != -1:
		if event.pressed:
			press_at(point(event.position))
		else:
			release_at(point(event.position))
	elif event is InputEventMouseMotion and dragged >= 0 and event.device != -1:
		drag_position = point(event.position)

func draw_battery(pos: Vector2, kind: int, alpha: float = 1.0) -> void:
	var color: Color = COLORS[kind]
	color.a = alpha
	card(Rect2(pos - Vector2(13, 64), Vector2(26, 14)), Color("aaa998"), 4)
	card(Rect2(pos - Vector2(36, 53), Vector2(72, 108)), color, 17, color.darkened(0.22))
	card(Rect2(pos - Vector2(30, 43), Vector2(60, 30)), color.lightened(0.3), 10)
	text_at(SYMBOLS[kind], pos + Vector2(0, 25), 43)

func _draw() -> void:
	drawing()
	card(Rect2(24, 150, 592, 410), Color("eae5db"), 28)
	for index in range(4):
		card(bin_rect(index), COLORS[index].lightened(0.18), 23, COLORS[index].darkened(0.12))
		card(Rect2(25 + index * 157, 683, 119, 22), COLORS[index].darkened(0.27), 10)
		text_at(SYMBOLS[index], Vector2(85 + index * 157, 780), 49)
	for i in range(batteries.size()):
		if i == dragged:
			continue
		var b = batteries[i]
		draw_battery(b.pos + Vector2(0, sin(b.life * 2.0) * 4), b.kind, 0.5 if b.life > 10 else 1.0)
	if dragged >= 0 and dragged < batteries.size():
		draw_battery(drag_position, batteries[dragged].kind)
	text_at(tx("Match color and symbol"), Vector2(320, 620), 22, Color("747870"))
	draw_feedback()
