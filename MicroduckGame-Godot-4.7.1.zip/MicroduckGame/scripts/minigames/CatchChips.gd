extends "res://scripts/minigames/GameBoard.gd"
var items: Array = []
var tray_x: float = 320.0
var combo: int = 0
var best_combo: int = 0
var spawn_clock: float = 0.0
var dragging: bool = false

func _reset() -> void:
	duration = 45.0
	time_left = duration
	items.clear()
	combo = 0
	best_combo = 0
	spawn_clock = 0.25
	tray_x = 320.0

func _tick(delta: float) -> void:
	tray_x = clampf(tray_x + Input.get_axis("ui_left", "ui_right") * delta * 530.0, 65, 575)
	spawn_clock -= delta
	if spawn_clock <= 0.0:
		spawn_clock = maxf(0.37, 0.8 - elapsed * 0.008)
		var roll = rng.randi_range(0, 9)
		var kind = 3 if roll < 2 else (1 if roll == 2 else (2 if roll < 5 else 0))
		items.append({"x": rng.randf_range(45, 595), "y": -35.0, "kind": kind, "speed": rng.randf_range(190, 245) + elapsed * 2.2})
	for index in range(items.size() - 1, -1, -1):
		var item = items[index]
		item.y += item.speed * delta
		if item.y > 690.0 and item.y < 765.0 and absf(item.x - tray_x) < 70.0:
			catch_kind(item.kind)
			items.remove_at(index)
		elif item.y > 850:
			if item.kind != 3:
				combo = 0
			items.remove_at(index)
	status = "%s %d   ·   %s %d" % [tx("Combo"), combo, tx("Best streak"), best_combo]

func catch_kind(kind: int) -> void:
	if not running:
		return
	if kind == 3:
		score = maxi(0, score - 10)
		combo = 0
		feedback("Bad chip!", "lose")
	else:
		score += [10, 25, 15][clampi(kind, 0, 2)]
		combo += 1
		best_combo = maxi(best_combo, combo)
		if combo % 5 == 0:
			score += 20
			feedback("Combo +20", "coin")
		else:
			feedback("Nice catch!", "beep")

func _winning() -> bool:
	return score >= 120

func _gui_input(event: InputEvent) -> void:
	if not running:
		return
	if event is InputEventScreenTouch:
		dragging = event.pressed
		tray_x = clampf(point(event.position).x, 65, 575)
	elif event is InputEventScreenDrag:
		tray_x = clampf(point(event.position).x, 65, 575)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.device != -1:
		dragging = event.pressed
		tray_x = clampf(point(event.position).x, 65, 575)
	elif event is InputEventMouseMotion and dragging and event.device != -1:
		tray_x = clampf(point(event.position).x, 65, 575)

func _draw() -> void:
	drawing()
	for x in range(20, 650, 80):
		draw_line(Vector2(x, 20), Vector2(x, 650), Color("eeebe4"), 2)
	card(Rect2(28, 680, 584, 150), Color("e6eee5"), 28)
	for item in items:
		draw_chip(Vector2(item.x, item.y), COLORS[item.kind])
	draw_duck(Vector2(tray_x, 740), 0.92)
	card(Rect2(tray_x - 72, 705, 144, 34), AQUA, 15, Color("76bdc7"))
	draw_line(Vector2(tray_x - 60, 706), Vector2(tray_x + 60, 706), Color.WHITE, 4)
	text_at(tx("Drag to catch"), Vector2(320, 838), 20, Color("747870"))
	draw_feedback()
