extends "res://scripts/minigames/GameBoard.gd"
var slots: Array[int] = [0, 1, 2]
var gear_box: int = 0
var round_number: int = 1
var found: int = 0
var phase: String = "reveal"
var phase_clock: float = 1.8
var swaps_left: int = 3
var swap_a: int = 0
var swap_b: int = 1
var swap_progress: float = 0.0
var swap_duration: float = 0.7
var swapping: bool = false
var selected_slot: int = -1
var answer_clock: float = 12.0

func _reset() -> void:
	duration = 150.0
	time_left = duration
	round_number = 1
	found = 0
	begin_round()

func begin_round() -> void:
	slots = [0, 1, 2]
	gear_box = rng.randi_range(0, 2)
	phase = "reveal"
	phase_clock = 1.8
	swaps_left = 2 + round_number
	swapping = false
	selected_slot = -1
	answer_clock = 12.0
	swap_duration = maxf(0.38, 0.86 - round_number * 0.08)

func _tick(delta: float) -> void:
	phase_clock -= delta
	if phase == "reveal" and phase_clock <= 0:
		phase = "shuffle"
		start_swap()
	elif phase == "shuffle":
		if swapping:
			swap_progress += delta / swap_duration
			if swap_progress >= 1.0:
				apply_swap(swap_a, swap_b)
				swapping = false
				swaps_left -= 1
				phase_clock = 0.18
		elif phase_clock <= 0:
			if swaps_left > 0:
				start_swap()
			else:
				phase = "choose"
	elif phase == "choose":
		answer_clock -= delta
		if answer_clock <= 0:
			selected_slot = -1
			phase = "result"
			phase_clock = 1.2
			feedback("Time is up", "lose")
	elif phase == "result" and phase_clock <= 0:
		if round_number == 5:
			finish(found >= 3)
		else:
			round_number += 1
			begin_round()
	status = "%s %d / 5   ·   %s %d" % [tx("Round"), round_number, tx("Treasures"), found]

func start_swap() -> void:
	swap_a = rng.randi_range(0, 2)
	swap_b = (swap_a + rng.randi_range(1, 2)) % 3
	swap_progress = 0.0
	swapping = true

func apply_swap(a: int, b: int) -> void:
	var first: int = slots[a]
	slots[a] = slots[b]
	slots[b] = first

func choose(slot: int) -> bool:
	if not running or phase != "choose" or slot < 0 or slot > 2:
		return false
	selected_slot = slot
	var success: bool = slots[slot] == gear_box
	phase = "result"
	phase_clock = 1.6
	if success:
		found += 1
		score += 60 + 10 * round_number
		feedback("Treasure found!", "coin")
	else:
		feedback("Watch this box next time", "lose")
	return success

func box_position(identity: int) -> Vector2:
	var slot: int = slots.find(identity)
	var x: float = 115 + slot * 205
	var y: float = 435
	if swapping and (slot == swap_a or slot == swap_b):
		var destination: int = swap_b if slot == swap_a else swap_a
		var t: float = smoothstep(0, 1, clampf(swap_progress, 0, 1))
		x = lerpf(x, 115 + destination * 205, t)
		y += sin(t * PI) * (-67 if slot == swap_a else 67)
	return Vector2(x, y)

func _winning() -> bool:
	return round_number >= 5 and found >= 3

func press_at(pos: Vector2) -> void:
	for i in range(3):
		if Rect2(30 + i * 205, 330, 170, 225).has_point(pos):
			choose(i)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch and event.pressed:
		press_at(point(event.position))
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed and event.device != -1:
		press_at(point(event.position))

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		var keys = [KEY_1, KEY_2, KEY_3]
		if keys.has(event.keycode):
			choose(keys.find(event.keycode))

func draw_gear(center: Vector2) -> void:
	for i in range(8):
		var angle: float = i * TAU / 8
		var offset = Vector2(cos(angle), sin(angle)) * 29
		draw_circle(center + offset, 11, YELLOW)
	draw_circle(center, 33, YELLOW)
	draw_circle(center, 14, Color("a57f32"))
	draw_circle(center + Vector2(-10, -12), 6, Color("fff0a5"))

func _draw() -> void:
	drawing()
	card(Rect2(16, 545, 608, 35), Color("d5c6b0"), 16)
	var hint: String = "Remember the gear" if phase == "reveal" else ("Follow the boxes" if phase == "shuffle" else "Choose a box")
	text_at(tx(hint), Vector2(320, 180), 27)
	for identity in range(3):
		var center = box_position(identity)
		var is_revealed: bool = (phase == "reveal" or phase == "result") and identity == gear_box
		var color = LAVENDER
		if phase == "result" and selected_slot >= 0 and slots[selected_slot] == identity:
			color = MINT if identity == gear_box else Color("ef8f94")
		card(Rect2(center + Vector2(-83, -37), Vector2(166, 140)), color.darkened(0.12), 19)
		card(Rect2(center + Vector2(-89, -55 if not is_revealed else -110), Vector2(178, 42)), color.lightened(0.14), 13)
		card(Rect2(center + Vector2(-10, -35), Vector2(20, 137)), YELLOW, 3)
		if is_revealed:
			draw_gear(center + Vector2(0, -39))
	for slot in range(3):
		text_at(str(slot + 1), Vector2(115 + slot * 205, 615), 25, Color("747870"))
	draw_duck(Vector2(320, 770), 0.7)
	draw_feedback()
