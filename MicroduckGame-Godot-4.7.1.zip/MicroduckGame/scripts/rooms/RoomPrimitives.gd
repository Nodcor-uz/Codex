extends RefCounted
## Original low-poly beveled geometry, shared between room builders.

static var _mesh_cache: Dictionary = {}
static var _material_cache: Dictionary = {}

static func material(color: Color, metal: float = 0.0, rough: float = 0.72, emission: float = 0.0) -> StandardMaterial3D:
	var key = str(color) + str(metal) + str(rough) + str(emission)
	if _material_cache.has(key):
		return _material_cache[key]
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.metallic = metal
	mat.roughness = rough
	if color.a < 1.0:
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	if emission > 0.0:
		mat.emission_enabled = true
		mat.emission = color
		mat.emission_energy_multiplier = emission
	_material_cache[key] = mat
	return mat

static func rounded_mesh(size: Vector3, radius: float = 0.08) -> Mesh:
	var key = str(size) + ":" + str(radius)
	if _mesh_cache.has(key):
		return _mesh_cache[key]
	# Subpixel bevels use a 12-triangle box; visible furniture retains smooth bevels.
	if radius < 0.027:
		var simple = BoxMesh.new()
		simple.size = size
		_mesh_cache[key] = simple
		return simple
	var half = size * 0.5
	var rad = minf(radius, minf(half.x, minf(half.y, half.z)) * 0.95)
	var inner = half - Vector3.ONE * rad
	var vertices = PackedVector3Array()
	var normals = PackedVector3Array()
	var indices = PackedInt32Array()
	# Six face planes with edge subdivisions make smooth, visibly rounded corners.
	var normals_axis = [Vector3.RIGHT, Vector3.LEFT, Vector3.UP, Vector3.DOWN, Vector3.BACK, Vector3.FORWARD]
	var axis_u = [Vector3.FORWARD, Vector3.BACK, Vector3.RIGHT, Vector3.RIGHT, Vector3.RIGHT, Vector3.LEFT]
	var axis_v = [Vector3.UP, Vector3.UP, Vector3.FORWARD, Vector3.BACK, Vector3.UP, Vector3.UP]
	for face in range(6):
		var n: Vector3 = normals_axis[face]
		var u: Vector3 = axis_u[face]
		var v: Vector3 = axis_v[face]
		var n_extent = absf(n.dot(half))
		var u_extent = absf(u.dot(half))
		var v_extent = absf(v.dot(half))
		var us = [-u_extent, -u_extent + rad * 0.30, -u_extent + rad, u_extent - rad, u_extent - rad * 0.30, u_extent]
		var vs = [-v_extent, -v_extent + rad * 0.30, -v_extent + rad, v_extent - rad, v_extent - rad * 0.30, v_extent]
		var offset = vertices.size()
		for iy in range(6):
			for ix in range(6):
				var point = n * n_extent + u * us[ix] + v * vs[iy]
				var nearest = Vector3(clampf(point.x, -inner.x, inner.x), clampf(point.y, -inner.y, inner.y), clampf(point.z, -inner.z, inner.z))
				var normal = (point - nearest).normalized()
				vertices.append(nearest + normal * rad)
				normals.append(normal)
		for iy in range(5):
			for ix in range(5):
				var a = offset + iy * 6 + ix
				# Clockwise winding, as expected by Godot's front faces.
				indices.append_array([a, a + 6, a + 1, a + 1, a + 6, a + 7])
	var arrays = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_INDEX] = indices
	var mesh = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	_mesh_cache[key] = mesh
	return mesh

static func box(parent: Node3D, title: String, size: Vector3, pos: Vector3, color: Color, radius: float = 0.06, metal: float = 0.0) -> MeshInstance3D:
	var obj = MeshInstance3D.new()
	obj.name = title
	obj.mesh = rounded_mesh(size, radius)
	obj.material_override = material(color, metal)
	obj.position = pos
	parent.add_child(obj)
	return obj

static func sphere(parent: Node3D, title: String, size: Vector3, pos: Vector3, color: Color) -> MeshInstance3D:
	var obj = MeshInstance3D.new()
	obj.name = title
	var mesh = SphereMesh.new()
	mesh.radius = 0.5
	mesh.height = 1.0
	mesh.radial_segments = 16
	mesh.rings = 8
	obj.mesh = mesh
	obj.scale = size
	obj.material_override = material(color)
	obj.position = pos
	parent.add_child(obj)
	return obj

static func cylinder(parent: Node3D, title: String, radius: float, height: float, pos: Vector3, color: Color, top_radius: float = -1.0) -> MeshInstance3D:
	var obj = MeshInstance3D.new()
	obj.name = title
	var mesh = CylinderMesh.new()
	mesh.top_radius = radius if top_radius < 0.0 else top_radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 32
	obj.mesh = mesh
	obj.material_override = material(color)
	obj.position = pos
	parent.add_child(obj)
	return obj

static func ring(parent: Node3D, title: String, inner: float, outer: float, pos: Vector3, color: Color) -> MeshInstance3D:
	var obj = MeshInstance3D.new()
	obj.name = title
	var mesh = TorusMesh.new()
	mesh.inner_radius = inner
	mesh.outer_radius = outer
	mesh.rings = 32
	mesh.ring_segments = 8
	obj.mesh = mesh
	obj.material_override = material(color)
	obj.position = pos
	parent.add_child(obj)
	return obj

static func rod(parent: Node3D, title: String, a: Vector3, b: Vector3, radius: float, color: Color) -> MeshInstance3D:
	var node = cylinder(parent, title, radius, a.distance_to(b), (a + b) * 0.5, color)
	var axis = (b - a).normalized()
	var right = axis.cross(Vector3.FORWARD)
	if right.length() < 0.001:
		right = axis.cross(Vector3.RIGHT)
	right = right.normalized()
	node.basis = Basis(right, axis, right.cross(axis).normalized())
	return node

static func group(parent: Node3D, title: String, pos: Vector3 = Vector3.ZERO) -> Node3D:
	var node = Node3D.new()
	node.name = title
	node.position = pos
	parent.add_child(node)
	return node

static func hit(parent: Node3D, title: String, size: Vector3, pos: Vector3, interaction: String) -> Area3D:
	var area = Area3D.new()
	area.name = title
	area.collision_layer = 2
	area.collision_mask = 0
	area.input_ray_pickable = true
	area.set_meta("interaction", interaction)
	area.add_to_group("room_interaction")
	var shape = CollisionShape3D.new()
	var box_shape = BoxShape3D.new()
	box_shape.size = size
	shape.shape = box_shape
	area.add_child(shape)
	area.position = pos
	parent.add_child(area)
	return area
