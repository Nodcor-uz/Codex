extends Node3D
## Seven original miniature interiors. All scenery is real reusable 3D geometry.
const G = preload("res://scripts/rooms/RoomPrimitives.gd")
const CREAM = Color("f6f0e7")
const WHITE = Color("fffaf2")
const ORANGE = Color("ff833f")
const AQUA = Color("9adfe8")
const LAVENDER = Color("b4a1e1")
const MINT = Color("a9e2c1")
const GRAPHITE = Color("33343b")
const WOOD = Color("d8a877")
const YELLOW = Color("ffd45e")

@export_enum("living", "kitchen", "bedroom", "bathroom", "games", "workshop", "garden") var room_id: String = "living"
var _content: Node3D
var _rug: MeshInstance3D
var _sky_material: StandardMaterial3D
var _window_sun: Node3D
var _window_moon: Node3D
var _window_stars: Node3D
var _extra_plant: Node3D
var _lamps: Array = []
var _bubbles: Array = []
var _clock_hand: Node3D
var _time: float = 0.0
var _night: bool = false
var _anchors: Dictionary = {}
var _filter_lid: Node3D
var _filter_animation: float = 0.0
var _furniture: Dictionary = {}

func _ready() -> void:
	build(room_id)

func build(kind: String) -> void:
	room_id = kind
	if is_instance_valid(_content):
		remove_child(_content)
		_content.queue_free()
	_content = G.group(self, "Interior")
	_rug = null
	_sky_material = null
	_window_sun = null
	_window_moon = null
	_window_stars = null
	_clock_hand = null
	_filter_lid = null
	_lamps.clear()
	_bubbles.clear()
	_anchors = {"home": Vector3.ZERO, "sleep": Vector3(-0.65, 0.38, -1.2), "charge": Vector3(0.95, 0.08, -0.4), "wash": Vector3.ZERO, "filter": Vector3(1.45, 0.0, -0.9)}
	match kind:
		"living": _living()
		"kitchen": _kitchen()
		"bedroom": _bedroom()
		"bathroom": _bathroom()
		"games": _games()
		"workshop": _workshop()
		"garden": _garden()
		_: _living()
	_extra_plant = _plant(_content, Vector3(2.0, 0.0, 1.4), 0.7, ORANGE)
	_extra_plant.name = "PurchasedPlant"
	_extra_plant.visible = false
	decorate(_furniture)
	set_night(_night)

func get_anchor(anchor_name: String) -> Vector3:
	return to_global(_anchors.get(anchor_name, Vector3.ZERO))

func decorate(choices: Dictionary) -> void:
	_furniture = choices.duplicate(true)
	var values = choices.values()
	var rug_color = Color("e7b77a")
	if room_id == "bedroom": rug_color = Color("c2b6e0")
	if room_id == "bathroom": rug_color = Color("afe2dd")
	if room_id == "games": rug_color = Color("b4a1e1")
	if room_id == "workshop": rug_color = Color("a8c7ca")
	if values.has("rug_mint") or choices.has("rug_mint"): rug_color = MINT
	if values.has("rug_lavender") or choices.has("rug_lavender"): rug_color = LAVENDER
	if is_instance_valid(_rug):
		_rug.material_override = G.material(rug_color)
	if is_instance_valid(_extra_plant):
		_extra_plant.visible = values.has("plant") or choices.has("plant")
	for light in _lamps:
		light.light_color = ORANGE if values.has("lamp_sunset") or choices.has("lamp_sunset") else YELLOW

func set_night(value: bool) -> void:
	_night = value
	if _sky_material:
		_sky_material.albedo_color = Color("314967") if value else Color("b6e6ed")
		_sky_material.emission = Color("314967") if value else Color("b6e6ed")
	if is_instance_valid(_window_sun): _window_sun.visible = not value
	if is_instance_valid(_window_moon): _window_moon.visible = value
	if is_instance_valid(_window_stars): _window_stars.visible = value
	for lamp in _lamps:
		lamp.light_energy = 0.55 if value else 0.22

func play_interaction(action: String) -> void:
	if action == "filter" and is_instance_valid(_filter_lid):
		_filter_animation = 3.5

func _process(delta: float) -> void:
	_time += delta
	if is_instance_valid(_clock_hand): _clock_hand.rotation.z = -_time * 0.055
	for i in range(_bubbles.size()):
		var bubble: Node3D = _bubbles[i]
		bubble.position.y = float(bubble.get_meta("base_y")) + sin(_time * 0.8 + i) * 0.07
	if is_instance_valid(_filter_lid):
		_filter_animation = maxf(0.0, _filter_animation - delta)
		_filter_lid.rotation.x = lerpf(_filter_lid.rotation.x, -1.35 if _filter_animation > 2.5 else 0.0, delta * 5.0)

func _shell(wall_color: Color, tile: bool = false) -> void:
	G.box(_content, "Foundation", Vector3(10.0, 0.18, 11.0), Vector3(0, -0.16, 0), Color("b98a61"), 0.02)
	if tile:
		for x in range(-6, 7):
			for z in range(-4, 7):
				G.box(_content, "CeramicTile", Vector3(0.73, 0.05, 0.73), Vector3(x * 0.75, -0.04, z * 0.75), WHITE if (x + z) % 2 == 0 else Color("e9e8dc"), 0.015)
	else:
		for z in range(-7, 10):
			for x in range(-2, 3):
				var shift = 0.6 if z % 2 == 0 else 0.0
				var color = WOOD.lightened(float(posmod(x * 7 + z * 3, 5)) * 0.022)
				G.box(_content, "OakFloorboard", Vector3(2.25, 0.06, 0.54), Vector3(x * 2.27 + shift, -0.03, z * 0.56), color, 0.015)
	G.box(_content, "BackWall", Vector3(9.0, 6.2, 0.22), Vector3(0, 3.0, -3.6), wall_color, 0.03)
	G.box(_content, "LeftWall", Vector3(0.18, 6.2, 8.0), Vector3(-4.5, 3.0, 0.4), wall_color.darkened(0.035), 0.02)
	G.box(_content, "RightWall", Vector3(0.18, 6.2, 8.0), Vector3(4.5, 3.0, 0.4), wall_color.lightened(0.02), 0.02)
	G.box(_content, "Skirting", Vector3(9.0, 0.2, 0.09), Vector3(0, 0.1, -3.44), WHITE, 0.02)
	G.box(_content, "WallRail", Vector3(9.0, 0.06, 0.07), Vector3(0, 1.48, -3.44), wall_color.lightened(0.19), 0.02)
	for x in range(-7, 8):
		G.box(_content, "WallPanelling", Vector3(0.028, 1.28, 0.04), Vector3(x * 0.6, 0.78, -3.45), wall_color.lightened(0.13), 0.008)

func _round_rug(color: Color, radius: float = 1.8) -> void:
	G.cylinder(_content, "RugBinding", radius + 0.05, 0.024, Vector3(0, 0.015, 0.15), WHITE)
	_rug = G.cylinder(_content, "WovenRug", radius, 0.03, Vector3(0, 0.032, 0.15), color)
	for i in range(3):
		var ring = G.ring(_content, "RugStitch", radius - 0.13 - i * 0.065, radius - 0.115 - i * 0.065, Vector3(0, 0.048, 0.15), color.lightened(0.2))
		ring.scale.y = 0.15

func _window(pos: Vector3, size: Vector2 = Vector2(2.55, 2.3)) -> void:
	var root = G.group(_content, "SunroomWindow", pos)
	G.box(root, "OuterWindowFrame", Vector3(size.x + 0.2, size.y + 0.2, 0.16), Vector3.ZERO, Color("e9c597"), 0.24)
	G.box(root, "IvoryWindowFrame", Vector3(size.x + 0.08, size.y + 0.08, 0.18), Vector3(0, 0, 0.06), WHITE, 0.22)
	var sky = G.box(root, "SkyGlass", Vector3(size.x - 0.1, size.y - 0.1, 0.05), Vector3(0, 0, 0.17), Color("b6e6ed"), 0.2)
	_sky_material = G.material(Color("b6e6ed"), 0.0, 0.4, 0.16).duplicate()
	_sky_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sky.material_override = _sky_material
	sky.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	G.box(root, "WindowMullion", Vector3(0.055, size.y - 0.1, 0.09), Vector3(0, 0, 0.24), WHITE, 0.02)
	G.box(root, "WindowCrossbar", Vector3(size.x - 0.1, 0.055, 0.09), Vector3(0, -0.18, 0.24), WHITE, 0.02)
	G.box(root, "DeepWindowSill", Vector3(size.x + 0.3, 0.13, 0.48), Vector3(0, -size.y * 0.5, 0.16), WHITE, 0.06)
	_window_sun = G.group(root, "Daylight")
	var sun = G.cylinder(_window_sun, "Sun", 0.24, 0.035, Vector3(0.65, 0.58, 0.22), YELLOW)
	sun.rotation.x = PI * 0.5
	for j in range(3):
		G.sphere(_window_sun, "Cloud", Vector3(0.43 + j * 0.08, 0.21, 0.08), Vector3(-0.65 + j * 0.18, 0.48 + sin(j) * 0.045, 0.22), Color("f0ffff"))
	G.sphere(_window_sun, "DistantHill", Vector3(size.x * 0.8, 0.6, 0.06), Vector3(-0.12, -size.y * 0.5 + 0.32, 0.21), Color("a5d7b6"))
	G.sphere(_window_sun, "DistantHill", Vector3(size.x * 0.48, 0.42, 0.06), Vector3(size.x * 0.22, -size.y * 0.5 + 0.23, 0.23), Color("85c6a6"))
	_window_moon = G.group(root, "Moonlight")
	var moon = G.cylinder(_window_moon, "Moon", 0.23, 0.03, Vector3(0.62, 0.55, 0.23), Color("fff2c6"))
	moon.rotation.x = PI * 0.5
	var cutout = G.cylinder(_window_moon, "CrescentCutout", 0.20, 0.035, Vector3(0.73, 0.62, 0.26), Color("314967"))
	cutout.rotation.x = PI * 0.5
	_window_stars = G.group(root, "Stars")
	for i in range(12):
		var px = sin(i * 4.6) * size.x * 0.4
		var py = cos(i * 2.9) * size.y * 0.39
		G.sphere(_window_stars, "Star", Vector3.ONE * (0.025 if i % 2 == 0 else 0.04), Vector3(px, py, 0.27), Color("fff2c6"))

func _plant(parent: Node3D, pos: Vector3, scale_factor: float = 1.0, pot_color: Color = CREAM) -> Node3D:
	var root = G.group(parent, "IndoorPlant", pos)
	root.scale = Vector3.ONE * scale_factor
	G.cylinder(root, "Pot", 0.27, 0.44, Vector3(0, 0.22, 0), pot_color, 0.33)
	G.ring(root, "PotLip", 0.28, 0.34, Vector3(0, 0.44, 0), pot_color)
	G.cylinder(root, "Soil", 0.27, 0.035, Vector3(0, 0.43, 0), Color("695448"))
	G.rod(root, "Stem", Vector3(0, 0.42, 0), Vector3(0.05, 1.18, 0), 0.028, Color("71976b"))
	for i in range(7):
		var angle = i * 2.4
		var yy = 0.60 + i * 0.09
		var end = Vector3(cos(angle) * 0.3, yy + 0.24, sin(angle) * 0.24)
		G.rod(root, "Branch", Vector3(0, yy, 0), end, 0.012, Color("71976b"))
		var leaf = G.sphere(root, "SatinLeaf", Vector3(0.19, 0.46, 0.1), end, Color("82b88b") if i % 2 == 0 else Color("a1d4a4"))
		leaf.rotation = Vector3(sin(angle) * 0.7, angle, -cos(angle) * 0.7)
	return root

func _floor_lamp(pos: Vector3, shade_color: Color = ORANGE) -> Node3D:
	var root = G.group(_content, "ReadingLamp", pos)
	G.cylinder(root, "LampFoot", 0.31, 0.08, Vector3(0, 0.04, 0), GRAPHITE)
	G.cylinder(root, "LampStem", 0.027, 1.86, Vector3(0, 0.99, 0), Color("bc9b67"))
	G.cylinder(root, "FabricShade", 0.44, 0.43, Vector3(0, 2.02, 0), shade_color, 0.27)
	G.cylinder(root, "LampGlow", 0.37, 0.02, Vector3(0, 1.81, 0), Color("ffedc0"))
	var lamp = OmniLight3D.new()
	lamp.name = "WarmLamp"
	lamp.position = Vector3(0, 1.78, 0)
	lamp.light_color = YELLOW
	lamp.light_energy = 0.22
	lamp.omni_range = 2.5
	lamp.shadow_enabled = false
	root.add_child(lamp)
	_lamps.append(lamp)
	G.hit(root, "LampTouch", Vector3(0.9, 0.8, 0.9), Vector3(0, 1.9, 0), "lamp")
	return root

func _books(parent: Node3D, pos: Vector3, count: int = 5) -> void:
	var colors = [ORANGE, AQUA, LAVENDER, YELLOW, MINT, Color("ddab94")]
	for i in range(count):
		var h = 0.30 + float(i % 3) * 0.07
		var book = G.box(parent, "Book", Vector3(0.10, h, 0.23), pos + Vector3(i * 0.115, h * 0.5, 0), colors[i % colors.size()], 0.015)
		if i == count - 1: book.rotation.z = -0.13
		G.box(parent, "BookSpine", Vector3(0.065, 0.018, 0.012), pos + Vector3(i * 0.115, h - 0.07, 0.12), WHITE, 0.003)

func _wall_art(pos: Vector3, color: Color, size: Vector2 = Vector2(0.9, 1.15)) -> void:
	var art = G.group(_content, "FramedBotanicalPrint", pos)
	G.box(art, "Frame", Vector3(size.x, size.y, 0.09), Vector3.ZERO, Color("ca9869"), 0.06)
	G.box(art, "Canvas", Vector3(size.x - 0.12, size.y - 0.12, 0.035), Vector3(0, 0, 0.06), WHITE, 0.03)
	G.sphere(art, "AbstractCircle", Vector3(size.x * 0.52, size.x * 0.52, 0.025), Vector3(0.05, 0.12, 0.085), color)
	G.box(art, "PrintStem", Vector3(0.025, size.y * 0.58, 0.02), Vector3(-0.07, -0.09, 0.105), GRAPHITE, 0.01)
	for j in range(3):
		var leaf = G.sphere(art, "PrintLeaf", Vector3(size.x * 0.24, 0.09, 0.02), Vector3(-0.12 if j % 2 == 0 else 0.04, -0.21 + j * 0.15, 0.11), Color("658979"))
		leaf.rotation.z = 0.5 if j % 2 == 0 else -0.5

func _clock(pos: Vector3, color: Color = CREAM) -> void:
	var root = G.group(_content, "WallClock", pos)
	var rim = G.cylinder(root, "ClockCase", 0.37, 0.09, Vector3.ZERO, color)
	rim.rotation.x = PI * 0.5
	var face = G.cylinder(root, "ClockFace", 0.32, 0.035, Vector3(0, 0, 0.065), WHITE)
	face.rotation.x = PI * 0.5
	for i in range(12):
		var a = i * TAU / 12.0
		G.sphere(root, "HourMark", Vector3.ONE * 0.025, Vector3(sin(a) * 0.26, cos(a) * 0.26, 0.09), GRAPHITE)
	_clock_hand = G.group(root, "MinuteHand", Vector3(0, 0, 0.10))
	G.box(_clock_hand, "MinuteNeedle", Vector3(0.023, 0.25, 0.02), Vector3(0, 0.11, 0), GRAPHITE, 0.008)
	var hour = G.box(root, "HourNeedle", Vector3(0.023, 0.18, 0.02), Vector3(0.06, 0.035, 0.11), ORANGE, 0.008)
	hour.rotation.z = -1.05

func _ball(parent: Node3D, pos: Vector3, size_factor: float = 1.0) -> Node3D:
	var root = G.group(parent, "PlayBall", pos)
	root.scale = Vector3.ONE * size_factor
	G.sphere(root, "SoftBall", Vector3.ONE * 0.44, Vector3(0, 0.23, 0), ORANGE)
	var stripe = G.ring(root, "BallStripe", 0.204, 0.225, Vector3(0, 0.23, 0), WHITE)
	stripe.rotation.z = 0.65
	G.hit(root, "BallTouch", Vector3.ONE * 0.65, Vector3(0, 0.24, 0), "ball")
	return root

func _rubber_duck(parent: Node3D, pos: Vector3) -> void:
	var root = G.group(parent, "RubberDuck", pos)
	G.sphere(root, "DuckBody", Vector3(0.33, 0.24, 0.4), Vector3(0, 0.12, 0), YELLOW)
	G.sphere(root, "DuckHead", Vector3.ONE * 0.22, Vector3(0, 0.28, 0.10), YELLOW)
	G.box(root, "DuckBeak", Vector3(0.15, 0.045, 0.16), Vector3(0, 0.25, 0.22), ORANGE, 0.02)
	for x in [-1, 1]: G.sphere(root, "DuckEye", Vector3.ONE * 0.024, Vector3(x * 0.08, 0.30, 0.18), GRAPHITE)
	G.hit(root, "DuckTouch", Vector3(0.5, 0.5, 0.6), Vector3(0, 0.2, 0), "duck")

func _dock(pos: Vector3, compact: bool = false) -> void:
	var dock = G.group(_content, "ChargingStation", pos)
	var radius = 0.51 if compact else 0.75
	G.cylinder(dock, "DockBase", radius, 0.10, Vector3(0, 0.05, 0), GRAPHITE)
	G.cylinder(dock, "DockTop", radius * 0.93, 0.06, Vector3(0, 0.11, 0), Color("e4e9e3"))
	var rim = G.ring(dock, "EnergyRing", radius * 0.78, radius * 0.82, Vector3(0, 0.15, 0), AQUA)
	rim.scale.y = 0.3
	rim.material_override = G.material(AQUA, 0.0, 0.3, 0.3)
	for x in [-1, 1]:
		G.box(dock, "ChargingContact", Vector3(0.16, 0.035, 0.24), Vector3(x * 0.23, 0.15, -0.05), Color("c5b15e"), 0.02, 0.65)
	G.box(dock, "ChargePylon", Vector3(0.21, 0.46, 0.18), Vector3(0, 0.26, -radius * 0.8), CREAM, 0.05)
	for i in range(3): G.box(dock, "ChargeIndicator", Vector3(0.09, 0.035, 0.015), Vector3(0, 0.23 + i * 0.07, -radius * 0.8 + 0.1), MINT, 0.008)
	G.hit(dock, "DockTouch", Vector3(radius * 2, 0.5, radius * 2), Vector3(0, 0.2, 0), "charge")

func _living() -> void:
	_shell(Color("b9dcd5"))
	_round_rug(Color("e7b77a"))
	_window(Vector3(-0.9, 3.55, -3.35), Vector2(2.35, 2.3))
	# Low, rounded sofa behind the pet, softened with contrasting cushions.
	var sofa = G.group(_content, "CloudSofa", Vector3(-1.45, 0, -2.25))
	for x in [-0.95, 0.95]:
		for z in [-0.35, 0.35]: G.cylinder(sofa, "OakLeg", 0.055, 0.27, Vector3(x, 0.135, z), WOOD)
	G.box(sofa, "SofaBase", Vector3(2.5, 0.38, 1.1), Vector3(0, 0.4, 0), Color("e99d6b"), 0.18)
	G.box(sofa, "SofaBack", Vector3(2.5, 0.9, 0.3), Vector3(0, 0.95, -0.4), Color("eeac7b"), 0.14)
	for x in [-1.14, 1.14]: G.box(sofa, "RolledArm", Vector3(0.30, 0.63, 1.12), Vector3(x, 0.65, 0), Color("eeac7b"), 0.14)
	for x in [-0.53, 0.53]: G.box(sofa, "SeatCushion", Vector3(1.0, 0.18, 0.85), Vector3(x, 0.64, 0.05), Color("ffd1a1"), 0.085)
	var pillow = G.box(sofa, "MintPillow", Vector3(0.55, 0.55, 0.16), Vector3(-0.65, 0.97, -0.18), MINT, 0.14)
	pillow.rotation.z = 0.17
	pillow = G.box(sofa, "CreamPillow", Vector3(0.46, 0.43, 0.17), Vector3(0.64, 0.94, -0.18), WHITE, 0.13)
	pillow.rotation.z = -0.13
	_floor_lamp(Vector3(-2.83, 0, -1.8), CREAM)
	# Open storage with books, tiny ceramic pieces and a radio.
	var shelf = G.group(_content, "OakBookcase", Vector3(2.03, 0, -2.8))
	for x in [-0.52, 0.52]: G.box(shelf, "SideRail", Vector3(0.07, 2.35, 0.48), Vector3(x, 1.2, 0), WOOD, 0.025)
	for y in [0.16, 0.83, 1.5, 2.17]: G.box(shelf, "ShelfBoard", Vector3(1.12, 0.065, 0.49), Vector3(0, y, 0), WOOD, 0.02)
	_books(shelf, Vector3(-0.4, 0.86, 0.02), 6)
	_books(shelf, Vector3(-0.4, 0.20, 0.02), 4)
	G.cylinder(shelf, "CeramicVase", 0.13, 0.35, Vector3(0.28, 1.71, 0), AQUA, 0.07)
	G.sphere(shelf, "LittleSculpture", Vector3.ONE * 0.22, Vector3(-0.25, 1.64, 0), ORANGE)
	_plant(_content, Vector3(2.1, 0, -0.3), 1.15, WHITE)
	_wall_art(Vector3(1.65, 3.38, -3.36), ORANGE)
	_clock(Vector3(3.02, 3.65, -3.36), Color("e2b486"))
	var table = G.group(_content, "CoffeeTable", Vector3(-2.0, 0, 0.6))
	G.cylinder(table, "PebbleTabletop", 0.62, 0.09, Vector3(0, 0.57, 0), CREAM)
	for x in [-0.31, 0.31]: G.rod(table, "TableLeg", Vector3(x * 1.15, 0.04, -0.15), Vector3(x, 0.53, -0.1), 0.04, WOOD)
	G.rod(table, "TableLeg", Vector3(0, 0.04, 0.36), Vector3(0, 0.53, 0.28), 0.04, WOOD)
	G.box(table, "Magazine", Vector3(0.38, 0.025, 0.28), Vector3(0, 0.63, 0), AQUA, 0.01)
	G.cylinder(table, "TeaMug", 0.09, 0.14, Vector3(0.22, 0.7, -0.12), ORANGE)
	_ball(_content, Vector3(1.35, 0, 0.9))
	_dock(Vector3(2.0, 0, -1.65), true)

func _kitchen() -> void:
	_shell(Color("f2dfc2"), true)
	_round_rug(Color("e9c18f"), 1.55)
	_window(Vector3(-0.75, 3.42, -3.35), Vector2(1.95, 1.9))
	# A continuous worktop with individual framed cabinet fronts.
	G.box(_content, "CounterCarcass", Vector3(4.5, 1.2, 0.86), Vector3(-0.9, 0.64, -2.82), CREAM, 0.07)
	G.box(_content, "MarbleWorktop", Vector3(4.6, 0.12, 1.0), Vector3(-0.9, 1.31, -2.78), WHITE, 0.045)
	for i in range(5):
		var x = -2.7 + i * 0.88
		G.box(_content, "ShakerDoor", Vector3(0.81, 1.03, 0.065), Vector3(x, 0.67, -2.35), Color("c3d8ca"), 0.055)
		G.box(_content, "InsetCabinetPanel", Vector3(0.66, 0.79, 0.025), Vector3(x, 0.65, -2.31), Color("d5e5d5"), 0.03)
		G.box(_content, "BrassHandle", Vector3(0.22, 0.035, 0.055), Vector3(x, 1.0, -2.27), Color("b99665"), 0.015, 0.5)
	# Rounded retro fridge with two doors and a tiny robot magnet.
	var fridge = G.group(_content, "RetroRefrigerator", Vector3(2.0, 0, -2.65))
	G.box(fridge, "FridgeBody", Vector3(1.03, 2.6, 1.0), Vector3(0, 1.32, 0), AQUA, 0.15)
	G.box(fridge, "FreezerDoor", Vector3(0.95, 0.68, 0.12), Vector3(0, 2.2, 0.52), Color("bce9ec"), 0.09)
	G.box(fridge, "FridgeDoor", Vector3(0.95, 1.65, 0.12), Vector3(0, 0.99, 0.52), Color("bce9ec"), 0.09)
	for y in [1.49, 2.1]: G.box(fridge, "FridgeHandle", Vector3(0.055, 0.32, 0.08), Vector3(-0.32, y, 0.64), WHITE, 0.025)
	G.box(fridge, "OrangeMagnet", Vector3(0.18, 0.15, 0.025), Vector3(0.23, 1.45, 0.61), ORANGE, 0.045)
	# Sink and arched metallic tap.
	G.box(_content, "SinkRim", Vector3(0.8, 0.035, 0.6), Vector3(-1.4, 1.39, -2.75), Color("afbab5"), 0.15, 0.6)
	G.box(_content, "SinkBasin", Vector3(0.65, 0.015, 0.45), Vector3(-1.4, 1.41, -2.75), Color("6c9698"), 0.12)
	G.rod(_content, "TapStem", Vector3(-1.4, 1.38, -3.05), Vector3(-1.4, 1.83, -3.05), 0.035, Color("a4b6b1"))
	G.rod(_content, "TapSpout", Vector3(-1.4, 1.83, -3.05), Vector3(-1.4, 1.83, -2.78), 0.035, Color("a4b6b1"))
	G.box(_content, "InductionHob", Vector3(0.8, 0.045, 0.65), Vector3(0.6, 1.4, -2.72), GRAPHITE, 0.08)
	for x in [0.4, 0.82]: G.ring(_content, "CooktopRing", 0.12, 0.135, Vector3(x, 1.43, -2.72), Color("aab0ab"))
	G.cylinder(_content, "TeapotBody", 0.16, 0.26, Vector3(0.4, 1.58, -2.72), ORANGE, 0.13)
	G.ring(_content, "TeapotHandle", 0.12, 0.15, Vector3(0.4, 1.74, -2.72), GRAPHITE).rotation.x = PI * 0.5
	# Floating shelves, jars and cookbooks.
	G.box(_content, "FloatingShelf", Vector3(1.45, 0.08, 0.45), Vector3(1.45, 3.14, -3.15), WOOD, 0.025)
	for i in range(3):
		G.cylinder(_content, "PantryJar", 0.13, 0.34, Vector3(1.02 + i * 0.35, 3.35, -3.12), [ORANGE, MINT, LAVENDER][i])
		G.cylinder(_content, "JarLid", 0.14, 0.05, Vector3(1.02 + i * 0.35, 3.54, -3.12), CREAM)
	_plant(_content, Vector3(-2.9, 1.39, -2.9), 0.42, ORANGE)
	# Feeding trolley is deliberately low so the duck remains readable.
	var feeder = G.group(_content, "SmartFoodTrolley", Vector3(-1.8, 0, -0.2))
	G.box(feeder, "TrolleyBody", Vector3(0.78, 0.55, 0.68), Vector3(0, 0.34, 0), CREAM, 0.11)
	G.box(feeder, "OrangeFoodTray", Vector3(0.87, 0.08, 0.74), Vector3(0, 0.66, 0), ORANGE, 0.08)
	G.cylinder(feeder, "PorcelainPlate", 0.25, 0.035, Vector3(0, 0.72, 0), WHITE)
	for x in [-0.27, 0.27]:
		for z in [-0.23, 0.23]:
			var w = G.cylinder(feeder, "TrolleyWheel", 0.09, 0.05, Vector3(x, 0.11, z), GRAPHITE)
			w.rotation.z = PI * 0.5
	G.box(feeder, "FoodDisplay", Vector3(0.35, 0.13, 0.025), Vector3(0, 0.4, 0.36), GRAPHITE, 0.035)
	for i in range(3): G.sphere(feeder, "DisplayDot", Vector3.ONE * 0.035, Vector3(-0.1 + i * 0.1, 0.4, 0.38), MINT)
	G.hit(feeder, "FeedTouch", Vector3(1, 1, 1), Vector3(0, 0.4, 0), "food")
	_clock(Vector3(-2.7, 3.75, -3.35), ORANGE)

func _bedroom() -> void:
	_shell(Color("c5bddd"))
	_round_rug(Color("c2b6e0"), 1.7)
	_window(Vector3(0.7, 3.55, -3.35), Vector2(2.45, 2.2))
	# Plush sleeping pod: open front, raised rear bed and a curved padded headboard.
	var bed = G.group(_content, "DreamPod", Vector3(-0.65, 0, -1.45))
	G.box(bed, "BedFrame", Vector3(1.65, 0.30, 2.25), Vector3(0, 0.22, 0), Color("e9ddd9"), 0.14)
	G.box(bed, "Mattress", Vector3(1.53, 0.19, 2.1), Vector3(0, 0.45, 0), WHITE, 0.09)
	G.box(bed, "LavenderDuvet", Vector3(1.55, 0.12, 1.3), Vector3(0, 0.57, 0.31), Color("aebbe0"), 0.055)
	G.box(bed, "DuvetFold", Vector3(1.57, 0.13, 0.22), Vector3(0, 0.6, -0.25), Color("d4d9ef"), 0.05)
	G.box(bed, "CloudPillow", Vector3(1.05, 0.17, 0.49), Vector3(0, 0.61, -0.76), CREAM, 0.08)
	G.box(bed, "PaddedHeadboard", Vector3(1.78, 1.1, 0.23), Vector3(0, 0.88, -1.07), Color("a59bc4"), 0.1)
	for x in [-0.52, 0, 0.52]: G.sphere(bed, "UpholsteryButton", Vector3.ONE * 0.045, Vector3(x, 1.08, -0.93), LAVENDER)
	G.hit(bed, "BedTouch", Vector3(1.7, 1.3, 2.3), Vector3(0, 0.6, 0), "sleep")
	var stand = G.group(_content, "BedsideCabinet", Vector3(-2.03, 0, -2.1))
	G.box(stand, "Cabinet", Vector3(0.72, 0.72, 0.75), Vector3(0, 0.43, 0), WOOD, 0.08)
	G.box(stand, "Drawer", Vector3(0.61, 0.25, 0.04), Vector3(0, 0.59, 0.4), CREAM, 0.025)
	G.sphere(stand, "DrawerKnob", Vector3.ONE * 0.07, Vector3(0, 0.59, 0.45), ORANGE)
	_books(stand, Vector3(-0.2, 0.1, 0.1), 3)
	var lamp = _floor_lamp(Vector3(-2.03, 0.78, -2.1), Color("f1d6ad"))
	lamp.scale = Vector3.ONE * 0.46
	_dock(Vector3(1.25, 0, -0.85))
	_anchors["sleep"] = Vector3(-0.65, 0.55, -1.15)
	_anchors["charge"] = Vector3(1.25, 0.16, -0.85)
	_wall_art(Vector3(-2.35, 3.4, -3.35), LAVENDER, Vector2(0.85, 1.1))
	# Hanging mobile with small pastel planets.
	G.rod(_content, "MobileString", Vector3(-1.45, 4.8, -2.65), Vector3(-1.45, 4.25, -2.65), 0.009, CREAM)
	G.rod(_content, "MobileBar", Vector3(-1.92, 4.25, -2.65), Vector3(-0.98, 4.25, -2.65), 0.02, WOOD)
	for i in range(3):
		var x = -1.85 + i * 0.4
		G.rod(_content, "PlanetString", Vector3(x, 4.25, -2.65), Vector3(x, 3.9 - (i % 2) * 0.2, -2.65), 0.006, CREAM)
		G.sphere(_content, "Planet", Vector3.ONE * 0.16, Vector3(x, 3.87 - (i % 2) * 0.2, -2.65), [YELLOW, AQUA, ORANGE][i])
	_plant(_content, Vector3(2.6, 0, -2.1), 0.9, WHITE)

func _bathroom() -> void:
	_shell(Color("cae7e5"), true)
	_round_rug(Color("afe2dd"), 1.5)
	# Glossy ceramic wall tile strip.
	for x in range(-8, 9):
		for y in range(4):
			G.box(_content, "WallTile", Vector3(0.49, 0.39, 0.025), Vector3(x * 0.51, 1.72 + y * 0.41, -3.46), WHITE if (x + y) % 3 else Color("cde7e3"), 0.015)
	# Left shower has a real open-front tray, frame and transparent side panel.
	var shower = G.group(_content, "BubbleShower", Vector3(-1.82, 0, -2.15))
	G.box(shower, "ShowerTray", Vector3(1.45, 0.16, 1.45), Vector3(0, 0.1, 0), WHITE, 0.08)
	G.box(shower, "DrainBed", Vector3(1.22, 0.025, 1.2), Vector3(0, 0.19, 0), Color("bbdcd7"), 0.05)
	for x in [-0.67, 0.67]: G.cylinder(shower, "ShowerUpright", 0.027, 2.75, Vector3(x, 1.4, -0.61), Color("abbcbc"))
	G.rod(shower, "ShowerRail", Vector3(-0.67, 2.77, -0.61), Vector3(0.67, 2.77, -0.61), 0.027, Color("abbcbc"))
	G.box(shower, "FrostedGlassSide", Vector3(0.025, 2.55, 1.3), Vector3(-0.67, 1.45, 0), Color(0.70, 0.88, 0.89, 0.24), 0.01)
	G.rod(shower, "ShowerPipe", Vector3(0.35, 0.9, -0.6), Vector3(0.35, 2.55, -0.6), 0.025, Color("a7b9b8"))
	G.rod(shower, "ShowerElbow", Vector3(0.35, 2.55, -0.6), Vector3(0.35, 2.55, -0.15), 0.025, Color("a7b9b8"))
	G.cylinder(shower, "RainShowerHead", 0.25, 0.065, Vector3(0.35, 2.51, -0.15), CREAM)
	for i in range(6): G.sphere(shower, "Nozzle", Vector3.ONE * 0.02, Vector3(0.35 + sin(i) * 0.16, 2.47, -0.15 + cos(i) * 0.16), GRAPHITE)
	G.hit(shower, "ShowerTouch", Vector3(1.45, 2.8, 1.45), Vector3(0, 1.4, 0), "wash")
	# Vanity and oval mirror with a warm frame.
	var vanity = G.group(_content, "FloatingVanity", Vector3(1.7, 0, -2.65))
	G.box(vanity, "VanityCabinet", Vector3(1.5, 0.84, 0.78), Vector3(0, 0.72, 0), WOOD, 0.08)
	G.box(vanity, "VanityFront", Vector3(1.35, 0.7, 0.045), Vector3(0, 0.73, 0.41), Color("e2b98a"), 0.045)
	G.box(vanity, "VanityHandle", Vector3(0.6, 0.035, 0.055), Vector3(0, 0.93, 0.46), GRAPHITE, 0.015)
	G.box(vanity, "SinkCounter", Vector3(1.65, 0.12, 0.9), Vector3(0, 1.2, 0), WHITE, 0.08)
	G.sphere(vanity, "RoundBasin", Vector3(0.85, 0.25, 0.65), Vector3(0, 1.37, 0.02), WHITE)
	G.sphere(vanity, "BasinInterior", Vector3(0.62, 0.055, 0.42), Vector3(0, 1.49, 0.04), Color("c0dad7"))
	G.rod(vanity, "Faucet", Vector3(0, 1.26, -0.28), Vector3(0, 1.73, -0.28), 0.03, Color("bdab87"))
	G.rod(vanity, "FaucetSpout", Vector3(0, 1.73, -0.28), Vector3(0, 1.73, -0.01), 0.03, Color("bdab87"))
	G.sphere(_content, "OvalMirrorFrame", Vector3(1.33, 1.75, 0.12), Vector3(1.7, 2.8, -3.31), Color("e9bc85"))
	G.sphere(_content, "SoftMirror", Vector3(1.17, 1.58, 0.06), Vector3(1.7, 2.8, -3.22), Color("a7cbd2"))
	G.box(_content, "MirrorReflection", Vector3(0.13, 1.07, 0.02), Vector3(1.43, 2.92, -3.17), Color("d5e9ec"), 0.05).rotation.z = -0.28
	# Towel ladder with folded textiles.
	for x in [2.72, 3.25]: G.rod(_content, "TowelLadderRail", Vector3(x, 0.05, -2.6), Vector3(x, 2.1, -3.03), 0.035, WOOD)
	for y in [0.6, 1.05, 1.5]: G.rod(_content, "TowelRung", Vector3(2.72, y, -2.7 - y * 0.15), Vector3(3.25, y, -2.7 - y * 0.15), 0.025, WOOD)
	G.box(_content, "PeachTowel", Vector3(0.47, 0.62, 0.09), Vector3(2.98, 1.19, -2.81), Color("ffc5a0"), 0.035)
	G.box(_content, "TowelStripe", Vector3(0.45, 0.055, 0.015), Vector3(2.98, 0.99, -2.75), WHITE, 0.01)
	# Cleaning tools stand and recycling station.
	G.box(_content, "SoapShelf", Vector3(0.9, 0.065, 0.38), Vector3(0.0, 3.5, -3.2), CREAM, 0.025)
	for i in range(3):
		G.cylinder(_content, "SoapBottle", 0.09, 0.32 + i * 0.025, Vector3(-0.27 + i * 0.27, 3.7, -3.18), [AQUA, ORANGE, LAVENDER][i])
		G.box(_content, "BottlePump", Vector3(0.12, 0.04, 0.05), Vector3(-0.25 + i * 0.27, 3.9, -3.18), WHITE, 0.015)
	_anchors["filter"] = Vector3(1.15, 0.0, -0.1)
	var station = G.group(_content, "FilterRecyclingPod", Vector3(1.75, 0, -0.25))
	G.box(station, "FilterBase", Vector3(0.9, 0.68, 0.9), Vector3(0, 0.38, 0), CREAM, 0.18)
	G.box(station, "FilterPanel", Vector3(0.52, 0.25, 0.03), Vector3(0, 0.43, 0.47), GRAPHITE, 0.05)
	for i in range(3): G.box(station, "FilterLED", Vector3(0.08, 0.035, 0.02), Vector3(-0.16 + i * 0.16, 0.43, 0.49), MINT, 0.01)
	_filter_lid = G.group(station, "FilterLidPivot", Vector3(0, 0.74, -0.35))
	G.box(_filter_lid, "FilterLid", Vector3(0.92, 0.11, 0.9), Vector3(0, 0, 0.35), AQUA, 0.05)
	G.hit(station, "FilterTouch", Vector3(1, 1, 1), Vector3(0, 0.4, 0), "filter")
	_rubber_duck(_content, Vector3(-1.3, 0.2, -1.6))
	for i in range(9):
		var bubble = G.sphere(_content, "FloatingBubble", Vector3.ONE * (0.09 + (i % 3) * 0.04), Vector3(-2.1 + sin(i * 2.3) * 0.45, 0.5 + i * 0.19, -1.6 + cos(i) * 0.2), Color(0.85, 0.97, 1.0, 0.4))
		bubble.set_meta("base_y", bubble.position.y)
		_bubbles.append(bubble)

func _games() -> void:
	_shell(Color("b9d9e7"))
	_round_rug(LAVENDER, 1.85)
	# Circular rug game markings are restrained, keeping the character readable.
	for i in range(6):
		var a = i * TAU / 6.0
		G.cylinder(_content, "PlayMatDot", 0.1, 0.01, Vector3(sin(a) * 1.45, 0.06, 0.15 + cos(a) * 1.45), [AQUA, YELLOW, ORANGE][i % 3])
	# Friendly retro cabinet.
	var arcade = G.group(_content, "ArcadeCabinet", Vector3(-1.9, 0, -2.4))
	G.box(arcade, "CabinetBase", Vector3(1.05, 1.2, 0.9), Vector3(0, 0.66, 0), Color("9e8cc8"), 0.1)
	G.box(arcade, "ArcadeUpper", Vector3(1.12, 1.28, 0.73), Vector3(0, 1.85, -0.08), LAVENDER, 0.1)
	G.box(arcade, "ScreenBezel", Vector3(0.96, 0.85, 0.09), Vector3(0, 1.87, 0.32), GRAPHITE, 0.08)
	G.box(arcade, "ArcadeScreen", Vector3(0.79, 0.65, 0.025), Vector3(0, 1.88, 0.38), Color("4e8c93"), 0.05)
	# Original tiny pixel-like duck graphic built from raised geometry.
	G.box(arcade, "ScreenDuckHead", Vector3(0.23, 0.2, 0.02), Vector3(0.0, 1.98, 0.4), YELLOW, 0.04)
	G.box(arcade, "ScreenDuckBody", Vector3(0.38, 0.17, 0.02), Vector3(-0.06, 1.80, 0.4), YELLOW, 0.04)
	G.box(arcade, "ScreenDuckBill", Vector3(0.14, 0.06, 0.02), Vector3(0.17, 1.96, 0.41), ORANGE, 0.02)
	G.sphere(arcade, "ScreenDuckEye", Vector3.ONE * 0.035, Vector3(0.05, 2.02, 0.43), GRAPHITE)
	G.box(arcade, "ControlDeck", Vector3(1.12, 0.14, 0.62), Vector3(0, 1.27, 0.32), CREAM, 0.05)
	G.cylinder(arcade, "JoystickStem", 0.025, 0.18, Vector3(-0.25, 1.42, 0.38), GRAPHITE)
	G.sphere(arcade, "JoystickBall", Vector3.ONE * 0.13, Vector3(-0.25, 1.52, 0.38), ORANGE)
	for i in range(3): G.cylinder(arcade, "ArcadeButton", 0.065, 0.035, Vector3(0.12 + i * 0.14, 1.36, 0.38), [AQUA, YELLOW, ORANGE][i])
	G.box(arcade, "Marquee", Vector3(1.18, 0.31, 0.82), Vector3(0, 2.62, -0.08), ORANGE, 0.08)
	for i in range(3): G.sphere(arcade, "MarqueeLight", Vector3.ONE * 0.09, Vector3(-0.26 + i * 0.26, 2.62, 0.35), WHITE)
	G.hit(arcade, "ArcadeTouch", Vector3(1.2, 2.8, 1.1), Vector3(0, 1.4, 0), "games")
	# Low toy shelves and prize cubbies.
	var shelf = G.group(_content, "ToyCubby", Vector3(1.7, 0, -2.65))
	G.box(shelf, "CubbyBack", Vector3(2.0, 1.8, 0.06), Vector3(0, 0.97, -0.28), Color("a3c5d7"), 0.02)
	for x in [-1, 0, 1]: G.box(shelf, "CubbyDivider", Vector3(0.07, 1.8, 0.6), Vector3(x, 0.97, 0), CREAM, 0.02)
	for y in [0.1, 1.0, 1.9]: G.box(shelf, "CubbyShelf", Vector3(2.07, 0.07, 0.6), Vector3(0, y, 0), CREAM, 0.02)
	G.box(shelf, "ToyBasket", Vector3(0.7, 0.53, 0.46), Vector3(-0.5, 0.40, 0), ORANGE, 0.07)
	G.box(shelf, "BasketHandle", Vector3(0.28, 0.08, 0.02), Vector3(-0.5, 0.48, 0.25), Color("e7a878"), 0.035)
	_books(shelf, Vector3(0.16, 0.15, 0), 5)
	_rubber_duck(shelf, Vector3(-0.5, 1.05, 0))
	G.cylinder(shelf, "TrophyBase", 0.17, 0.08, Vector3(0.5, 1.10, 0), GRAPHITE)
	G.cylinder(shelf, "TrophyStem", 0.045, 0.22, Vector3(0.5, 1.25, 0), YELLOW)
	G.sphere(shelf, "TrophyCup", Vector3(0.35, 0.30, 0.35), Vector3(0.5, 1.46, 0), YELLOW)
	# Wall-mounted playful lighting track and pennant garland.
	for i in range(9):
		var x = -2.8 + i * 0.7
		var y = 4.12 - sin(float(i) / 8.0 * PI) * 0.38
		G.sphere(_content, "FairyLight", Vector3.ONE * 0.09, Vector3(x, y, -3.32), [YELLOW, AQUA, ORANGE, LAVENDER][i % 4])
		if i > 0:
			var prev_x = -2.8 + (i - 1) * 0.7
			var prev_y = 4.12 - sin(float(i - 1) / 8.0 * PI) * 0.38
			G.rod(_content, "GarlandCord", Vector3(prev_x, prev_y, -3.34), Vector3(x, y, -3.34), 0.009, CREAM)
	_wall_art(Vector3(0.2, 3.0, -3.36), ORANGE, Vector2(1.05, 1.15))
	for i in range(3):
		var block = G.box(_content, "SoftPlayBlock", Vector3.ONE * 0.39, Vector3(1.75 + (i % 2) * 0.28, 0.21 + (i / 2) * 0.39, 0.2), [AQUA, ORANGE, YELLOW][i], 0.055)
		block.rotation.y = i * 0.35
	_ball(_content, Vector3(-1.35, 0, 0.85))
	G.hit(_content, "CubeTouch", Vector3(0.9, 0.9, 0.8), Vector3(1.85, 0.4, 0.2), "cube")

func _workshop() -> void:
	_shell(Color("d3dedb"))
	_round_rug(Color("a8c7ca"), 1.7)
	# Rounded workbench with storage drawers.
	G.box(_content, "WorkbenchTop", Vector3(5.0, 0.16, 1.05), Vector3(0, 1.25, -2.65), WOOD, 0.06)
	for x in [-2.05, 2.05]:
		G.box(_content, "BenchCabinet", Vector3(0.85, 1.12, 0.82), Vector3(x, 0.62, -2.65), Color("a8bab7"), 0.06)
		for i in range(3):
			G.box(_content, "PartsDrawer", Vector3(0.72, 0.29, 0.06), Vector3(x, 0.30 + i * 0.33, -2.2), CREAM, 0.025)
			G.box(_content, "DrawerPull", Vector3(0.25, 0.03, 0.045), Vector3(x, 0.33 + i * 0.33, -2.15), GRAPHITE, 0.01)
	# Pegboard shows real holes and organized tools.
	G.box(_content, "ToolPegboard", Vector3(3.6, 1.58, 0.11), Vector3(-0.6, 2.8, -3.38), Color("c6a27c"), 0.1)
	for x in range(15):
		for y in range(6):
			G.sphere(_content, "PegHole", Vector3(0.025, 0.025, 0.012), Vector3(-2.21 + x * 0.23, 2.22 + y * 0.23, -3.31), Color("937759"))
	for i in range(3):
		var x = -1.85 + i * 0.52
		G.box(_content, "ToolHandle", Vector3(0.09, 0.33, 0.08), Vector3(x, 2.68, -3.21), [ORANGE, AQUA, LAVENDER][i], 0.035)
		G.rod(_content, "ToolShaft", Vector3(x, 2.81, -3.21), Vector3(x, 3.10, -3.21), 0.018, Color("bdc6c2"))
		if i == 1: G.box(_content, "WrenchHead", Vector3(0.18, 0.11, 0.07), Vector3(x, 3.13, -3.21), Color("bdc6c2"), 0.03)
		if i == 2: G.box(_content, "HammerHead", Vector3(0.24, 0.10, 0.1), Vector3(x, 3.13, -3.21), Color("bdc6c2"), 0.02)
	# Diagnostic screen with waveform and colored status rows.
	var monitor = G.group(_content, "DiagnosticsMonitor", Vector3(1.3, 1.34, -2.8))
	G.box(monitor, "MonitorStand", Vector3(0.5, 0.045, 0.35), Vector3(0, 0, 0), GRAPHITE, 0.025)
	G.box(monitor, "MonitorStem", Vector3(0.07, 0.29, 0.07), Vector3(0, 0.16, 0), GRAPHITE, 0.02)
	G.box(monitor, "MonitorFrame", Vector3(1.15, 0.78, 0.12), Vector3(0, 0.6, 0), GRAPHITE, 0.08)
	G.box(monitor, "MonitorScreen", Vector3(0.99, 0.62, 0.025), Vector3(0, 0.6, 0.08), Color("426768"), 0.045)
	for i in range(7):
		var bar_height = 0.04 + absf(sin(i * 0.9)) * 0.26
		G.box(monitor, "DiagnosticBar", Vector3(0.07, bar_height, 0.015), Vector3(-0.36 + i * 0.12, 0.57 + bar_height * 0.5, 0.1), MINT, 0.02)
	for i in range(3): G.box(monitor, "DiagnosticStatus", Vector3(0.2, 0.025, 0.015), Vector3(-0.3 + i * 0.3, 0.39, 0.1), [AQUA, YELLOW, ORANGE][i], 0.008)
	G.hit(monitor, "DiagnosticsTouch", Vector3(1.25, 1, 0.6), Vector3(0, 0.5, 0), "stats")
	# Mini robotic arm with visible elbow and end-effector.
	var arm = G.group(_content, "HelpfulRobotArm", Vector3(-1.35, 1.35, -2.48))
	G.cylinder(arm, "ArmBase", 0.25, 0.12, Vector3(0, 0.06, 0), GRAPHITE)
	G.rod(arm, "UpperLink", Vector3(0, 0.15, 0), Vector3(-0.20, 0.65, 0), 0.09, ORANGE)
	G.sphere(arm, "Elbow", Vector3.ONE * 0.22, Vector3(-0.20, 0.65, 0), GRAPHITE)
	G.rod(arm, "Forearm", Vector3(-0.20, 0.65, 0), Vector3(0.25, 0.96, 0), 0.075, CREAM)
	G.sphere(arm, "Wrist", Vector3.ONE * 0.16, Vector3(0.25, 0.96, 0), GRAPHITE)
	for x in [-1, 1]: G.rod(arm, "Gripper", Vector3(0.25, 0.96, 0), Vector3(0.25 + x * 0.12, 1.14, 0), 0.025, Color("abbab6"))
	# Color sample pods visually hint at customization.
	G.box(_content, "ColorShelf", Vector3(1.24, 0.08, 0.42), Vector3(2.32, 3.22, -3.17), CREAM, 0.02)
	for i in range(4): G.sphere(_content, "MaterialSample", Vector3.ONE * 0.22, Vector3(1.89 + i * 0.29, 3.39, -3.12), [ORANGE, LAVENDER, AQUA, MINT][i])
	# Low rolling tool cart on the side, with neatly sorted parts.
	var cart = G.group(_content, "PartsCart", Vector3(1.85, 0, -0.15))
	G.box(cart, "CartBody", Vector3(0.75, 0.7, 0.65), Vector3(0, 0.46, 0), ORANGE, 0.1)
	G.box(cart, "ToolTray", Vector3(0.85, 0.08, 0.75), Vector3(0, 0.86, 0), CREAM, 0.03)
	for i in range(3):
		G.box(cart, "CartDrawer", Vector3(0.63, 0.16, 0.03), Vector3(0, 0.26 + i * 0.2, 0.35), Color("ed773b"), 0.02)
		G.box(cart, "CartPull", Vector3(0.27, 0.025, 0.035), Vector3(0, 0.3 + i * 0.2, 0.39), GRAPHITE, 0.01)
	for x in [-0.25, 0.25]:
		var wheel = G.cylinder(cart, "CartWheel", 0.09, 0.06, Vector3(x, 0.11, 0.22), GRAPHITE)
		wheel.rotation.z = PI * 0.5
	for i in range(3): G.ring(cart, "SpareGear", 0.05, 0.11, Vector3(-0.23 + i * 0.23, 0.92, 0), Color("a9b8b4"))
	G.hit(cart, "WardrobeTouch", Vector3(1, 1.1, 0.9), Vector3(0, 0.5, 0), "wardrobe")
	_floor_lamp(Vector3(-2.85, 0, -1.25), AQUA)

func _garden() -> void:
	# Open-air diorama replaces the room shell entirely.
	G.box(_content, "GardenSoil", Vector3(10, 0.24, 11), Vector3(0, -0.15, 0), Color("a7ba80"), 0.1)
	G.box(_content, "VelvetLawn", Vector3(9.8, 0.06, 10.8), Vector3(0, 0, 0), Color("b5d49b"), 0.03)
	# Sky plane plus rounded hedges provide spatial depth behind the fence.
	var sky = G.box(_content, "GardenSky", Vector3(13, 7, 0.12), Vector3(0, 3.3, -5.15), Color("b6e6ed"), 0.03)
	_sky_material = G.material(Color("b6e6ed"), 0.0, 0.85, 0.1).duplicate()
	_sky_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sky.material_override = _sky_material
	sky.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	for i in range(9): G.sphere(_content, "DistantHedge", Vector3(1.5, 1.3 + (i % 3) * 0.25, 1.0), Vector3(-4.5 + i * 1.1, 1.1, -4.3), Color("8ebf95") if i % 2 == 0 else Color("a0cba0"))
	for i in range(21):
		var x = -4.6 + i * 0.46
		G.box(_content, "Picket", Vector3(0.33, 1.35, 0.13), Vector3(x, 0.73, -3.45), CREAM, 0.1)
	for y in [0.4, 1.0]: G.box(_content, "FenceRail", Vector3(10, 0.1, 0.12), Vector3(0, y, -3.55), Color("e5d5b9"), 0.025)
	# Stepping stones run through the foreground, safely below the pet.
	for i in range(5):
		var stone = G.cylinder(_content, "SteppingStone", 0.56, 0.045, Vector3(sin(i * 0.7) * 0.18, 0.045, 1.0 + i * 0.82), Color("e7dfc5"))
		stone.scale.x = 1.35
	# Tree with clustered soft foliage and visible branch structure.
	var tree = G.group(_content, "GardenTree", Vector3(-2.6, 0, -2.5))
	G.rod(tree, "Trunk", Vector3.ZERO, Vector3(0.1, 2.75, 0), 0.17, Color("bb9067"))
	G.rod(tree, "Branch", Vector3(0.05, 1.65, 0), Vector3(-0.62, 2.65, 0.1), 0.09, Color("bb9067"))
	G.rod(tree, "Branch", Vector3(0.08, 2.15, 0), Vector3(0.7, 3.0, -0.2), 0.075, Color("bb9067"))
	for i in range(7):
		G.sphere(tree, "TreeCrown", Vector3(1.45, 1.15, 1.3), Vector3(sin(i * 2.2) * 0.65, 2.85 + (i % 3) * 0.35, cos(i * 2.2) * 0.3), [Color("91bd86"), Color("a8ce91"), Color("bddda2")][i % 3])
	# Slatted bench with slightly angled back.
	var bench = G.group(_content, "GardenBench", Vector3(1.65, 0, -2.35))
	for x in [-0.73, 0.73]:
		for z in [-0.22, 0.22]: G.box(bench, "BenchLeg", Vector3(0.09, 0.58, 0.09), Vector3(x, 0.29, z), Color("8caaa0"), 0.02)
	for z in [-0.24, -0.08, 0.08, 0.24]: G.box(bench, "SeatSlat", Vector3(1.9, 0.08, 0.135), Vector3(0, 0.61, z), WOOD, 0.025)
	for y in [0.88, 1.1]: G.box(bench, "BackSlat", Vector3(1.9, 0.17, 0.08), Vector3(0, y, -0.26), Color("dfb787"), 0.04)
	for x in [-0.8, 0.8]: G.box(bench, "BackSupport", Vector3(0.07, 0.8, 0.07), Vector3(x, 0.8, -0.29), Color("8caaa0"), 0.02)
	# Small roller ramp is unmistakable but does not obstruct the central pet.
	var ramp = G.group(_content, "RollerRamp", Vector3(1.95, 0, 0.5))
	G.box(ramp, "RampFoot", Vector3(1.0, 0.12, 1.45), Vector3(0, 0.08, 0), Color("d7b183"), 0.05)
	var slope = G.box(ramp, "GentleRamp", Vector3(0.95, 0.10, 1.2), Vector3(0, 0.29, -0.05), Color("f1cca0"), 0.045)
	slope.rotation.x = 0.30
	for x in [-0.49, 0.49]: G.rod(ramp, "RampEdge", Vector3(x, 0.15, 0.52), Vector3(x, 0.5, -0.62), 0.025, ORANGE)
	G.hit(ramp, "RampTouch", Vector3(1.2, 0.7, 1.5), Vector3(0, 0.3, 0), "trick")
	_ball(_content, Vector3(-1.25, 0.04, 0.65), 1.15)
	for i in range(14):
		var side = -1.0 if i % 2 == 0 else 1.0
		var flower_pos = Vector3(side * (1.6 + float(i % 4) * 0.32), 0.02, -1.6 + float(i / 4) * 0.48)
		_flower(flower_pos, [ORANGE, LAVENDER, YELLOW, Color("e6a4b4")][i % 4])
	# Birdhouse and outdoor fairy lights.
	G.rod(_content, "BirdhousePole", Vector3(2.9, 0, -3.0), Vector3(2.9, 2.6, -3.0), 0.035, WOOD)
	G.box(_content, "Birdhouse", Vector3(0.46, 0.5, 0.4), Vector3(2.9, 2.7, -3.0), MINT, 0.06)
	G.box(_content, "BirdhouseRoof", Vector3(0.62, 0.12, 0.56), Vector3(2.9, 3.0, -3.0), ORANGE, 0.05).rotation.z = 0.08
	var hole = G.cylinder(_content, "BirdhouseOpening", 0.09, 0.025, Vector3(2.9, 2.75, -2.78), GRAPHITE)
	hole.rotation.x = PI * 0.5
	_window_sun = G.group(_content, "GardenSun")
	var sun = G.cylinder(_window_sun, "Sun", 0.38, 0.04, Vector3(1.2, 4.3, -5.03), YELLOW)
	sun.rotation.x = PI * 0.5
	_window_moon = G.group(_content, "GardenMoon")
	G.sphere(_window_moon, "Moon", Vector3(0.54, 0.54, 0.06), Vector3(1.2, 4.3, -5.03), Color("fff3c7"))
	_window_stars = G.group(_content, "GardenStars")
	for i in range(13): G.sphere(_window_stars, "Star", Vector3.ONE * 0.045, Vector3(sin(i * 2.4) * 3.7, 3.7 + cos(i * 1.8) * 1.0, -5.0), CREAM)

func _flower(pos: Vector3, color: Color) -> void:
	var root = G.group(_content, "Wildflower", pos)
	var h = 0.35 + absf(sin(pos.x * 4.0)) * 0.18
	G.cylinder(root, "FlowerStem", 0.012, h, Vector3(0, h * 0.5, 0), Color("6a9a73"))
	var leaf = G.sphere(root, "FlowerLeaf", Vector3(0.19, 0.07, 0.05), Vector3(0.07, h * 0.45, 0), Color("81b482"))
	leaf.rotation.z = 0.35
	for i in range(5):
		var a = i * TAU / 5.0
		G.sphere(root, "Petal", Vector3(0.13, 0.13, 0.07), Vector3(sin(a) * 0.085, h + cos(a) * 0.085, 0), color)
	G.sphere(root, "FlowerCenter", Vector3.ONE * 0.09, Vector3(0, h, 0.05), YELLOW)
