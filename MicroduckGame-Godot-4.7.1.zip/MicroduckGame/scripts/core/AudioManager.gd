extends Node
## Original offline music and pooled sound effects. No external audio dependencies.

const TRACKS = {
	"main": "res://assets/audio/cozy_circuits.wav",
	"sleep": "res://assets/audio/moon_dock.wav",
	"game": "res://assets/audio/roller_groove.wav",
	"shop": "res://assets/audio/little_treasures.wav",
}
const ALIASES = {
	"click": "ui", "button": "ui", "switch": "ui", "room": "ui",
	"purchase": "coin", "buy": "coin", "reward": "coin", "level_up": "win",
	"head": "happy", "pet": "happy", "beak": "beep", "body": "servo",
	"feet": "wheels", "poke": "surprise", "shake": "surprise",
	"rinse": "wash", "dry": "wash", "filter": "servo", "eat": "feed",
	"wake": "happy", "stop_charge": "beep", "ball": "happy", "duck": "beep",
	"cube": "servo", "music": "happy", "error": "lose", "success": "win",
}

var music_volume: float = 0.45
var sfx_volume: float = 0.75
var vibration_enabled: bool = true
var music_players: Array[AudioStreamPlayer] = []
var effect_players: Array[AudioStreamPlayer] = []
var effect_streams: Dictionary = {}
var track_streams: Dictionary = {}
var current_track: String = ""
var active_music: int = 0
var next_effect: int = 0
var crossfade: Tween
var last_effect_times: Dictionary = {}
var shutting_down = false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for index in range(2):
		var player = AudioStreamPlayer.new()
		player.name = "Music%d" % index
		player.volume_db = -80.0
		add_child(player)
		music_players.append(player)
	for index in range(8):
		var player = AudioStreamPlayer.new()
		player.name = "Effect%d" % index
		add_child(player)
		effect_players.append(player)
	for effect in ["ui", "happy", "feed", "wash", "charge", "sleep", "coin", "win", "lose", "beep", "surprise", "hunger", "servo", "wheels"]:
		var path: String = "res://assets/audio/%s.wav" % effect
		if ResourceLoader.exists(path):
			effect_streams[effect] = load(path)
	for key in TRACKS:
		if ResourceLoader.exists(TRACKS[key]):
			var stream: AudioStreamWAV = load(TRACKS[key])
			stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
			stream.loop_begin = 0
			stream.loop_end = int(stream.get_length() * stream.mix_rate)
			track_streams[key] = stream
	if DisplayServer.get_name() != "headless":
		set_room("living")

func apply_settings(settings: Dictionary) -> void:
	music_volume = clampf(float(settings.get("music", 0.45)), 0.0, 1.0)
	sfx_volume = clampf(float(settings.get("sfx", 0.75)), 0.0, 1.0)
	vibration_enabled = bool(settings.get("vibration", true))
	if is_instance_valid(crossfade):
		crossfade.kill()
	for index in range(music_players.size()):
		music_players[index].volume_db = _db(music_volume * 0.72) if index == active_music else -80.0
	for player in effect_players:
		player.volume_db = _db(sfx_volume)

func set_room(room: String) -> void:
	if shutting_down:return
	if DisplayServer.get_name() == "headless":
		return
	var track: String = "main"
	match room:
		"bedroom", "sleep": track = "sleep"
		"games", "minigame", "game": track = "game"
		"shop", "wardrobe": track = "shop"
	if track == current_track or not track_streams.has(track) or music_players.is_empty():
		return
	current_track = track
	if is_instance_valid(crossfade):
		crossfade.kill()
	var previous: AudioStreamPlayer = music_players[active_music]
	active_music = 1 - active_music
	var next: AudioStreamPlayer = music_players[active_music]
	next.stream = track_streams[track]
	next.volume_db = -80.0
	next.play()
	crossfade = create_tween().set_parallel(true)
	crossfade.tween_property(previous, "volume_db", -80.0, 0.8)
	crossfade.tween_property(next, "volume_db", _db(music_volume * 0.72), 0.8)
	crossfade.chain().tween_callback(previous.stop)

func play(sound: String) -> void:
	if shutting_down:return
	if DisplayServer.get_name() == "headless":
		return
	var key: String = str(ALIASES.get(sound, sound))
	if not effect_streams.has(key) or effect_players.is_empty() or sfx_volume <= 0.001:
		return
	# Repeated dragging and taps cannot stack an uncomfortable wall of sound.
	var now: int = Time.get_ticks_msec()
	if now - int(last_effect_times.get(key, -1000)) < 65:
		return
	last_effect_times[key] = now
	var player: AudioStreamPlayer = effect_players[next_effect]
	next_effect = (next_effect + 1) % effect_players.size()
	player.stop()
	player.stream = effect_streams[key]
	player.volume_db = _db(sfx_volume)
	player.pitch_scale = randf_range(0.97, 1.03) if key in ["happy", "beep", "servo", "feed"] else 1.0
	player.play()
	if vibration_enabled and OS.has_feature("mobile") and key in ["coin", "win", "lose"]:
		Input.vibrate_handheld(30 if key != "win" else 60, 0.3)

func _db(value: float) -> float:
	return linear_to_db(maxf(value, 0.0001))

func shutdown() -> void:
	shutting_down = true
	if is_instance_valid(crossfade):
		crossfade.kill()
	for player in music_players + effect_players:
		if is_instance_valid(player):
			player.stop()
			player.stream = null
	effect_streams.clear()
	track_streams.clear()

func _exit_tree() -> void:
	shutdown()
