extends RefCounted
## Prices and inventory effects are data, not UI behavior.
const FOOD_EFFECTS = {
	"cookie":{"hunger":15.0,"cleanliness":-1.0},
	"chip":{"hunger":25.0,"cleanliness":-1.0},
	"oil":{"hunger":35.0,"cleanliness":-2.0},
	"fruit":{"hunger":40.0,"happiness":3.0,"cleanliness":-1.0},
	"cell":{"hunger":55.0,"happiness":4.0,"cleanliness":-2.0},
	"feast":{"hunger":80.0,"happiness":8.0,"cleanliness":-3.0},
	"basic":{"hunger":12.0,"cleanliness":-0.5}}

static func make_catalog() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var rows = [
		["cookie","food","Micro cookie","A crunchy little treat. +15 fullness",15,1],
		["chip","food","Energy chips","A favorite snack. +25 fullness",30,1],
		["oil","food","Robo donut","A soft round treat. +35 fullness",40,1],
		["fruit","food","Duck flakes","A sunny bowl of flakes. +40 fullness",45,1],
		["cell","food","Mini burger","A big little snack. +55 fullness",65,1],
		["feast","food","Celebration meal","A special feast. +80 fullness",100,1],
		["basic","food","Basic snack","Always free. +12 fullness",0,1],
		["classic","skin","Classic Orange","Warm ivory and orange. The original friend.",0,1],
		["lavender","skin","Lavender Yellow","Soft lilac shell and sunny yellow details.",160,1],
		["sky","skin","Sky Blue","A fresh blue shell with orange details.",180,1],
		["graphite","skin","Graphite","Dark graphite with bright yellow accents.",220,2],
		["mint","skin","Mint Edition","Mint shell with creamy accents.",240,3],
		["golden","skin","Golden Duck","A warm golden celebration.",650,5],
		["neon","skin","Neon Cyber","Graphite with a turquoise camera light.",850,10],
		["candy","skin","Candy Pink","Strawberry pink and vanilla cream.",380,4],
		["none","accessory","No accessory","Show off the original silhouette.",0,1],
		["bow","accessory","Little bow","A playful ribbon for special days.",90,1],
		["cap","accessory","Explorer cap","Ready for a little adventure.",130,2],
		["glasses","accessory","Star glasses","A bright little star on the dance floor.",180,3],
		["rug_mint","furniture","Mint rug","A soft mint rug for the current room.",110,1],
		["rug_lavender","furniture","Lavender rug","A cozy lavender rug for the current room.",110,1],
		["lamp_sunset","furniture","Sunset lamp","A warm peach accent for the current room.",150,2],
		["plant","furniture","Little plant","A little green companion in the current room.",100,1],
		["ball","toy","Bouncy ball","Roll a ball together. Restores joy.",0,1],
		["duck","toy","Rubber duck","A funny squeaky friend. Restores joy.",65,1],
		["cube","toy","Puzzle cube","A tiny puzzle for a curious robot.",90,2],
		["music","toy","Music box","A little melody and a happy dance.",120,2]]
	for row in rows:
		result.append({"id":row[0],"kind":row[1],"name":row[2],"description":row[3],"price":row[4],"level":row[5]})
	var parts = [
		["lens_aqua","lens","Aqua lens","A soft turquoise camera ring.",70,1,"#9ADFE8"],
		["lens_lavender","lens","Lavender lens","A little lilac light.",85,2,"#B4A1E1"],
		["beak_yellow","beak","Sunny beak","A warm yellow robotic beak.",70,1,"#FFD45E"],
		["beak_rose","beak","Rose beak","A playful rosy accent.",85,2,"#F3A1B5"],
		["rollers_mint","rollers","Mint rollers","A fresh mint finish for your skates.",90,1,"#A9E2C1"],
		["rollers_yellow","rollers","Sunny rollers","Bright yellow roller feet.",90,1,"#FFD45E"]]
	for row in parts:
		result.append({"id":row[0],"kind":row[1],"name":row[2],"description":row[3],"price":row[4],"level":row[5],"color":row[6]})
	return result

static func find_item(catalog: Array[Dictionary], item_id: String) -> Dictionary:
	for item in catalog:
		if item["id"] == item_id:
			return item
	return {}

static func purchase(data: Dictionary, item: Dictionary) -> String:
	if item.is_empty():
		return "This item is unavailable."
	if int(data["level"]) < int(item["level"]):
		return "Reach a higher level to unlock this item."
	var item_id: String = item["id"]
	if item["kind"] != "food" and item_id in data["owned_items"]:
		return "You already own this item."
	if int(data["coins"]) < int(item["price"]):
		return "Not enough coins. Play a mini-game to earn more!"
	if item["kind"] == "food" and int(data["owned_food"].get(item_id,0)) >= 999:
		return "The pantry is full."
	data["coins"] = int(data["coins"]) - int(item["price"])
	if item["kind"] == "food":
		data["owned_food"][item_id] = int(data["owned_food"].get(item_id, 0)) + 1
	else:
		data["owned_items"].append(item_id)
	return ""
