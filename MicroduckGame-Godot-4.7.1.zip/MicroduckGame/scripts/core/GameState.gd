extends Node
## Authoritative offline pet state. UI requests actions; this node validates them.
signal changed
signal notice(text: String)
signal action(kind: String)
signal cosmetics_changed

const SaveStore = preload("res://scripts/core/SaveManager.gd")
const Economy = preload("res://scripts/core/EconomyManager.gd")
const Progression = preload("res://scripts/core/ProgressionManager.gd")
const Needs = preload("res://scripts/core/PetNeeds.gd")
const ROOMS = ["living","kitchen","bedroom","bathroom","games","workshop","garden"]
const GAMES = ["catch","roller","memory","sort","beat","treasure"]
const SKINS = ["classic","lavender","sky","graphite","mint","golden","neon","candy"]
const ACCESSORIES = ["none","bow","cap","glasses"]
const STAT_KEYS = ["feed","sleep","charge","wash","filter","pet","games","wins","coins_earned","skins_bought","decorations","toys","visits"]
var catalog: Array[Dictionary] = Economy.make_catalog()
var data: Dictionary = {}
var save_path = "user://microduck_save.json"
var autosave_enabled = true
var wash_stage = 0
var _tick = 0.0
var _save_tick = 0.0
var _busy_until = 0
var _cooldowns: Dictionary = {}
var _session: Dictionary = {}
var _session_serial = 0
var _offline_seconds = 0.0
var _last_warning = ""
var _quitting = false
var _paused_at = -1.0
var _resume_frame_skip = false

func _ready() -> void:
	load_progress()
	get_tree().auto_accept_quit = false

func defaults() -> Dictionary:
	var now = int(Time.get_unix_time_from_system())
	var stats: Dictionary = {}
	for key in STAT_KEYS:
		stats[key] = 0
	return {"save_version":2,"pet_name":"Кряк","level":1,"xp":0,"coins":500,"created_at":now,"last_saved_at":now,
		"needs":{"hunger":72.0,"happiness":82.0,"cleanliness":78.0,"battery":66.0,"rest":74.0},
		"current_room":"living","is_sleeping":false,"is_charging":false,"equipped_skin":"classic","equipped_accessory":"none",
		"owned_items":["classic","none","ball"],"owned_food":{"chip":4,"cell":2,"oil":2,"cookie":2,"fruit":2,"feast":1,"basic":1},
		"part_colors":{},"equipped_parts":{},
		"furniture_choices":{},"completed_tutorial":false,"tutorial_rewarded":false,"tutorial_step":0,
		"daily_missions":{},"achievements":[],"minigame_records":{},"total_play_time":0.0,
		"settings":{"music":0.45,"sfx":0.75,"vibration":true,"quality":"high","language":"ru"},
		"stats":stats,"visited_rooms":["living"],"played_games":[],"charge_recovered":0.0,"rest_recovered":0.0,
		"charge_rewarded":false,"rest_rewarded":false,"anniversary_claimed":0,"daily_gift_day":-1}

func load_progress() -> void:
	var loaded = SaveStore.read_game(save_path)
	data = sanitize(loaded["data"])
	_offline_seconds = clampf(Time.get_unix_time_from_system() - float(data["last_saved_at"]), 0.0, Needs.OFFLINE_CAP)
	var recovered = Needs.advance(data, _offline_seconds, true)
	_apply_rest_recovery(recovered)
	_refresh_day()
	_check_anniversary()
	if bool(loaded["recovered"]):
		call_deferred("_notify", "Your progress was restored from the backup.")
	elif bool(loaded["failed"]):
		call_deferred("_notify", "The save could not be read. A new friend is ready to meet you.")
	data["last_saved_at"] = int(Time.get_unix_time_from_system())
	changed.emit()

func _num(value: Variant, fallback: float, low: float, high: float) -> float:
	if value is int or value is float:
		var number = float(value)
		if is_finite(number):
			return clampf(number, low, high)
	return fallback

func _array(value: Variant) -> Array:
	return value if value is Array else []

func _dict(value: Variant) -> Dictionary:
	return value if value is Dictionary else {}

func sanitize(raw: Dictionary) -> Dictionary:
	var clean = defaults()
	var now = int(Time.get_unix_time_from_system())
	clean["pet_name"] = _clean_name(str(raw.get("pet_name",clean["pet_name"])))
	for key in ["level","xp","coins","created_at","last_saved_at","tutorial_step","anniversary_claimed","daily_gift_day"]:
		var maximum = 9999999.0
		var minimum = 0.0
		if key == "level":
			maximum = 50.0
			minimum = 1.0
		elif key in ["created_at","last_saved_at"]:
			maximum = float(now + 86400 * 365)
		elif key == "tutorial_step":
			maximum = 20.0
		elif key == "daily_gift_day":
			minimum = -1.0
		clean[key] = int(_num(raw.get(key),float(clean[key]),minimum,maximum))
	# Missing fields migrate independently, rather than discarding other progress.
	var source_needs = _dict(raw.get("needs",{}))
	for key in clean["needs"]:
		clean["needs"][key] = _num(source_needs.get(key,raw.get(key)),float(clean["needs"][key]),0.0,100.0)
	for key in ["is_sleeping","is_charging","completed_tutorial","tutorial_rewarded","charge_rewarded","rest_rewarded"]:
		if raw.get(key) is bool:
			clean[key] = raw[key]
	if str(raw.get("current_room","")) in ROOMS:
		clean["current_room"] = raw["current_room"]
	if clean["current_room"] != "bedroom":
		clean["is_sleeping"] = false
		clean["is_charging"] = false
	# Old versions recorded the tutorial once; migration must not grant it again.
	if clean["completed_tutorial"]:
		clean["tutorial_rewarded"] = true
	for key in ["total_play_time","charge_recovered","rest_recovered"]:
		clean[key] = _num(raw.get(key),0.0,0.0,1000000000.0)
	var valid_items: Array = []
	for item in catalog:
		if item["kind"] != "food":
			valid_items.append(item["id"])
	for item in _array(raw.get("owned_items")):
		if item is String and item in valid_items and not item in clean["owned_items"]:
			clean["owned_items"].append(item)
	for key in clean["owned_food"]:
		clean["owned_food"][key] = int(_num(_dict(raw.get("owned_food")).get(key),float(clean["owned_food"][key]),0.0,999.0))
	if str(raw.get("equipped_skin","")) in SKINS and raw["equipped_skin"] in clean["owned_items"]:
		clean["equipped_skin"] = raw["equipped_skin"]
	if str(raw.get("equipped_accessory","")) in ACCESSORIES and raw["equipped_accessory"] in clean["owned_items"]:
		clean["equipped_accessory"] = raw["equipped_accessory"]
	for part in ["lens","beak","rollers"]:
		var item_id = str(_dict(raw.get("equipped_parts")).get(part,""))
		var part_item = Economy.find_item(catalog,item_id)
		if not part_item.is_empty() and part_item["kind"] == part and item_id in clean["owned_items"]:
			clean["equipped_parts"][part] = item_id
			clean["part_colors"][part] = part_item["color"]
	clean["owned_food"]["basic"] = 1
	var source_furniture = _dict(raw.get("furniture_choices"))
	for room in ROOMS:
		var slots = _dict(source_furniture.get(room))
		var accepted: Dictionary = {}
		for slot in ["rug","lamp","plant"]:
			var item_id = str(slots.get(slot,""))
			if item_id in ["rug_mint","rug_lavender","lamp_sunset","plant"] and item_id in clean["owned_items"]:
				accepted[slot] = item_id
		if not accepted.is_empty():
			clean["furniture_choices"][room] = accepted
	var source_settings = _dict(raw.get("settings",raw.get("game_settings",{})))
	for key in ["music","sfx"]:
		clean["settings"][key] = _num(source_settings.get(key),float(clean["settings"][key]),0.0,1.0)
	if source_settings.get("vibration") is bool:
		clean["settings"]["vibration"] = source_settings["vibration"]
	if str(source_settings.get("quality","")) in ["low","high"]:
		clean["settings"]["quality"] = source_settings["quality"]
	if str(source_settings.get("language","")) in ["ru","en","uz"]:
		clean["settings"]["language"] = source_settings["language"]
	for key in STAT_KEYS:
		clean["stats"][key] = int(_num(_dict(raw.get("stats")).get(key),0.0,0.0,99999999.0))
	for key in GAMES:
		var score = int(_num(_dict(raw.get("minigame_records")).get(key),0.0,0.0,1000000.0))
		if score > 0:
			clean["minigame_records"][key] = score
	for room in _array(raw.get("visited_rooms")):
		if room in ROOMS and not room in clean["visited_rooms"]:
			clean["visited_rooms"].append(room)
	for game in _array(raw.get("played_games")):
		if game in GAMES and not game in clean["played_games"]:
			clean["played_games"].append(game)
	for item in _array(raw.get("achievements")):
		if item is String and item.length() < 64 and not item in clean["achievements"]:
			clean["achievements"].append(item)
	var missions = _dict(raw.get("daily_missions"))
	clean["daily_missions"] = {"day":int(_num(missions.get("day"),-1.0,-1.0,9999999.0)),"progress":{},"claimed":[],"visited":[]}
	for key in ["feed","games","pet","charge","wash","score","visits"]:
		clean["daily_missions"]["progress"][key] = int(_num(_dict(missions.get("progress")).get(key),0.0,0.0,9999999.0))
	for item in _array(missions.get("claimed")):
		if item in ["feed","games","pet","charge","wash","score","visits"] and not item in clean["daily_missions"]["claimed"]:
			clean["daily_missions"]["claimed"].append(item)
	for room in _array(missions.get("visited")):
		if room in ROOMS and not room in clean["daily_missions"]["visited"]:
			clean["daily_missions"]["visited"].append(room)
	clean["xp"] = mini(int(clean["xp"]),Progression.required_xp(int(clean["level"]))-1)
	if int(clean["level"]) == 50:
		clean["xp"] = 0
	return clean

func _process(delta: float) -> void:
	if _resume_frame_skip:
		_resume_frame_skip = false
		return
	_tick += delta
	_save_tick += delta
	if _tick >= 1.0:
		var elapsed = minf(_tick,60.0)
		_tick = 0.0
		data["total_play_time"] = float(data["total_play_time"]) + elapsed
		_apply_rest_recovery(Needs.advance(data,elapsed))
		_refresh_day()
		_check_warning()
		changed.emit()
	if _save_tick >= 30.0:
		_save_tick = 0.0
		save()

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED and not data.is_empty():
		_paused_at = Time.get_unix_time_from_system()
	elif what == NOTIFICATION_APPLICATION_RESUMED and _paused_at >= 0.0 and not data.is_empty():
		var elapsed = clampf(Time.get_unix_time_from_system()-_paused_at,0.0,Needs.OFFLINE_CAP)
		_paused_at = -1.0
		_resume_frame_skip = true
		_tick = 0.0
		_save_tick = 0.0
		_apply_rest_recovery(Needs.advance(data,elapsed,true))
		_refresh_day()
		_check_anniversary()
		_commit()
	if what in [NOTIFICATION_APPLICATION_PAUSED,NOTIFICATION_WM_CLOSE_REQUEST,NOTIFICATION_APPLICATION_FOCUS_OUT] and not data.is_empty():
		save()
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		_quit_cleanly()

func _quit_cleanly() -> void:
	if _quitting:return
	_quitting = true
	var audio_manager = get_node_or_null("/root/Audio")
	if audio_manager and audio_manager.has_method("shutdown"):
		audio_manager.shutdown()
	# Let the audio thread release its last stream playback before engine teardown.
	await get_tree().create_timer(0.15).timeout
	get_tree().quit()

func save() -> bool:
	if not autosave_enabled or data.is_empty():
		return true
	data["last_saved_at"] = int(Time.get_unix_time_from_system())
	var okay = SaveStore.write_game(save_path,data)
	if not okay:
		_notify("Progress could not be saved. Please check free storage space.")
	return okay

func _notify(text: String) -> void:
	notice.emit(text)

func _commit() -> void:
	changed.emit()
	save()

func _available(allow_sleep: bool = false) -> bool:
	if not _session.is_empty():
		_notify("Finish the mini-game first.")
		return false
	if Time.get_ticks_msec() < _busy_until:
		return false
	if not allow_sleep and (data["is_sleeping"] or data["is_charging"]):
		_notify("Wake me up or unplug the dock first.")
		return false
	return true

func _wait(seconds: float) -> void:
	_busy_until = Time.get_ticks_msec() + int(seconds * 1000.0)

func buy(item_id: String) -> bool:
	var item = Economy.find_item(catalog,item_id)
	var error = Economy.purchase(data,item)
	if not error.is_empty():
		_notify(error)
		return false
	if item["kind"] == "skin":
		_stat("skins_bought")
	action.emit("purchase")
	_notify("Added to your collection!")
	_commit()
	return true

func equip(item_id: String) -> bool:
	if not item_id in data["owned_items"]:
		_notify("Buy this item to use it.")
		return false
	var item = Economy.find_item(catalog,item_id)
	if item.is_empty():
		return false
	match item["kind"]:
		"skin": data["equipped_skin"] = item_id
		"accessory": data["equipped_accessory"] = item_id
		"lens","beak","rollers":
			data["part_colors"][item["kind"]] = item["color"]
			data["equipped_parts"][item["kind"]] = item_id
		"furniture":
			var room: String = data["current_room"]
			if not data["furniture_choices"].has(room):
				data["furniture_choices"][room] = {}
			var slot = "rug" if item_id.begins_with("rug") else ("lamp" if item_id.begins_with("lamp") else "plant")
			if data["furniture_choices"][room].get(slot,"") != item_id:
				data["furniture_choices"][room][slot] = item_id
				_stat("decorations")
		"toy":
			return care(item_id)
		_:
			return false
	cosmetics_changed.emit()
	action.emit("happy")
	_commit()
	return true

func feed(food_id: String) -> bool:
	if not _available():
		return false
	if data["current_room"] != "kitchen":
		_notify("Let's eat in the kitchen.")
		return false
	if not Economy.FOOD_EFFECTS.has(food_id):
		return false
	if int(data["owned_food"].get(food_id,0)) <= 0:
		_notify("The pantry is empty. Visit the food shop.")
		return false
	if float(data["needs"]["hunger"]) >= 95.0:
		_notify("I'm full, thank you!")
		return false
	_wait(2.0)
	if food_id != "basic":
		data["owned_food"][food_id] = int(data["owned_food"][food_id]) - 1
	Needs.change(data,Economy.FOOD_EFFECTS[food_id])
	_stat("feed")
	add_xp(5)
	action.emit("feed")
	_commit()
	return true

func care(kind: String) -> bool:
	if kind in ["wake","stop_charge"]:
		if not _session.is_empty():
			return false
		if kind == "wake":
			data["is_sleeping"] = false
		else:
			data["is_charging"] = false
		_busy_until = 0
		action.emit(kind)
		_commit()
		return true
	if not _available(kind in ["sleep","charge"]):
		return false
	if kind in ["sleep","charge"]:
		if data["current_room"] != "bedroom":
			_notify("The bed and charging dock are in the bedroom.")
			return false
		if kind == "sleep":
			if data["is_sleeping"] or float(data["needs"]["rest"]) >= 99.0:
				_notify("I'm well rested!")
				return false
			data["is_sleeping"] = true
			data["rest_recovered"] = 0.0
			data["rest_rewarded"] = false
		else:
			if data["is_charging"] or float(data["needs"]["battery"]) >= 99.0:
				_notify("My battery is full!")
				return false
			data["is_charging"] = true
			data["charge_recovered"] = 0.0
			data["charge_rewarded"] = false
	elif kind in ["wash","rinse","dry","filter"]:
		if data["current_room"] != "bathroom":
			_notify("Let's use the bathroom for this.")
			return false
		match kind:
			"wash":
				if wash_stage != 0:
					_notify("Rinse the bubbles, then dry the shell.")
					return false
				wash_stage = 1
				_wait(1.0)
			"rinse":
				if wash_stage != 1:
					_notify("Use the sponge first.")
					return false
				wash_stage = 2
				_wait(1.0)
			"dry":
				if wash_stage != 2:
					_notify("Soap and rinse before drying.")
					return false
				wash_stage = 0
				var useful = float(data["needs"]["cleanliness"]) < 95.0
				Needs.change(data,{"cleanliness":35.0,"happiness":4.0})
				if useful:
					_stat("wash")
					add_xp(10)
				_wait(1.0)
			"filter":
				if float(data["needs"]["cleanliness"]) >= 98.0:
					_notify("The filter is already clean.")
					return false
				Needs.change(data,{"cleanliness":12.0})
				_stat("filter")
				_wait(1.5)
	elif kind in ["ball","duck","cube","music"]:
		if not kind in data["owned_items"]:
			_notify("Find this toy in the shop.")
			return false
		if float(data["needs"]["battery"]) < 8.0:
			_notify("A little charge, then we can play!")
			return false
		if not _cooldown("toy",8.0):
			return false
		Needs.change(data,{"happiness":8.0,"battery":-1.0,"cleanliness":-0.4,"rest":-0.5})
		_stat("toys")
		_wait(2.0)
	elif kind in ["pet","head","beak","body","feet","poke","shake"]:
		if not _cooldown("touch",0.5):
			return false
		if kind == "pet":
			if not _cooldown("pet",3.0):
				return false
			Needs.change(data,{"happiness":3.0})
			_stat("pet")
		elif kind in ["poke","shake"]:
			Needs.change(data,{"happiness":-0.5})
		_wait(0.35)
	else:
		return false
	action.emit(kind)
	_commit()
	return true

func _cooldown(key: String, seconds: float) -> bool:
	var now = Time.get_ticks_msec()
	if now < int(_cooldowns.get(key,0)):
		return false
	_cooldowns[key] = now + int(seconds*1000.0)
	return true

func visit_room(room: String) -> void:
	if not room in ROOMS or not _session.is_empty():
		return
	if data["current_room"] != room:
		data["is_sleeping"] = false
		data["is_charging"] = false
		wash_stage = 0
		_busy_until = 0
	data["current_room"] = room
	if not room in data["visited_rooms"]:
		data["visited_rooms"].append(room)
	_refresh_day()
	if not room in data["daily_missions"]["visited"]:
		data["daily_missions"]["visited"].append(room)
		_stat("visits")
	_commit()

func _apply_rest_recovery(recovered: Dictionary) -> void:
	data["charge_recovered"] = float(data["charge_recovered"]) + float(recovered["battery"])
	data["rest_recovered"] = float(data["rest_recovered"]) + float(recovered["rest"])
	if data["is_charging"] and not data["charge_rewarded"] and float(data["charge_recovered"]) >= 20.0:
		data["charge_rewarded"] = true
		_stat("charge")
		add_xp(5)
	if data["is_sleeping"] and not data["rest_rewarded"] and float(data["rest_recovered"]) >= 20.0:
		data["rest_rewarded"] = true
		_stat("sleep")
		add_xp(5)

func add_xp(amount: int) -> void:
	var levels = Progression.apply_xp(data,amount)
	if levels > 0:
		action.emit("level_up")
		_notify("New level! A little gift is waiting in your wallet.")
	changed.emit()

func age_days() -> int:
	return maxi(1,1 + int(maxf(0.0,Time.get_unix_time_from_system()-float(data["created_at"]))/86400.0))

func xp_required() -> int:
	return Progression.required_xp(int(data["level"]))

func _today() -> int:
	# Device-local calendar date: one task set per day, even across DST changes.
	return int(Time.get_unix_time_from_datetime_string(Time.get_date_string_from_system(false)+"T00:00:00")/86400)

func _refresh_day() -> void:
	var today = _today()
	if data["daily_missions"].is_empty() or today > int(data["daily_missions"].get("day",-1)):
		data["daily_missions"] = {"day":today,"progress":{},"claimed":[],"visited":[]}
	# Turning the clock backwards does not reset already claimed rewards.

func _stat(key: String, amount: int = 1) -> void:
	data["stats"][key] = mini(99999999,int(data["stats"].get(key,0))+maxi(0,amount))
	_refresh_day()
	var progress: Dictionary = data["daily_missions"]["progress"]
	progress[key] = mini(99999999,int(progress.get(key,0))+maxi(0,amount))

func daily_tasks() -> Array:
	_refresh_day()
	var patterns = [["feed","pet","games"],["visits","wash","score"],["charge","pet","games"]]
	var chosen: Array = patterns[int(data["daily_missions"]["day"]) % patterns.size()]
	var definitions = {
		"feed":["Snack time","Feed your friend twice.",2,35],
		"pet":["A gentle touch","Stroke your friend five times.",5,30],
		"games":["Play date","Finish two mini-games.",2,50],
		"visits":["Little explorer","Visit three different rooms.",3,30],
		"wash":["Bubble bath","Finish a soap, rinse and dry cycle.",1,35],
		"score":["A bright score","Earn 100 points across mini-games.",100,45],
		"charge":["Recharge together","Restore 20 battery on the dock.",1,35]}
	var result: Array = []
	for key in chosen:
		var row: Array = definitions[key]
		result.append({"id":key,"name":row[0],"description":row[1],"progress":mini(int(data["daily_missions"]["progress"].get(key,0)),int(row[2])),"target":int(row[2]),"reward":int(row[3]),"claimed":key in data["daily_missions"]["claimed"]})
	return result

func achievement_list() -> Array:
	return Progression.achievement_rows(data,age_days())

func claim_task(task_id: String) -> bool:
	for task in daily_tasks():
		if task["id"] == task_id and not task["claimed"] and int(task["progress"]) >= int(task["target"]):
			data["daily_missions"]["claimed"].append(task_id)
			_reward(int(task["reward"]),20)
			_commit()
			return true
	return false

func claim_achievement(achievement_id: String) -> bool:
	for achievement in achievement_list():
		if achievement["id"] == achievement_id and not achievement["claimed"] and int(achievement["progress"]) >= int(achievement["target"]):
			data["achievements"].append(achievement_id)
			_reward(int(achievement["reward"]),20)
			_commit()
			return true
	return false

func _reward(coins: int, xp: int) -> void:
	data["coins"] = mini(9999999,int(data["coins"])+maxi(0,coins))
	_stat("coins_earned",coins)
	add_xp(xp)
	action.emit("reward")

func complete_tutorial() -> void:
	data["completed_tutorial"] = true
	data["tutorial_step"] = 8
	if not data["tutorial_rewarded"]:
		data["tutorial_rewarded"] = true
		_reward(50,20)
	_commit()

func _canonical_game(game_id: String) -> String:
	var aliases = {"CatchChips":"catch","RollerDuck":"roller","MemoryLights":"memory","BatterySort":"sort","DuckBeat":"beat","DuckTreasure":"treasure"}
	return str(aliases.get(game_id,game_id))

func begin_minigame(game_id: String) -> String:
	var game = _canonical_game(game_id)
	if not game in GAMES or not _available():
		return ""
	if float(data["needs"]["battery"]) < 8.0:
		_notify("Charge your battery before the next adventure.")
		return ""
	_session_serial += 1
	var token = "%d-%d-%d" % [Time.get_ticks_usec(),_session_serial,randi()]
	_session = {"token":token,"game":game,"started":Time.get_ticks_msec()}
	return token

func finish_minigame(token: String, score: int, won: bool, aborted: bool = false) -> Dictionary:
	var no_reward = {"coins":0,"xp":0,"new_record":false,"score":0,"won":false}
	if _session.is_empty() or token != str(_session.get("token","")):
		return no_reward
	var session = _session.duplicate()
	_session.clear() # Consume before any signal, save or reward can re-enter.
	if aborted:
		changed.emit()
		return no_reward
	var game: String = session["game"]
	var final_score = clampi(score,0,100000)
	var coins = clampi(10+int(final_score/6)+(10 if won else 0),10,100)
	var xp = clampi(15+int(final_score/25)+(5 if won else 0),15,35)
	var record = final_score > int(data["minigame_records"].get(game,0))
	if record:
		data["minigame_records"][game] = final_score
	if not game in data["played_games"]:
		data["played_games"].append(game)
	Needs.change(data,{"happiness":10.0 if won else 5.0,"battery":-4.0,"rest":-2.0,"cleanliness":-1.5})
	_stat("games")
	_stat("score",final_score)
	if won:
		_stat("wins")
	_reward(coins,xp)
	_commit()
	return {"coins":coins,"xp":xp,"new_record":record,"score":final_score,"won":won}

func set_setting(key: String, value: Variant) -> void:
	if key in ["music","sfx"]:
		data["settings"][key] = _num(value,float(data["settings"][key]),0.0,1.0)
	elif key == "vibration" and value is bool:
		data["settings"][key] = value
	elif key == "quality" and str(value) in ["low","high"]:
		data["settings"][key] = str(value)
	elif key == "language" and str(value) in ["ru","en","uz"]:
		data["settings"][key] = str(value)
	else:
		return
	_commit()

func _clean_name(value: String) -> String:
	var result = value.strip_edges().replace("\n"," ").replace("\r"," ").replace("\t"," ").substr(0,16)
	return "Кряк" if result.is_empty() else result

func rename_pet(value: String) -> void:
	data["pet_name"] = _clean_name(value)
	_commit()

func _check_anniversary() -> void:
	var years = int((age_days()-1)/7)
	if years > int(data["anniversary_claimed"]):
		data["anniversary_claimed"] = years
		_reward(50,10)

func _check_warning() -> void:
	var warning = ""
	if float(data["needs"]["battery"]) < 15.0 and not data["is_charging"]:
		warning = "My battery needs a little sunshine from the dock."
	elif float(data["needs"]["hunger"]) < 20.0:
		warning = "A crunchy microchip would be lovely."
	elif float(data["needs"]["cleanliness"]) < 20.0:
		warning = "Time for a bubble bath?"
	elif float(data["needs"]["rest"]) < 20.0 and not data["is_sleeping"]:
		warning = "My little servos need some rest."
	if warning != _last_warning:
		_last_warning = warning
		if not warning.is_empty():
			_notify(warning)

func reset_progress() -> void:
	SaveStore.remove_game(save_path)
	data = defaults()
	_session.clear()
	_cooldowns.clear()
	wash_stage = 0
	_busy_until = 0
	_last_warning = ""
	_paused_at = -1.0
	_refresh_day()
	cosmetics_changed.emit()
	_commit()
