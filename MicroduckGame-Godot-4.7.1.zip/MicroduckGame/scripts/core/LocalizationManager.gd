extends Node
## English source strings are stable keys. All translations live in one JSON file.

signal language_changed

const SUPPORTED: Array[String] = ["ru", "en", "uz"]
const DISPLAY_NAMES = {"ru": "Русский", "en": "English", "uz": "O‘zbek"}
var language: String = "ru"
var translations: Dictionary = {}

func _ready() -> void:
	var path: String = "res://resources/localization/strings.json"
	if FileAccess.file_exists(path):
		var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
		if parsed is Dictionary:
			translations = parsed

func t(source: String) -> String:
	if language == "en":
		return source
	var row = translations.get(source, {})
	if row is Dictionary:
		return str(row.get(language, source))
	return source

func set_language(code: String) -> void:
	var selected: String = code if code in SUPPORTED else "ru"
	if language == selected:
		return
	language = selected
	language_changed.emit()

func available_languages() -> Dictionary:
	return DISPLAY_NAMES.duplicate()
