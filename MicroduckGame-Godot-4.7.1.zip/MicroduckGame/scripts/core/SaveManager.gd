extends RefCounted
## Atomic replacement, integrity check, recovery copy and legacy JSON migration.
const FORMAT_VERSION = 2

static func read_game(path: String) -> Dictionary:
	var primary = _read_one(path)
	if not primary.is_empty():
		return {"data":primary,"recovered":false,"failed":false}
	var backup = _read_one(path + ".bak")
	if not backup.is_empty():
		return {"data":backup,"recovered":true,"failed":false}
	return {"data":{},"recovered":false,"failed":FileAccess.file_exists(path)}

static func _read_one(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {}
	var f = FileAccess.open(path, FileAccess.READ)
	if f == null or f.get_length() > 2 * 1024 * 1024:
		return {}
	var parser = JSON.new()
	if parser.parse(f.get_as_text()) != OK:
		return {}
	var parsed = parser.data
	if not parsed is Dictionary:
		return {}
	if parsed.has("format"):
		if not parsed.get("data") is Dictionary:
			return {}
		var payload: Dictionary = parsed["data"]
		if str(parsed.get("checksum", "")) != JSON.stringify(payload).sha256_text():
			return {}
		return payload
	# Version 1 saves stored fields directly, without a checksum envelope.
	if parsed.has("pet_name") or parsed.has("needs") or parsed.has("coins"):
		return parsed
	return {}

static func write_game(path: String, data: Dictionary) -> bool:
	var temp = path + ".tmp"
	# Godot JSON numbers load as floats. Normalize before computing the digest so
	# an integral field (500) and its parsed representation (500.0) agree.
	var normalized = JSON.parse_string(JSON.stringify(data))
	var encoded = JSON.stringify(normalized)
	var envelope = {"format":FORMAT_VERSION,"checksum":encoded.sha256_text(),"data":normalized}
	var f = FileAccess.open(temp, FileAccess.WRITE)
	if f == null:
		return false
	f.store_string(JSON.stringify(envelope, "\t"))
	f.flush()
	var error = f.get_error()
	f.close()
	if error != OK:
		return false
	# Never overwrite the recovery copy with a corrupt primary.
	if not _read_one(path).is_empty():
		if DirAccess.copy_absolute(path, path + ".bak") != OK:
			return false
	if DirAccess.rename_absolute(temp, path) != OK:
		return false
	# The very first save also has a recovery copy.
	if not FileAccess.file_exists(path + ".bak"):
		DirAccess.copy_absolute(path, path + ".bak")
	return true

static func remove_game(path: String) -> void:
	for suffix in ["", ".bak", ".tmp"]:
		if FileAccess.file_exists(path + suffix):
			DirAccess.remove_absolute(path + suffix)
