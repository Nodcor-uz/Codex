extends RefCounted
## All time balance lives here. Rates are units per real hour.
const RATES = {"hunger":12.0,"happiness":9.0,"cleanliness":7.0,"battery":14.0,"rest":10.0}
const OFFLINE_CAP = 8.0 * 3600.0
const CHARGE_PER_SECOND = 0.8
const REST_PER_SECOND = 0.65

static func advance(data: Dictionary, seconds: float, offline: bool = false) -> Dictionary:
	var elapsed = clampf(seconds, 0.0, OFFLINE_CAP if offline else 60.0)
	var needs: Dictionary = data["needs"]
	var before_battery = float(needs["battery"])
	var before_rest = float(needs["rest"])
	var sleeping: bool = data.get("is_sleeping", false)
	var charging: bool = data.get("is_charging", false)
	for key in RATES:
		var rate = float(RATES[key])
		if sleeping:
			rate *= 0.25
		if key == "battery" and charging:
			needs[key] = clampf(float(needs[key]) + CHARGE_PER_SECOND * elapsed, 0.0, 100.0)
		elif key == "rest" and sleeping:
			needs[key] = clampf(float(needs[key]) + REST_PER_SECOND * elapsed, 0.0, 100.0)
		else:
			# A prolonged absence never kills or permanently blocks the pet.
			needs[key] = clampf(float(needs[key]) - rate * elapsed / 3600.0, 5.0, 100.0)
	return {"battery":maxf(0.0,float(needs["battery"])-before_battery),"rest":maxf(0.0,float(needs["rest"])-before_rest)}

static func change(data: Dictionary, amounts: Dictionary) -> void:
	for key in amounts:
		if data["needs"].has(key):
			data["needs"][key] = clampf(float(data["needs"][key]) + float(amounts[key]), 0.0, 100.0)
