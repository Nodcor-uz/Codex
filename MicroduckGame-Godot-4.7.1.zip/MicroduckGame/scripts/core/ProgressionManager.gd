extends RefCounted
const MAX_LEVEL = 50

static func required_xp(level: int) -> int:
	return 60 + (level - 1) * 25 + int(pow(maxi(0, level - 1), 1.5) * 3.0)

static func apply_xp(data: Dictionary, amount: int) -> int:
	if int(data["level"]) >= MAX_LEVEL:
		data["xp"] = 0
		return 0
	data["xp"] = int(data["xp"]) + clampi(amount, 0, 100000)
	var gained = 0
	while int(data["level"]) < MAX_LEVEL and int(data["xp"]) >= required_xp(int(data["level"])):
		data["xp"] = int(data["xp"]) - required_xp(int(data["level"]))
		data["level"] = int(data["level"]) + 1
		var coins = 40 + int(data["level"]) * 5
		data["coins"] = mini(9999999,int(data["coins"]) + coins)
		data["stats"]["coins_earned"] = int(data["stats"].get("coins_earned",0)) + coins
		gained += 1
	if int(data["level"]) >= MAX_LEVEL:
		data["xp"] = 0
	return gained

static func achievement_rows(data: Dictionary, age: int) -> Array:
	var stats: Dictionary = data.get("stats",{})
	var definitions = [
		["hello","Hello, little friend!","Complete the introduction.",int(data.get("completed_tutorial",false)),1,30],
		["first_food","First snack","Feed your robot once.",stats.get("feed",0),1,25],
		["first_sleep","Sweet dreams","Restore 20 rest with sleep.",stats.get("sleep",0),1,25],
		["first_charge","Fully connected","Restore 20 battery on the dock.",stats.get("charge",0),1,25],
		["first_bath","Squeaky clean","Finish a bath: soap, rinse and dry.",stats.get("wash",0),1,30],
		["first_game","Let's play!","Finish your first mini-game.",stats.get("games",0),1,25],
		["ten_wins","Little champion","Win ten mini-games.",stats.get("wins",0),10,120],
		["coin_collector","Coin collector","Earn 1,000 coins through play.",stats.get("coins_earned",0),1000,100],
		["level_five","Growing together","Reach level 5.",data.get("level",1),5,100],
		["level_ten","Best friends","Reach level 10.",data.get("level",1),10,150],
		["first_skin","Fresh look","Buy your first new shell color.",stats.get("skins_bought",0),1,40],
		["three_days","Three sunny days","Spend three real days together.",age,3,50],
		["seven_days","A week together","Spend seven real days together.",age,7,100],
		["memory_master","Bright memory","Score 80 in Memory Lights.",data.get("minigame_records",{}).get("memory",0),80,80],
		["decorator","Home, sweet home","Equip your first decoration.",stats.get("decorations",0),1,40],
		["gentle_hands","Gentle hands","Stroke your robot twenty times.",stats.get("pet",0),20,50],
		["explorer","Every corner","Visit all seven rooms.",data.get("visited_rooms",[]).size(),7,60],
		["all_games","Arcade explorer","Finish all six different mini-games.",data.get("played_games",[]).size(),6,120]]
	var result: Array = []
	for row in definitions:
		result.append({"id":row[0],"name":row[1],"description":row[2],"progress":mini(int(row[3]),int(row[4])),"target":int(row[4]),"reward":int(row[5]),"claimed":row[0] in data.get("achievements",[])})
	return result
