extends RefCounted

const INK = Color("303a40")
const MUTED = Color("71817f")
const CREAM = Color("fffaf1")
const ORANGE = Color("f58a4a")
const AQUA = Color("a7dcd7")
const LAVENDER = Color("c4b6df")
const MINT = Color("b7dcb5")
const GOLD = Color("f7cc65")

static func style(color:Color, radius:int=24, border:Color=Color.TRANSPARENT, width:int=0, shadow:bool=false)->StyleBoxFlat:
	var s = StyleBoxFlat.new()
	s.bg_color=color
	s.set_corner_radius_all(radius)
	s.set_border_width_all(width)
	s.border_color=border
	s.content_margin_left=20
	s.content_margin_right=20
	s.content_margin_top=12
	s.content_margin_bottom=12
	if shadow:
		s.shadow_color=Color(0.16,0.24,0.23,0.10)
		s.shadow_size=12
		s.shadow_offset=Vector2(0,5)
	return s

static func theme()->Theme:
	var t = Theme.new()
	if ResourceLoader.exists("res://assets/fonts/NotoSans-Regular.ttf"):
		t.default_font=load("res://assets/fonts/NotoSans-Regular.ttf")
	t.default_font_size=22
	t.set_color("font_color","Label",INK)
	t.set_color("font_color","Button",INK)
	t.set_color("font_hover_color","Button",INK)
	t.set_color("font_pressed_color","Button",INK)
	t.set_color("font_disabled_color","Button",Color("9eaaa4"))
	t.set_stylebox("normal","Button",style(CREAM,22,Color("e3e8df"),1,true))
	t.set_stylebox("hover","Button",style(Color("f3f4e6"),22,Color("b4ccc1"),2,true))
	t.set_stylebox("pressed","Button",style(Color("e3eadc"),22))
	t.set_stylebox("disabled","Button",style(Color("e9ece5"),22))
	t.set_stylebox("focus","Button",style(Color.TRANSPARENT,22,AQUA,3))
	t.set_stylebox("normal","LineEdit",style(Color("edf2e9"),18))
	t.set_stylebox("focus","LineEdit",style(Color("f4f7f0"),18,AQUA,2))
	t.set_color("font_color","LineEdit",INK)
	t.set_color("font_placeholder_color","LineEdit",MUTED)
	t.set_stylebox("background","ProgressBar",style(Color("e4e9df"),6))
	t.set_stylebox("fill","ProgressBar",style(MINT,6))
	t.set_constant("separation","VBoxContainer",14)
	t.set_constant("separation","HBoxContainer",12)
	return t

static func label(text:String, font_size:int=22, color:Color=INK)->Label:
	var l = Label.new()
	l.text=text
	l.add_theme_font_size_override("font_size",font_size)
	l.add_theme_color_override("font_color",color)
	l.mouse_filter=Control.MOUSE_FILTER_IGNORE
	return l

static func icon(name:String)->Texture2D:
	var p = "res://assets/icons/%s.svg" % name
	return load(p) if ResourceLoader.exists(p) else null

static func button(text:String, callback:Callable=Callable(), color:Color=CREAM, icon_name:String="")->Button:
	var b = Button.new()
	b.text=text
	b.custom_minimum_size=Vector2(0,66)
	b.add_theme_stylebox_override("normal",style(color,22,Color("e0e5da"),1,true))
	b.add_theme_stylebox_override("hover",style(color.lightened(0.06),22,Color("b0c4b4"),2,true))
	b.add_theme_stylebox_override("pressed",style(color.darkened(0.09),22))
	b.mouse_default_cursor_shape=Control.CURSOR_POINTING_HAND
	if not icon_name.is_empty():
		b.icon=icon(icon_name)
		b.expand_icon=true
		b.add_theme_constant_override("icon_max_width",30)
	if callback.is_valid():
		b.pressed.connect(callback)
	b.button_down.connect(func():
		b.pivot_offset=b.size*0.5
		b.create_tween().tween_property(b,"scale",Vector2(0.97,0.97),0.07)
	)
	b.button_up.connect(func(): b.create_tween().tween_property(b,"scale",Vector2.ONE,0.12))
	return b

static func wrap(child:Control, color:Color=CREAM, radius:int=24)->PanelContainer:
	var p=PanelContainer.new()
	p.add_theme_stylebox_override("panel",style(color,radius,Color.TRANSPARENT,0,true))
	p.add_child(child)
	return p

static func margins(child:Control, amount:int=24)->MarginContainer:
	var m=MarginContainer.new()
	for side in ["left","top","right","bottom"]:
		m.add_theme_constant_override("margin_"+side,amount)
	m.add_child(child)
	return m
