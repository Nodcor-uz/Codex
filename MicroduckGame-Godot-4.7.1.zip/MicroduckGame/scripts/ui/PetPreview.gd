extends SubViewportContainer

var viewport:SubViewport
var pet:Node3D
var spin=0.0

func _ready()->void:
	custom_minimum_size=Vector2(0,300)
	stretch=true
	mouse_filter=Control.MOUSE_FILTER_IGNORE
	viewport=SubViewport.new()
	viewport.size=Vector2i(500,300)
	viewport.transparent_bg=true
	viewport.own_world_3d=true
	viewport.render_target_update_mode=SubViewport.UPDATE_ALWAYS
	add_child(viewport)
	var world=Node3D.new()
	viewport.add_child(world)
	var env=WorldEnvironment.new()
	var e=Environment.new()
	e.background_mode=Environment.BG_COLOR
	e.background_color=Color("e9efe4")
	e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color=Color.WHITE
	e.ambient_light_energy=0.24
	env.environment=e
	world.add_child(env)
	var sun=DirectionalLight3D.new()
	sun.rotation_degrees=Vector3(-35,-25,0)
	sun.light_energy=0.48
	world.add_child(sun)
	pet=load("res://scenes/pet/Microduck.tscn").instantiate()
	world.add_child(pet)
	pet.set_skin(State.data.equipped_skin)
	pet.set_accessory(State.data.equipped_accessory)
	if pet.has_method("set_part_color"):
		for part in State.data.get("part_colors",{}):pet.set_part_color(part,Color(State.data.part_colors[part]))
	var camera=Camera3D.new()
	camera.projection=Camera3D.PROJECTION_ORTHOGONAL
	camera.size=4.1
	camera.position=Vector3(3,2.8,7)
	world.add_child(camera)
	camera.look_at(Vector3(0,1.65,0))
	camera.current=true

func apply_item(item:Dictionary)->void:
	if not is_instance_valid(pet):return
	match item.kind:
		"skin":pet.set_skin(item.id)
		"accessory":pet.set_accessory(item.id)
		"lens","beak","rollers":
			if pet.has_method("set_part_color"):pet.set_part_color(item.kind,Color(item.get("color","ffffff")))

func _process(delta:float)->void:
	if is_instance_valid(pet):
		spin+=delta
		pet.rotation.y=sin(spin*0.6)*0.3
