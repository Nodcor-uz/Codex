extends Control

signal closed
signal requested(kind:String,payload:Variant)

const U=preload("res://scripts/ui/UITheme.gd")
const Preview=preload("res://scripts/ui/PetPreview.gd")
const GAME_IDS=["catch","roller","memory","sort","beat","treasure"]
const GAME_NAMES=["Catch the Chips","Roller Duck","Memory Lights","Battery Sort","Duck Beat","Duck Treasure"]
const GAME_DESCRIPTIONS=["Catch treats. Dodge broken parts.","Three lanes, little wheels, big adventure.","Watch the lights. Repeat the pattern.","Drag each battery to its matching dock.","Find the rhythm. Tap right on time.","Follow the clues and uncover a treasure."]
var panel:PanelContainer
var content:VBoxContainer
var scroll:ScrollContainer
var current=""
var category="food"
var owned_only=false
var return_screen=""

func _ready()->void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	theme=U.theme()
	visible=false

func clear()->void:
	for child in get_children():
		remove_child(child)
		child.queue_free()

func shell(title:String, subtitle:String="", allow_close:bool=true)->void:
	clear()
	visible=true
	var dim=ColorRect.new()
	dim.color=Color(0.12,0.19,0.19,0.40)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)
	panel=PanelContainer.new()
	panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	panel.offset_left=22
	panel.offset_right=-22
	panel.offset_top=84
	panel.offset_bottom=-30
	panel.add_theme_stylebox_override("panel",U.style(U.CREAM,32))
	add_child(panel)
	var outer=VBoxContainer.new()
	outer.add_theme_constant_override("separation",18)
	panel.add_child(outer)
	var header=HBoxContainer.new()
	outer.add_child(header)
	var title_label=U.label(L.t(title),30)
	title_label.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	title_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	header.add_child(title_label)
	if allow_close:
		var x=U.button("",hide_panel,U.AQUA,"close")
		x.custom_minimum_size=Vector2(56,56)
		header.add_child(x)
	if not subtitle.is_empty():
		var sub=U.label(subtitle,19,U.MUTED)
		sub.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
		outer.add_child(sub)
	scroll=ScrollContainer.new()
	scroll.size_flags_vertical=Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED
	outer.add_child(scroll)
	content=VBoxContainer.new()
	content.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation",16)
	scroll.add_child(content)
	panel.modulate.a=0
	create_tween().tween_property(panel,"modulate:a",1.0,0.16)

func hide_panel()->void:
	visible=false
	clear()
	closed.emit()

func paragraph(text:String, font_size:int=21, color:Color=U.INK)->Label:
	var l=U.label(text,font_size,color)
	l.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	content.add_child(l)
	return l

func button(text:String, fn:Callable, color:Color=U.CREAM, ico:String="")->Button:
	var b=U.button(L.t(text),fn,color,ico)
	content.add_child(b)
	return b

func show_screen(id:String)->void:
	current=id
	match id:
		"shop","shop_food":show_catalog("food",false)
		"food":show_food()
		"wardrobe":show_catalog("skin",false)
		"decor":show_catalog("furniture",false)
		"toys":show_toys()
		"minigames":show_games()
		"tasks":show_tasks(false)
		"achievements":show_tasks(true)
		"settings":show_settings()
		"collection":show_collection()
		"welcome":show_welcome()
		"about":show_about()

func show_catalog(kind:String="food",owned:bool=false)->void:
	category=kind
	owned_only=owned
	shell("Workshop collection" if current=="wardrobe" else "Duck shop",L.t("Duck Coins")+"  ·  "+str(State.data.coins))
	var tabs=HBoxContainer.new()
	var tab_scroll=ScrollContainer.new()
	tab_scroll.vertical_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED
	tab_scroll.add_child(tabs)
	content.add_child(tab_scroll)
	for entry in [["food","Food"],["skin","Skins"],["lens","Lenses"],["beak","Beaks"],["rollers","Rollers"],["accessory","Accessories"],["furniture","Decor"],["toy","Toys"]]:
		var id=entry[0]
		var tab=U.button(L.t(entry[1]),func():show_catalog(id,owned_only),U.AQUA if id==kind else Color("edf0e6"))
		tab.add_theme_font_size_override("font_size",18)
		tab.custom_minimum_size.y=52
		tabs.add_child(tab)
	for item in State.catalog:
		if item.kind!=kind:continue
		var is_owned=item.id in State.data.owned_items
		if owned and not is_owned:continue
		var box=VBoxContainer.new()
		var card=U.wrap(box,Color("f0f2e8"))
		content.add_child(card)
		var row=HBoxContainer.new()
		box.add_child(row)
		var swatch=ColorRect.new()
		swatch.custom_minimum_size=Vector2(9,52)
		swatch.color=_item_color(item)
		row.add_child(swatch)
		var text_box=VBoxContainer.new()
		text_box.size_flags_horizontal=Control.SIZE_EXPAND_FILL
		row.add_child(text_box)
		var title=U.label(L.t(item.name),22)
		title.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
		text_box.add_child(title)
		var desc=U.label(L.t(item.description),17,U.MUTED)
		desc.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
		text_box.add_child(desc)
		var controls=HBoxContainer.new()
		box.add_child(controls)
		var item_id=String(item.id)
		if kind in ["skin","accessory","lens","beak","rollers"]:
			var preview_btn=U.button(L.t("Preview"),func():show_preview(item),U.CREAM)
			preview_btn.size_flags_horizontal=Control.SIZE_EXPAND_FILL
			controls.add_child(preview_btn)
		var buy_text=L.t("Equip") if is_owned and kind!="food" else "%s  %d" % [L.t("Buy"),item.price]
		if kind=="toy" and is_owned:buy_text=L.t("Play")
		if int(item.price)==0 and kind=="food":buy_text=L.t("Free")
		var b=U.button(buy_text,func():
			if is_owned and kind!="food":
				if kind=="toy":requested.emit("toy",item_id)
				else:
					State.equip(item_id)
					show_catalog(kind,owned_only)
			else:confirm_purchase(item)
		,U.GOLD if not is_owned else U.AQUA)
		b.size_flags_horizontal=Control.SIZE_EXPAND_FILL
		controls.add_child(b)
		if int(State.data.level)<int(item.level):
			b.disabled=true
			b.text=L.t("Level")+" "+str(item.level)
		if kind=="food":
			box.add_child(U.label(L.t("In pantry")+": "+str(State.data.owned_food.get(item.id,0)),16,U.MUTED))
	button("Back to home",hide_panel,U.CREAM,"home")

func _item_color(item:Dictionary)->Color:
	if item.has("color"):return Color(item.color)
	var colors={"classic":U.ORANGE,"lavender":U.LAVENDER,"sky":U.AQUA,"graphite":Color("475258"),"mint":U.MINT,"golden":U.GOLD,"neon":Color("48c4bb"),"candy":Color("edb4c2")}
	return colors.get(item.id,U.ORANGE)

func confirm_purchase(item:Dictionary)->void:
	shell("Add to your collection?",L.t("Purchases use earned Duck Coins only."))
	paragraph(L.t(item.name),30)
	paragraph(L.t(item.description))
	paragraph("%d  %s" % [item.price,L.t("Duck Coins")],32,U.ORANGE)
	paragraph(L.t("Balance")+": "+str(State.data.coins),20,U.MUTED)
	button("Confirm purchase",func():
		if State.buy(item.id):Audio.play("coin")
		show_catalog(category,owned_only)
	,U.GOLD,"coin")
	button("Cancel",func():show_catalog(category,owned_only))

func show_preview(item:Dictionary)->void:
	shell("Make it yours",L.t("Preview on your 3D robot"))
	var preview=Preview.new()
	preview.custom_minimum_size.y=400
	content.add_child(preview)
	preview.apply_item(item)
	paragraph(L.t(item.name),28)
	paragraph(L.t(item.description),20,U.MUTED)
	if item.id in State.data.owned_items:
		button("Equip",func():State.equip(item.id);show_catalog(category,owned_only),U.AQUA,"check")
	else:
		var buy=button("Buy",func():confirm_purchase(item),U.GOLD,"coin")
		buy.text+=" · "+str(item.price)
		buy.disabled=int(State.data.level)<int(item.level)
		if buy.disabled:paragraph(L.t("Level")+" "+str(item.level))
	button("Back",func():show_catalog(category,owned_only),U.CREAM,"back")

func show_food()->void:
	shell("A bite of happiness",L.t("Choose a treat, then tap it or drag it to the beak."))
	for item in State.catalog:
		if item.kind!="food":continue
		var count=int(State.data.owned_food.get(item.id,0))
		if count<=0 and int(item.price)!=0:continue
		var food_id=String(item.id)
		var b=button(item.name,func():hide_panel();requested.emit("select_food",food_id),U.CREAM,"food")
		b.text+="  ·  "+(L.t("Free") if int(item.price)==0 else "×"+str(count))
		paragraph(L.t(item.description),17,U.MUTED)
	button("Restock",func():current="shop";show_catalog("food"),U.GOLD,"shop")

func show_toys()->void:
	shell("A little playtime",L.t("Pick a toy and play together."))
	for item in State.catalog:
		if item.kind!="toy":continue
		var id=String(item.id)
		if id in State.data.owned_items:
			button(item.name,func():hide_panel();requested.emit("toy",id),U.AQUA,"games")
		else:
			button(item.name,func():current="shop";show_catalog("toy"),U.CREAM,"shop")
		paragraph(L.t(item.description),18,U.MUTED)

func show_games()->void:
	shell("Small games. Big smiles.",L.t("Play, earn coins, and make a new best score."))
	for i in range(GAME_IDS.size()):
		var id=GAME_IDS[i]
		var box=VBoxContainer.new()
		content.add_child(U.wrap(box,[U.AQUA,U.LAVENDER,U.GOLD,U.MINT,Color("f0c3b3"),Color("d8d8b2")][i]))
		var row=HBoxContainer.new()
		box.add_child(row)
		var title=U.label("0%d   %s" % [i+1,L.t(GAME_NAMES[i])],24)
		title.size_flags_horizontal=Control.SIZE_EXPAND_FILL
		title.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
		row.add_child(title)
		var b=U.button("",func():requested.emit("minigame",id),U.CREAM,"play")
		b.custom_minimum_size=Vector2(64,64)
		row.add_child(b)
		var desc=U.label(L.t(GAME_DESCRIPTIONS[i]),18)
		desc.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
		box.add_child(desc)
		var record=State.data.minigame_records.get(id,0)
		if record is Dictionary:record=record.get("score",0)
		box.add_child(U.label(L.t("Best")+" · "+str(record),17,U.MUTED))

func show_tasks(achievements:bool)->void:
	current="achievements" if achievements else "tasks"
	shell("Achievements" if achievements else "Today, together",L.t("Little moments worth celebrating.") if achievements else L.t("Three small goals. A new day, a new adventure."))
	var list=State.achievement_list() if achievements else State.daily_tasks()
	for task in list:
		var box=VBoxContainer.new()
		content.add_child(U.wrap(box,Color("eef1e7")))
		var title=U.label(L.t(task.name),23)
		title.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
		box.add_child(title)
		var desc=U.label(L.t(task.description),18,U.MUTED)
		desc.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
		box.add_child(desc)
		var bar=ProgressBar.new()
		bar.max_value=maxf(1,float(task.target))
		bar.value=float(task.progress)
		bar.show_percentage=false
		bar.custom_minimum_size.y=10
		box.add_child(bar)
		var row=HBoxContainer.new()
		box.add_child(row)
		var p=U.label("%d / %d" % [mini(int(task.progress),int(task.target)),int(task.target)],18,U.MUTED)
		p.size_flags_horizontal=Control.SIZE_EXPAND_FILL
		row.add_child(p)
		var task_id=String(task.id)
		var b=U.button(L.t("Claimed") if task.claimed else L.t("Claim")+" · "+str(task.reward),func():
			if achievements:State.claim_achievement(task_id)
			else:State.claim_task(task_id)
			Audio.play("coin")
			show_tasks(achievements)
		,U.GOLD,"coin")
		b.disabled=task.claimed or float(task.progress)<float(task.target)
		row.add_child(b)

func show_settings()->void:
	current="settings"
	shell("Settings",L.t("A home that feels like you."))
	for entry in [["music","Music"],["sfx","Sound effects"]]:
		paragraph(L.t(entry[1]),22)
		var slider=HSlider.new()
		slider.min_value=0
		slider.max_value=1
		slider.step=0.05
		slider.value=float(State.data.settings.get(entry[0],0.5))
		slider.custom_minimum_size=Vector2(0,48)
		var id=entry[0]
		slider.value_changed.connect(func(value):State.set_setting(id,value);Audio.apply_settings(State.data.settings))
		content.add_child(slider)
	var vibration=CheckButton.new()
	vibration.text=L.t("Vibration")
	vibration.button_pressed=State.data.settings.vibration
	vibration.custom_minimum_size.y=60
	vibration.toggled.connect(func(v):State.set_setting("vibration",v))
	content.add_child(vibration)
	paragraph(L.t("Language"),22)
	var langs=HBoxContainer.new()
	content.add_child(langs)
	for entry in [["ru","Русский"],["en","English"],["uz","O‘zbek"]]:
		var code=entry[0]
		var b=U.button(entry[1],func():State.set_setting("language",code);L.set_language(code);show_settings(),U.AQUA if L.language==code else U.CREAM)
		b.size_flags_horizontal=Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size",18)
		langs.add_child(b)
	paragraph(L.t("Graphics"),22)
	var quality=HBoxContainer.new()
	content.add_child(quality)
	for item in [["low","Battery saver"],["high","Soft shadows"]]:
		var q=item[0]
		var b=U.button(L.t(item[1]),func():State.set_setting("quality",q);requested.emit("quality",q);show_settings(),U.AQUA if State.data.settings.quality==q else U.CREAM)
		b.size_flags_horizontal=Control.SIZE_EXPAND_FILL
		quality.add_child(b)
	paragraph(L.t("Robot name"),22)
	var name_input=LineEdit.new()
	name_input.text=State.data.pet_name
	name_input.max_length=14
	name_input.custom_minimum_size.y=64
	content.add_child(name_input)
	button("Save name",func():State.rename_pet(name_input.text);requested.emit("message",L.t("Name saved")),U.AQUA,"check")
	button("Replay tutorial",func():hide_panel();requested.emit("tutorial",null),U.CREAM,"refresh")
	button("Pet statistics",show_collection,U.CREAM,"trophy")
	button("About the game",show_about,U.CREAM,"info")
	button("Reset progress",confirm_reset,Color("f4d9cf"))

func confirm_reset()->void:
	shell("Start a new friendship?",L.t("This removes the current robot, purchases and records from this device."))
	button("Keep my robot",show_settings,U.AQUA,"heart")
	button("Reset everything",func():State.reset_progress();hide_panel();requested.emit("reset",null),Color("f2b29d"))

func show_collection()->void:
	current="collection"
	shell("Our little story",L.t("Everything you have discovered together."))
	paragraph(State.data.pet_name,32)
	paragraph("%s %d  ·  %s %d  ·  %s %d" % [L.t("Day"),State.age_days(),L.t("Level"),State.data.level,L.t("Robot years"),int((State.age_days()-1)/7)],20,U.MUTED)
	paragraph(L.t("Time together")+": %d %s" % [int(State.data.total_play_time/60),L.t("minutes")])
	var count=0
	for row in State.achievement_list():
		if row.progress>=row.target:count+=1
	paragraph(L.t("Achievements")+": %d / %d" % [count,State.achievement_list().size()])
	paragraph(L.t("Collection"),26)
	for item in State.catalog:
		if item.kind!="food" and item.id in State.data.owned_items:paragraph("✓  "+L.t(item.name),20)
	paragraph(L.t("Open rooms"),26)
	paragraph(L.t("Living room")+" · "+L.t("Kitchen")+" · "+L.t("Bedroom")+" · "+L.t("Bathroom")+" · "+L.t("Playroom")+" · "+L.t("Workshop")+" · "+L.t("Garden"),19,U.MUTED)
	paragraph(L.t("Personal bests"),26)
	for i in range(GAME_IDS.size()):
		var record=State.data.minigame_records.get(GAME_IDS[i],0)
		if record is Dictionary:record=record.get("score",0)
		paragraph(L.t(GAME_NAMES[i])+"   ·   "+str(record),20)
	button("Wardrobe",func():current="wardrobe";show_catalog("skin"),U.AQUA,"wardrobe")

func show_welcome()->void:
	current="welcome"
	shell("Hello, little friend!",L.t("A curious little robot has arrived. What shall we call it?"),false)
	var preview=Preview.new()
	preview.custom_minimum_size.y=350
	content.add_child(preview)
	var input=LineEdit.new()
	input.text=State.data.pet_name
	input.max_length=14
	input.custom_minimum_size.y=72
	input.alignment=HORIZONTAL_ALIGNMENT_CENTER
	content.add_child(input)
	button("Let's be friends",func():State.rename_pet(input.text);hide_panel();requested.emit("tutorial",null),U.ORANGE,"heart")
	button("Skip tutorial",func():State.rename_pet(input.text);State.complete_tutorial();hide_panel(),U.CREAM)
	paragraph(L.t("Your progress stays on this device. No account or internet needed."),18,U.MUTED)

func show_about()->void:
	shell("MICRODUCK",L.t("My Little Robot"))
	paragraph(L.t("A little robot. A home full of discoveries."),28)
	paragraph(L.t("Care, play, collect. Your robot will always be happy to see you again."))
	paragraph("Godot Engine 4.6 · GDScript",19,U.MUTED)
	paragraph(L.t("Original procedural 3D art, icons, sounds and music. Offline. No ads. No purchases with real money."),20,U.MUTED)
	button("Back",show_settings,U.AQUA,"back")

func show_results(id:String,score:int,won:bool,rewards:Dictionary)->void:
	current="results"
	shell("A little victory!" if won else "Nice try, little explorer!",L.t("Every adventure teaches something new."))
	var index=GAME_IDS.find(id)
	paragraph(L.t(GAME_NAMES[index]) if index>=0 else id,26,U.MUTED)
	paragraph(str(score),72,U.ORANGE)
	paragraph(L.t("Points"),23,U.MUTED)
	paragraph("+%d %s    +%d XP" % [rewards.get("coins",0),L.t("Duck Coins"),rewards.get("xp",0)],28)
	if rewards.get("new_record",false):paragraph(L.t("A new personal best!"),26,U.ORANGE)
	button("Play again",func():requested.emit("minigame",id),U.AQUA,"play")
	button("More mini-games",show_games,U.CREAM,"games")
	button("Back to home",func():hide_panel();requested.emit("room","living"),U.CREAM,"home")
