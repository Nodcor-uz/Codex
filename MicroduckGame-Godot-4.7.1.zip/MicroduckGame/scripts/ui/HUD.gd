extends Control

signal room_requested(id:String)
signal panel_requested(id:String)
signal action_requested(id:String)
signal need_requested(id:String)

const U=preload("res://scripts/ui/UITheme.gd")
const Badge=preload("res://scripts/ui/LevelBadge.gd")
const ROOMS={"living":"Living room","kitchen":"Kitchen","bedroom":"Bedroom","bathroom":"Bathroom","games":"Playroom","workshop":"Workshop","garden":"Garden"}
const NEEDS=["hunger","happiness","cleanliness","battery","rest"]
const NEED_NAMES=["Food","Joy","Clean","Battery","Rest"]
const NEED_ICONS=["food","heart","clean","battery","moon"]
const COLORS=[U.ORANGE,U.MINT,U.AQUA,U.GOLD,U.LAVENDER]
var badge:Control
var name_label:Label
var age_label:Label
var coins_button:Button
var room_label:Label
var room_subtitle:Label
var needs:Array=[]
var nav:HBoxContainer
var actions:HBoxContainer
var actions_title:Label
var thought:Label
var tutorial_label:Label
var tutorial_box:PanelContainer
var bottom:VBoxContainer
var top:MarginContainer
var current_room=""
var sleep_state=false
var charge_state=false
var wash_stage=-1
var toast_tween:Tween

func _ready()->void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter=Control.MOUSE_FILTER_IGNORE
	theme=U.theme()
	_build()
	refresh()

func _build()->void:
	top=MarginContainer.new()
	top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	top.add_theme_constant_override("margin_left",24)
	top.add_theme_constant_override("margin_right",24)
	top.add_theme_constant_override("margin_top",22)
	top.mouse_filter=Control.MOUSE_FILTER_IGNORE
	add_child(top)
	var v=VBoxContainer.new()
	v.add_theme_constant_override("separation",14)
	v.mouse_filter=Control.MOUSE_FILTER_IGNORE
	top.add_child(v)
	var brand=U.label("M I C R O D U C K",17,U.MUTED)
	v.add_child(brand)
	var row=HBoxContainer.new()
	row.mouse_filter=Control.MOUSE_FILTER_IGNORE
	v.add_child(row)
	badge=Badge.new()
	row.add_child(badge)
	var profile=VBoxContainer.new()
	profile.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	profile.add_theme_constant_override("separation",1)
	profile.alignment=BoxContainer.ALIGNMENT_CENTER
	profile.mouse_filter=Control.MOUSE_FILTER_IGNORE
	row.add_child(profile)
	name_label=U.label("Microduck",29)
	profile.add_child(name_label)
	age_label=U.label("",16,U.MUTED)
	profile.add_child(age_label)
	coins_button=U.button("250",func():panel_requested.emit("shop"),U.GOLD,"coin")
	coins_button.custom_minimum_size=Vector2(128,62)
	row.add_child(coins_button)
	var settings=U.button("",func():panel_requested.emit("settings"),U.CREAM,"settings")
	settings.custom_minimum_size=Vector2(62,62)
	row.add_child(settings)
	var need_row=HBoxContainer.new()
	need_row.add_theme_constant_override("separation",8)
	v.add_child(need_row)
	for i in range(5):
		var index=i
		var b=U.button("",func():need_requested.emit(NEEDS[index]),Color(1,0.99,0.95,0.94))
		b.size_flags_horizontal=Control.SIZE_EXPAND_FILL
		b.custom_minimum_size=Vector2(0,70)
		need_row.add_child(b)
		var box=VBoxContainer.new()
		box.mouse_filter=Control.MOUSE_FILTER_IGNORE
		box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		box.offset_left=12
		box.offset_right=-12
		box.offset_top=8
		box.offset_bottom=-8
		box.add_theme_constant_override("separation",5)
		b.add_child(box)
		var nr=HBoxContainer.new()
		nr.mouse_filter=Control.MOUSE_FILTER_IGNORE
		nr.alignment=BoxContainer.ALIGNMENT_CENTER
		box.add_child(nr)
		var ico=TextureRect.new()
		ico.texture=U.icon(NEED_ICONS[i])
		ico.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
		ico.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		ico.custom_minimum_size=Vector2(26,26)
		ico.mouse_filter=Control.MOUSE_FILTER_IGNORE
		nr.add_child(ico)
		var value=U.label("98",21)
		nr.add_child(value)
		var bar=ProgressBar.new()
		bar.custom_minimum_size=Vector2(0,5)
		bar.show_percentage=false
		bar.mouse_filter=Control.MOUSE_FILTER_IGNORE
		bar.add_theme_stylebox_override("fill",U.style(COLORS[i],4))
		bar.add_theme_stylebox_override("background",U.style(Color("e7e9df"),4))
		box.add_child(bar)
		needs.append({"value":value,"bar":bar,"button":b})
	var location=VBoxContainer.new()
	location.position=Vector2(30,242)
	location.mouse_filter=Control.MOUSE_FILTER_IGNORE
	location.add_theme_constant_override("separation",3)
	add_child(location)
	room_label=U.label("",30)
	location.add_child(room_label)
	room_subtitle=U.label("",17,U.MUTED)
	location.add_child(room_subtitle)
	var utilities=VBoxContainer.new()
	utilities.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	utilities.position=Vector2(-84,250)
	utilities.add_theme_constant_override("separation",14)
	add_child(utilities)
	for info in [["tasks","tasks"],["achievements","trophy"],["collection","wardrobe"]]:
		var id=info[0]
		var b=U.button("",func():panel_requested.emit(id),U.CREAM,info[1])
		b.custom_minimum_size=Vector2(60,60)
		utilities.add_child(b)
	bottom=VBoxContainer.new()
	bottom.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	bottom.offset_left=20
	bottom.offset_right=-20
	bottom.offset_top=-240
	bottom.offset_bottom=-24
	bottom.add_theme_constant_override("separation",15)
	bottom.mouse_filter=Control.MOUSE_FILTER_IGNORE
	add_child(bottom)
	actions_title=U.label("",17,U.INK)
	actions_title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	bottom.add_child(actions_title)
	actions=HBoxContainer.new()
	bottom.add_child(actions)
	nav=HBoxContainer.new()
	nav.add_theme_constant_override("separation",5)
	bottom.add_child(nav)
	thought=U.label("",20)
	thought.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	thought.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	thought.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	thought.offset_left=-275
	thought.offset_right=275
	thought.offset_top=-322
	thought.offset_bottom=-258
	thought.add_theme_stylebox_override("normal",U.style(Color(1,0.99,0.95,0.95),20))
	thought.visible=false
	add_child(thought)
	tutorial_label=U.label("",19)
	tutorial_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	tutorial_box=U.wrap(tutorial_label,Color("fff2d4"),20)
	tutorial_box.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	tutorial_box.offset_left=26
	tutorial_box.offset_right=-100
	tutorial_box.offset_top=324
	tutorial_box.visible=false
	tutorial_box.mouse_filter=Control.MOUSE_FILTER_IGNORE
	add_child(tutorial_box)
	_build_nav()

func _build_nav()->void:
	for c in nav.get_children():
		nav.remove_child(c)
		c.queue_free()
	for entry in [["living","Home","home"],["kitchen","Food","food"],["games","Games","games"],["bedroom","Sleep","sleep"],["bathroom","Bath","bath"],["shop","Shop","shop"]]:
		var id=entry[0]
		var color=U.ORANGE if State.data.current_room==id else U.CREAM
		var b=U.button("",func():
			if id=="shop":panel_requested.emit("shop")
			else:room_requested.emit(id)
		,color)
		b.size_flags_horizontal=Control.SIZE_EXPAND_FILL
		b.custom_minimum_size=Vector2(0,90)
		nav.add_child(b)
		var vb=VBoxContainer.new()
		vb.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		vb.offset_top=12
		vb.offset_bottom=-8
		vb.mouse_filter=Control.MOUSE_FILTER_IGNORE
		vb.add_theme_constant_override("separation",5)
		vb.alignment=BoxContainer.ALIGNMENT_CENTER
		b.add_child(vb)
		var tex=TextureRect.new()
		tex.texture=U.icon(entry[2])
		tex.custom_minimum_size=Vector2(32,32)
		tex.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
		tex.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		tex.mouse_filter=Control.MOUSE_FILTER_IGNORE
		vb.add_child(tex)
		var l=U.label(L.t(entry[1]),16)
		l.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
		vb.add_child(l)

func refresh()->void:
	if not is_instance_valid(badge):return
	badge.level=int(State.data.level)
	badge.progress=float(State.data.xp)/State.xp_required()
	badge.queue_redraw()
	name_label.text=State.data.pet_name
	age_label.text=L.t("Day")+" %02d · " % State.age_days()+L.t("Robot friend")
	coins_button.text=str(State.data.coins)
	for i in range(5):
		var value=float(State.data.needs[NEEDS[i]])
		needs[i].value.text=str(roundi(value))
		needs[i].bar.value=value
		needs[i].button.tooltip_text=L.t(NEED_NAMES[i])+": "+str(roundi(value))+" / 100"
	var new_room=String(State.data.current_room)
	var new_stage=int(State.wash_stage)
	if current_room!=new_room or sleep_state!=State.data.is_sleeping or charge_state!=State.data.is_charging or wash_stage!=new_stage:
		current_room=new_room
		sleep_state=State.data.is_sleeping
		charge_state=State.data.is_charging
		wash_stage=new_stage
		refresh_room()

func refresh_room()->void:
	room_label.text=L.t(ROOMS.get(State.data.current_room,"Living room"))
	var subtitles={"living":"A little place to feel at home","kitchen":"Good food, happy circuits","bedroom":"Recharge your little world","bathroom":"A fresh start, every day","games":"Big adventures. Little wheels.","workshop":"Made to be your very own","garden":"A breath of fresh air"}
	room_subtitle.text=L.t(subtitles.get(State.data.current_room,""))
	_build_nav()
	for c in actions.get_children():
		actions.remove_child(c)
		c.queue_free()
	var choices=[]
	match State.data.current_room:
		"living":choices=[["toys","Toys","games"],["workshop","Workshop","tools"],["garden","Garden","garden"]]
		"kitchen":choices=[["food","Choose food","food"],["shop_food","Restock","shop"]]
		"bedroom":choices=[["wake" if State.data.is_sleeping else "sleep","Wake up" if State.data.is_sleeping else "Sleep","moon"],["stop_charge" if State.data.is_charging else "charge","Unplug" if State.data.is_charging else "Charge","battery"]]
		"bathroom":choices=[["wash","Soap","bath"],["rinse","Rinse","clean"],["dry","Dry","sun"],["filter","Filter","tools"]]
		"games":choices=[["minigames","Mini-games","play"],["toys","Toys","games"]]
		"workshop":choices=[["wardrobe","Wardrobe","wardrobe"],["decor","Decorate","home"],["living","Home","back"]]
		"garden":choices=[["roll","Roll around","play"],["treasure","Treasure","star"],["living","Home","back"]]
	for row in choices:
		var id=row[0]
		var b=U.button(L.t(row[1]),func():action_requested.emit(id),U.CREAM,row[2])
		b.size_flags_horizontal=Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size",18)
		b.custom_minimum_size.y=64
		actions.add_child(b)
	actions_title.text=L.t("Tap or stroke your robot to say hello")
	if State.data.current_room=="bathroom":actions_title.text=L.t("Soap, rinse, then dry. A happy little routine.")
	if State.data.is_sleeping:actions_title.text=L.t("Shhh… restoring rest")
	if State.data.is_charging:actions_title.text=L.t("Battery charging")

func toast(text:String)->void:
	thought.text=text
	thought.visible=true
	thought.modulate.a=1
	if toast_tween and toast_tween.is_valid():toast_tween.kill()
	toast_tween=create_tween()
	toast_tween.tween_interval(3.6)
	toast_tween.tween_property(thought,"modulate:a",0.0,0.35)
	toast_tween.tween_callback(func():thought.visible=false)

func tutorial(text:String)->void:
	tutorial_box.visible=not text.is_empty()
	tutorial_label.text=text

func update_safe_area()->void:
	if not OS.has_feature("mobile"):return
	var safe=DisplayServer.get_display_safe_area()
	var screen=DisplayServer.screen_get_size()
	if screen.y<=0:return
	var factor=size.y/float(screen.y)
	top.add_theme_constant_override("margin_top",maxi(22,roundi(safe.position.y*factor)+8))
	bottom.offset_bottom=-maxi(24,roundi((screen.y-safe.end.y)*factor)+12)
	bottom.offset_top=bottom.offset_bottom-216
