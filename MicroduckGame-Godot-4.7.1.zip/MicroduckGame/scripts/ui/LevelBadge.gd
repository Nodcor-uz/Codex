extends Control

var level:int=1
var progress:float=0.0

func _ready()->void:
	custom_minimum_size=Vector2(70,70)
	mouse_filter=Control.MOUSE_FILTER_IGNORE

func _draw()->void:
	var center=size*0.5
	var r=minf(size.x,size.y)*0.43
	draw_circle(center,r,Color("fffaf1"),true,-1,true)
	draw_arc(center,r,-PI*0.5,PI*1.5,60,Color("dfe6dc"),5,true)
	draw_arc(center,r,-PI*0.5,-PI*0.5+TAU*maxf(progress,0.015),60,Color("f58a4a"),5,true)
	var font=get_theme_default_font()
	var txt=str(level)
	var w=font.get_string_size(txt,HORIZONTAL_ALIGNMENT_LEFT,-1,27).x
	draw_string(font,center+Vector2(-w/2,9),txt,HORIZONTAL_ALIGNMENT_LEFT,-1,27,Color("303a40"))
