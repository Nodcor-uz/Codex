extends SceneTree
## Run: godot --headless --path . --script res://tests/state_test.gd
## Uses a dedicated disposable save; never resets the player's data.
const StateScript = preload("res://scripts/core/GameState.gd")
const Saves = preload("res://scripts/core/SaveManager.gd")
const Needs = preload("res://scripts/core/PetNeeds.gd")
const Progression = preload("res://scripts/core/ProgressionManager.gd")
var checks = 0
var failures: Array[String] = []
var state: Node
var test_path = "user://microduck_state_test.json"

func _initialize() -> void:
	call_deferred("run")

func check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures.append(message)
		push_error("STATE TEST: " + message)

func fresh() -> void:
	state.data = state.defaults()
	state._session.clear()
	state._cooldowns.clear()
	state._busy_until = 0
	state.wash_stage = 0
	state._refresh_day()

func unlock_action() -> void:
	state._busy_until = 0
	state._cooldowns.clear()

func run() -> void:
	Saves.remove_game(test_path)
	state = StateScript.new()
	state.save_path = test_path
	state.autosave_enabled = false
	root.add_child(state)
	state.set_process(false)
	check(state.data["coins"] == 500,"A new player starts with 500 coins")
	check(state.achievement_list().size() >= 15,"At least 15 real achievements exist")
	var paid_foods = 0
	for item in state.catalog:
		if item["kind"] == "food" and int(item["price"]) > 0:
			paid_foods += 1
	check(paid_foods >= 6,"Six purchasable foods exist")

	# Purchases, repeated permanent items, insufficient funds, and atomic equip.
	check(state.buy("lavender"),"An affordable skin can be purchased")
	var coins = int(state.data["coins"])
	check(not state.buy("lavender"),"A permanent skin cannot be purchased twice")
	check(state.data["coins"] == coins,"A repeated purchase never charges money")
	check(state.equip("lavender"),"An owned skin can be equipped")
	check(state.data["equipped_skin"] == "lavender","Equipping updates the persistent skin")
	check(not state.equip("neon"),"An unowned skin cannot be equipped")
	check(not state.buy("neon"),"Level-locked purchases are rejected")
	state.data["coins"] = 0
	check(not state.buy("chip"),"A food purchase checks available coins")
	check(state.data["coins"] == 0,"A rejected purchase cannot make coins negative")
	state.data["coins"] = 500
	check(state.buy("lens_aqua") and state.equip("lens_aqua"),"Independent lens customization can be bought and equipped")
	check(state.data["part_colors"].get("lens") == "#9ADFE8","Equipped lens uses the catalog color")
	check(state.buy("rollers_mint") and state.equip("rollers_mint"),"Roller customization works independently")
	check(state.data["part_colors"].size() == 2,"Equipping a second part preserves the first")
	check(state.buy("plant"),"Furniture can be purchased")
	state.visit_room("living")
	check(state.equip("plant"),"Furniture can be equipped in a room")
	state.visit_room("kitchen")
	check(state.data["furniture_choices"].get("living",{}).get("plant") == "plant","Furniture persists per room")
	check(not state.data["furniture_choices"].has("kitchen"),"Decorating one room does not overwrite another")

	# Feeding cannot double consume; food restores fullness, never electrical charge.
	fresh()
	check(not state.feed("chip"),"Feeding is restricted to the kitchen")
	state.visit_room("kitchen")
	state.data["needs"]["hunger"] = 20.0
	var battery = float(state.data["needs"]["battery"])
	var food_before = int(state.data["owned_food"]["cell"])
	check(state.feed("cell"),"Food is accepted when hungry")
	check(state.data["owned_food"]["cell"] == food_before - 1,"Food is consumed exactly once")
	check(is_equal_approx(state.data["needs"]["hunger"],75.0),"The mini burger restores its advertised 55 fullness")
	check(is_equal_approx(state.data["needs"]["battery"],battery),"Food does not substitute for charging")
	check(not state.feed("cell"),"Rapid repeated feeding is blocked")
	unlock_action()
	state.data["needs"]["hunger"] = 100.0
	check(not state.feed("cookie"),"A full robot refuses additional food")
	state.data["needs"]["hunger"] = 20.0
	state.data["coins"] = 0
	check(state.feed("basic"),"Free baseline food is available with zero coins")
	check(state.data["owned_food"]["basic"] == 1,"Free baseline food cannot run out")

	# A bath is an ordered transaction; unfinished sequences award nothing.
	fresh()
	state.visit_room("bathroom")
	state.data["needs"]["cleanliness"] = 20.0
	check(not state.care("dry"),"Drying before washing and rinsing is rejected")
	check(state.care("wash"),"A bath starts with soap")
	unlock_action()
	check(not state.care("wash"),"A bath cannot restart before rinsing")
	check(state.care("rinse"),"Soap can be rinsed off")
	unlock_action()
	check(state.care("dry"),"Drying completes the bath")
	check(state.data["stats"]["wash"] == 1,"A bath counts exactly once")
	check(state.data["xp"] == 10,"A useful completed bath grants 10 XP")
	unlock_action()
	check(not state.care("dry"),"Repeated completion cannot grant XP again")
	check(state.data["xp"] == 10,"Duplicate drying does not change XP")

	# Separate and simultaneous sleep and charging; rewards require actual recovery.
	fresh()
	state.visit_room("bedroom")
	state.data["needs"]["battery"] = 20.0
	state.data["needs"]["rest"] = 20.0
	check(state.care("sleep") and state.care("charge"),"Sleep and charge can run together")
	check(state.data["is_sleeping"] and state.data["is_charging"],"Both durable modes are retained")
	check(not state.care("pet"),"Touches cannot interrupt sleep or trigger a dance")
	state._apply_rest_recovery(Needs.advance(state.data,40.0))
	check(state.data["needs"]["battery"] > 50.0 and state.data["needs"]["rest"] > 45.0,"Sleep and charging restore their separate needs")
	check(state.data["stats"]["charge"] == 1 and state.data["stats"]["sleep"] == 1,"Recovery rewards are awarded after 20 actual points")
	var xp = int(state.data["xp"])
	state._apply_rest_recovery(Needs.advance(state.data,40.0))
	check(state.data["xp"] == xp,"Continuing one charge does not duplicate its reward")
	state.visit_room("living")
	check(not state.data["is_sleeping"] and not state.data["is_charging"],"Changing rooms safely stops sleep and charging")

	# Bounded offline time with no permanent harm, and future clock handling.
	fresh()
	var one = state.data.duplicate(true)
	var two = state.data.duplicate(true)
	Needs.advance(one,8*3600,true)
	Needs.advance(two,365*86400,true)
	check(one["needs"] == two["needs"],"Offline decline is capped at eight hours")
	for value in two["needs"].values():
		check(float(value) >= 5.0 and float(value) <= 100.0,"Offline needs stay recoverable")
	var before = state.data["needs"].duplicate()
	Needs.advance(state.data,-300.0,true)
	check(state.data["needs"] == before,"Clock rollback never reverses needs")
	state._paused_at = Time.get_unix_time_from_system()-3600.0
	state._notification(Node.NOTIFICATION_APPLICATION_RESUMED)
	check(absf(float(state.data["needs"]["hunger"])-float(before["hunger"])+12.0)<0.01,"Resuming a suspended app applies elapsed offline needs")
	before = state.data["needs"].duplicate()
	state._process(60.0)
	check(state.data["needs"] == before,"The first resumed frame does not double-count offline time")
	state._notification(Node.NOTIFICATION_APPLICATION_RESUMED)
	check(state.data["needs"] == before,"Repeated resume notifications do not apply elapsed time again")

	# Mini-game rewards are single-use, score bounded, and abort-safe.
	fresh()
	var token = state.begin_minigame("CatchChips")
	check(not token.is_empty(),"A valid mini-game starts with a session token")
	check(state.begin_minigame("memory").is_empty(),"A second active session is rejected")
	coins = int(state.data["coins"])
	var result = state.finish_minigame(token,180,true)
	check(result["coins"] > 0 and result["xp"] > 0,"A completed game earns score-based rewards")
	var rewarded_coins = int(state.data["coins"])
	var repeated = state.finish_minigame(token,99999,true)
	check(repeated["coins"] == 0 and int(state.data["coins"]) == rewarded_coins,"Duplicate completion gives no second reward")
	check(state.data["minigame_records"].get("catch",0) == 180,"The actual score is retained as the record")
	token = state.begin_minigame("memory")
	var cancelled = state.finish_minigame(token,500,true,true)
	check(cancelled["coins"] == 0 and int(state.data["coins"]) == rewarded_coins,"Aborted games give no coins")
	check(not "memory" in state.data["played_games"],"An aborted game does not count as played")
	token = state.begin_minigame("sort")
	result = state.finish_minigame(token,1000000,true)
	check(int(result["coins"]) <= 100 and int(result["xp"]) <= 35,"Large scores cannot exceed reward caps")

	# Tasks/achievements and tutorials are idempotent and survive calendar rollback.
	fresh()
	var task: Dictionary = state.daily_tasks()[0]
	state.data["daily_missions"]["progress"][task["id"]] = task["target"]
	check(state.claim_task(task["id"]),"A completed task can be claimed")
	coins = int(state.data["coins"])
	check(not state.claim_task(task["id"]) and int(state.data["coins"]) == coins,"A daily task can only be claimed once")
	state.data["daily_missions"]["day"] = state._today() + 1
	state._refresh_day()
	check(task["id"] in state.data["daily_missions"]["claimed"],"Calendar rollback preserves claimed tasks")
	state.data["stats"]["feed"] = 1
	check(state.claim_achievement("first_food"),"A completed achievement is claimable")
	coins = int(state.data["coins"])
	check(not state.claim_achievement("first_food") and int(state.data["coins"]) == coins,"Achievements cannot be claimed twice")
	state.complete_tutorial()
	coins = int(state.data["coins"])
	state.complete_tutorial()
	check(int(state.data["coins"]) == coins,"Tutorial completion pays once")
	fresh()
	for i in range(20):
		unlock_action()
		state.care("head")
	check(state.data["xp"] == 0,"Repeated ordinary taps never farm XP")
	for i in range(30):
		state.add_xp(100000)
	check(state.data["level"] == 50 and state.data["xp"] == 0,"Progression reaches and safely caps at level 50")
	check(Progression.required_xp(20) > Progression.required_xp(10),"Level thresholds increase with progression")

	# Save integrity, recovery, migration, independent defaults, malformed values.
	fresh()
	state.rename_pet("A very very very long robot name\nwith lines")
	check(state.data["pet_name"].length() <= 16 and not "\n" in state.data["pet_name"],"Pet names cannot break the HUD")
	state.buy("lavender")
	state.equip("lavender")
	state.buy("lens_aqua")
	state.equip("lens_aqua")
	state.data["needs"]["hunger"] = 47.375
	check(Saves.write_game(test_path,state.data),"Saving writes an atomic JSON envelope")
	var loaded = Saves.read_game(test_path)
	check(not loaded["data"].is_empty(),"A written save passes its integrity check")
	check(loaded["data"].get("equipped_skin","") == "lavender","Cosmetics survive a save/load round trip")
	check(is_equal_approx(float(loaded["data"].get("needs",{}).get("hunger",0.0)),47.375),"Fractional needs survive save/load")
	var restored = state.sanitize(loaded["data"])
	check(restored["part_colors"].get("lens","") == "#9ADFE8","Independent cosmetic parts survive save sanitation")
	state.data["coins"] = 777
	check(Saves.write_game(test_path,state.data),"A second save creates a usable previous version")
	var corrupt = FileAccess.open(test_path,FileAccess.WRITE)
	corrupt.store_string("{broken save")
	corrupt.close()
	loaded = Saves.read_game(test_path)
	check(loaded["recovered"] and not loaded["data"].is_empty(),"A corrupt primary is restored from backup")
	check(loaded["data"].get("coins",-1) != 777,"Recovery uses the previous committed version")
	check(Saves.write_game(test_path,state.data),"Recovery can write a fresh valid primary")
	loaded = Saves.read_game(test_path)
	check(not loaded["recovered"] and loaded["data"].get("coins",0) == 777,"Recovered saves return to ordinary loading")
	var partial = state.sanitize({"coins":123,"pet_name":"Ada","hunger":34.0})
	check(partial["coins"] == 123 and partial["pet_name"] == "Ada","Missing optional fields do not reset existing progress")
	check(partial["needs"]["hunger"] == 34.0,"Legacy flat needs migrate independently")
	var malformed = state.sanitize({"coins":-99,"level":900,"needs":{"hunger":999,"battery":"bad"},"owned_items":null,"owned_food":[],"settings":{"music":-8,"language":"unknown"},"achievements":[{},"ok"],"daily_missions":{"day":"bad","claimed":42}})
	check(malformed["coins"] == 0 and malformed["level"] == 50,"Numeric fields clamp safely")
	check(malformed["needs"]["hunger"] == 100.0 and malformed["needs"]["battery"] == 66.0,"Needs reject malformed values")
	check(malformed["settings"]["music"] == 0.0 and malformed["settings"]["language"] == "ru","Settings reject invalid values")
	check(malformed["owned_food"]["basic"] == 1,"Sanitation always retains free food")

	Saves.remove_game(test_path)
	state.queue_free()
	await process_frame
	print("STATE TESTS: %d checks, %d failures" % [checks,failures.size()])
	quit(0 if failures.is_empty() else 1)
