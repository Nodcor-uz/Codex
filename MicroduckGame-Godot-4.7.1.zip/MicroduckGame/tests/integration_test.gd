extends SceneTree
## End-to-end composition test, safe for an existing player profile.
## godot --headless --path . --script res://tests/integration_test.gd -- --test-mode
## Add --screenshots=/absolute/directory when using a real display driver.
## Mini-game clocks are moved to their end boundary; skill rules have separate tests.

var game: Node
var state: Node
var checks: Array[Dictionary] = []
var failed = 0
var captures = ""
var report_path = ""
var old_data: Dictionary
var old_save_path = ""

func _initialize() -> void:
	call_deferred("run")

func check(condition: bool, description: String) -> void:
	checks.append({"ok":condition,"check":description})
	if condition:
		print("PASS: ",description)
	else:
		failed += 1
		push_error("FAIL: " + description)

func settle(seconds: float = 0.2) -> void:
	await create_timer(seconds).timeout
	await process_frame

func capture(name: String) -> void:
	if captures.is_empty() or DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	var img = root.get_texture().get_image()
	check(img.save_png(captures.path_join(name + ".png")) == OK, "Screenshot " + name)

func button_named(node: Node, text: String) -> BaseButton:
	if node is Button and node.text == text:
		return node
	for child in node.get_children():
		var result = button_named(child,text)
		if result != null:
			return result
	return null

func mesh_count(node: Node) -> int:
	var count = 1 if node is MeshInstance3D else 0
	for child in node.get_children():
		count += mesh_count(child)
	return count

func change_room(id: String) -> void:
	game.hud.room_requested.emit(id)
	await settle(0.6)
	check(game.room_id == id and state.data.current_room == id, "HUD navigation to " + id)

func run() -> void:
	if not "--test-mode" in OS.get_cmdline_user_args():
		push_error("Integration tests require -- --test-mode to protect player progress.")
		quit(2)
		return
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--screenshots="):
			captures = argument.trim_prefix("--screenshots=")
		if argument.begins_with("--report="):
			report_path = argument.trim_prefix("--report=")
	if not captures.is_empty():
		DirAccess.make_dir_recursive_absolute(captures)
	state = root.get_node("State")
	old_data = state.data.duplicate(true)
	old_save_path = state.save_path
	state.autosave_enabled = false
	state.set_process(false)
	state.save_path = "user://qa_integration_%d.json" % Time.get_ticks_usec()
	var packed = load("res://scenes/main/Main.tscn")
	if not packed is PackedScene:
		check(false,"Main scene loads")
		finish()
		return
	game = packed.instantiate()
	root.add_child(game)
	current_scene = game
	await settle(0.5)
	check(game.test_mode,"Main uses isolated test mode")
	check(is_instance_valid(game.pet) and mesh_count(game.pet) >= 30,"Pet contains articulated 3D geometry")
	check(game.hud.nav.get_child_count() == 6,"Six primary navigation buttons")
	check(state.data.coins == 500,"New profile starts with 500 coins")
	var pet_identity = game.pet.get_instance_id()
	var initial_needs: Dictionary = state.data.needs.duplicate(true)
	# Unlocking a test fixture is deliberate; real level gates are checked separately.
	state.data.level = 20
	for id in ["living","kitchen","bedroom","bathroom","games","workshop","garden"]:
		await change_room(id)
		check(mesh_count(game.room) > 12,"3D room geometry " + id)
		check(game.pet.get_instance_id() == pet_identity,"Same pet retained in " + id)
		check(state.data.needs == initial_needs,"Room switch preserves needs " + id)
		await capture("room_" + id)
	for id in ["shop","food","wardrobe","decor","toys","minigames","tasks","achievements","settings","collection","about"]:
		game.hud.panel_requested.emit(id)
		await settle()
		check(game.panels.visible and game.panels.content.get_child_count() > 0,"Populated panel " + id)
		if id in ["shop","wardrobe","minigames","settings","collection"]:
			await capture("panel_" + id)
		game.panels.hide_panel()
		check(not game.panels.visible,"Panel closes " + id)
	# A real button invokes the purchase transaction, then inventory equips the item.
	var item: Dictionary = {}
	for candidate in state.catalog:
		if candidate.id == "lavender":
			item = candidate
	check(not item.is_empty(),"Lavender skin catalog entry")
	if not item.is_empty():
		game.panels.show_catalog("skin")
		var balance = int(state.data.coins)
		game.panels.confirm_purchase(item)
		var confirm = button_named(game.panels,root.get_node("L").t("Confirm purchase"))
		check(confirm != null,"Purchase confirmation button exists")
		if confirm:
			confirm.pressed.emit()
			check(state.data.coins == balance-int(item.price),"Purchase button deducts exact cost")
			check("lavender" in state.data.owned_items,"Purchase adds skin to inventory")
			check(state.equip("lavender"),"Owned skin equips")
			check(state.data.equipped_skin == "lavender","Equipped skin recorded")
		game.panels.hide_panel()
	# Feed through the actual selected-food presentation and callback.
	await change_room("kitchen")
	state.data.needs.hunger = 30.0
	state._busy_until = 0
	game.action_lock = 0.0
	var pantry = int(state.data.owned_food.chip)
	game.panels.requested.emit("select_food","chip")
	check(is_instance_valid(game.food),"Selecting food creates a 3D treat")
	game._feed_selected()
	check(state.data.needs.hunger > 30.0,"Feeding restores hunger")
	check(state.data.owned_food.chip == pantry-1,"Feeding consumes exactly one item")
	game._feed_selected()
	check(state.data.owned_food.chip == pantry-1,"Second feeding callback cannot consume twice")
	await settle(2.5)
	# Rest, charge and return must keep the state machine and room presentation aligned.
	await change_room("bedroom")
	state.data.needs.rest = 25.0
	state.data.needs.battery = 25.0
	game.hud.action_requested.emit("sleep")
	game.hud.action_requested.emit("charge")
	check(state.data.is_sleeping and state.data.is_charging,"Sleep and charging can coexist")
	await settle(0.6)
	await capture("care_sleep_charge")
	game.hud.action_requested.emit("wake")
	game.hud.action_requested.emit("stop_charge")
	check(not state.data.is_sleeping and not state.data.is_charging,"Wake and unplug controls work")
	# Bathing must require accumulated movement across multiple parts before soap commits.
	await change_room("bathroom")
	state.data.needs.cleanliness = 25.0
	state._busy_until = 0
	game.action_lock = 0.0
	game.hud.action_requested.emit("wash")
	check(game.washing and state.wash_stage == 0,"Soap control enters interactive scrubbing")
	game._scrub(Vector2(300,500),20.0,"head")
	check(state.wash_stage == 0,"Single short stroke does not finish washing")
	for i in range(20):
		game._scrub(Vector2(300+i,500),45.0,"head" if i%2 == 0 else "body")
	check(state.wash_stage == 1 and not game.washing,"Multi-part scrub reaches soap stage")
	await settle(2.6)
	game.hud.action_requested.emit("rinse")
	check(state.wash_stage == 2,"Rinse control advances stage")
	await settle(2.6)
	game.hud.action_requested.emit("dry")
	check(state.wash_stage == 0 and state.data.needs.cleanliness > 25.0,"Drying completes bath")
	await settle(2.6)
	# Every mini-game is entered twice: cancellation then its timer-completion boundary.
	await change_room("games")
	for id in ["catch","roller","memory","sort","beat","treasure"]:
		state._busy_until = 0
		state.data.needs.battery = 90.0
		var before = int(state.data.coins)
		game.launch_minigame(id)
		await settle()
		check(is_instance_valid(game.arcade),"Mini-game scene launches " + id)
		if not is_instance_valid(game.arcade):
			continue
		game.arcade.start_game()
		await settle(0.3)
		check(is_instance_valid(game.arcade.board) and game.arcade.board.running,"Playable board starts " + id)
		check(state.data.coins == before,"No early reward " + id)
		await capture("game_" + id)
		game.arcade.abort()
		await settle()
		check(not is_instance_valid(game.arcade) and game.hud.visible,"Abort frees arcade and restores HUD " + id)
		check(state.data.coins == before,"Cancellation gives no coins " + id)
		game.launch_minigame(id)
		await settle()
		game.arcade.start_game()
		await settle(0.1)
		var token: String = game.session_token
		# Exercise timer completion without claiming a full-duration manual playthrough.
		game.arcade.board.time_left = 0.001
		await settle(0.3)
		check(not is_instance_valid(game.arcade),"Timer completion frees board " + id)
		check(game.panels.visible and game.panels.current == "results","Result panel shown " + id)
		check(state.data.coins > before,"Completed round rewards once " + id)
		var after = int(state.data.coins)
		var duplicate: Dictionary = state.finish_minigame(token,999,true)
		check(int(duplicate.coins) == 0 and state.data.coins == after,"Duplicate result cannot reward " + id)
		game.panels.hide_panel()
	# Real save file roundtrip, isolated from the player save.
	state.rename_pet("Тест O‘zbek")
	state.autosave_enabled = true
	check(state.save(),"Isolated save writes successfully")
	var expected = state.data.duplicate(true)
	state.data = state.defaults()
	state.load_progress()
	check(state.data.pet_name == expected.pet_name,"Pet name survives save/load")
	check(state.data.equipped_skin == expected.equipped_skin,"Cosmetics survive save/load")
	check(state.data.coins == expected.coins,"Balance survives save/load")
	check(state.data.current_room == expected.current_room,"Room survives save/load")
	check(state.data.minigame_records == expected.minigame_records,"Records survive save/load")
	state.autosave_enabled = false
	# Relayout checks run on real portrait viewports without requiring an Android device.
	if DisplayServer.get_name() != "headless":
		await change_room("living")
		for resolution in [Vector2i(720,1280),Vector2i(1080,1920),Vector2i(1080,2400),Vector2i(1440,3200)]:
			root.size = resolution
			await settle(0.4)
			for nav_button in game.hud.nav.get_children():
				var rect: Rect2 = nav_button.get_global_rect()
				check(rect.size.x > 20 and rect.position.x >= 0 and rect.end.x <= game.ui_root.size.x+1,"Navigation fits %dx%d" % [resolution.x,resolution.y])
			await capture("portrait_%dx%d" % [resolution.x,resolution.y])
	finish()

func finish() -> void:
	if state:
		state.autosave_enabled = false
		for suffix in ["", ".bak", ".tmp"]:
			if FileAccess.file_exists(state.save_path+suffix):
				DirAccess.remove_absolute(state.save_path+suffix)
		state.save_path = old_save_path
		state.data = old_data
	if is_instance_valid(game):
		game.queue_free()
	if not report_path.is_empty():
		var f = FileAccess.open(report_path,FileAccess.WRITE)
		if f:
			f.store_string(JSON.stringify({"engine":Engine.get_version_info().string,"checks":checks,"failed":failed},"\t"))
	print("INTEGRATION: %d checks, %d failures" % [checks.size(),failed])
	var audio_manager = root.get_node_or_null("Audio")
	if audio_manager and audio_manager.has_method("shutdown"):
		audio_manager.shutdown()
	await create_timer(0.15).timeout
	quit(1 if failed > 0 else 0)
