extends SceneTree
## Run: godot --headless --path . --script res://tests/minigame_test.gd
## Use a temporary XDG_DATA_HOME if testing outside the editor.
var checks: int = 0
var failures: int = 0

func _initialize() -> void:
	call_deferred("run")

func check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error("FAIL: " + message)

func make_game(scene_name: String) -> Control:
	var game = load("res://scenes/minigames/" + scene_name + ".tscn").instantiate()
	root.add_child(game)
	game.start_game()
	game.board.set_process(false)
	return game

func run() -> void:
	var game = make_game("CatchChips")
	var board = game.board
	for i in range(5):
		board.catch_kind(0)
	check(board.score == 70 and board.combo == 5 and board.best_combo == 5, "catch: five chips receive exactly one combo bonus")
	board.catch_kind(3)
	check(board.score == 60 and board.combo == 0, "catch: faulty chip penalizes and clears streak")
	board.catch_kind(1)
	check(board.score == 85, "catch: gold chip is worth 25")
	var result = {"calls": 0, "score": 0, "won": false, "aborted": true}
	game.finished.connect(func(points, won, aborted):
		result.calls += 1
		result.score = points
		result.won = won
		result.aborted = aborted)
	board.finish(true)
	board.finish(false)
	game.abort()
	await process_frame
	check(result.calls == 1 and result.score == 85 and not result.aborted, "host: completion is single-use")
	game.queue_free()
	await process_frame

	game = make_game("RollerDuck")
	board = game.board
	check(is_instance_valid(board.world) and is_instance_valid(board.pet), "roller: real 3D world and articulated pet are present")
	board.move_lane(-9)
	check(board.lane == 0, "roller: left lane clamps")
	board.move_lane(9)
	check(board.lane == 2, "roller: right lane clamps")
	board.jump()
	check(board.jump_timer > 0, "roller: jump starts")
	board.jump_height = 1.0
	board.resolve("barrier")
	check(board.lives == 3 and board.score == 10, "roller: jumping clears low barriers")
	board.resolve("block")
	check(board.lives == 2, "roller: tall blocks cannot be jumped")
	board.resolve("block")
	check(board.lives == 2, "roller: collision grace prevents duplicate damage")
	board.invulnerable = 0
	board.resolve("block")
	board.invulnerable = 0
	board.resolve("block")
	check(board.ended and board.lives == 0, "roller: three collisions lose the round")
	game.queue_free()
	await process_frame

	game = make_game("MemoryLights")
	board = game.board
	board.sequence = [0, 1] as Array[int]
	board.phase = "answer"
	check(board.choose(0) and board.score == 0, "memory: partial answer gives no round reward")
	check(board.choose(1) and board.score == 40, "memory: exact sequence completes round")
	board.phase_clock = 0
	board._tick(0.01)
	check(board.round_number == 2 and board.sequence.size() == 3, "memory: next round length grows")
	board.phase = "answer"
	var wrong = (board.sequence[0] + 1) % 4
	check(not board.choose(wrong) and board.phase == "failed", "memory: wrong signal fails")
	board._tick(2.0)
	check(board.ended, "memory: failure finishes after correct light feedback")
	game.queue_free()
	await process_frame

	game = make_game("BatterySort")
	board = game.board
	board.batteries = [{"kind": 2, "slot": 0, "pos": Vector2(95, 240), "life": 0.0}]
	board.press_at(Vector2(95, 240))
	check(board.dragged == 0, "sort: battery is grabbed inside hit area")
	board.release_at(board.bin_rect(2).get_center())
	check(board.score == 15 and board.batteries.is_empty(), "sort: drag to matching bin consumes and scores")
	board.batteries = [{"kind": 1, "slot": 0, "pos": Vector2(95, 240), "life": 0.0}]
	check(not board.assign(0, 0) and board.score == 10, "sort: wrong bin costs five")
	check(not board.assign(0, 0) and board.score == 10, "sort: consumed item cannot be reused")
	game.queue_free()
	await process_frame

	game = make_game("DuckBeat")
	board = game.board
	board.notes = [{"lane": 0, "time": 2.0, "hit": false, "miss": false, "played": true}, {"lane": 1, "time": 3.0, "hit": false, "miss": false, "played": true}]
	check(board.hit_lane(0, 2.0) == "Perfect" and board.score == 30, "beat: exact timing earns Perfect")
	check(board.hit_lane(0, 2.0) == "Miss" and board.score == 28, "beat: the same note cannot score twice")
	check(board.hit_lane(1, 3.18) == "Good" and board.score == 43, "beat: wider timing window earns Good")
	board.notes.append({"lane": 2, "time": 4.0, "hit": false, "miss": false, "played": true})
	board.elapsed = 4.4
	board._tick(0.01)
	check(board.notes[2].miss and board.combo == 0, "beat: unplayed notes become misses")
	game.queue_free()
	await process_frame

	game = make_game("DuckTreasure")
	board = game.board
	board.gear_box = 1
	board.slots = [0, 1, 2] as Array[int]
	board.apply_swap(0, 1)
	board.apply_swap(0, 2)
	check(board.slots == [2, 0, 1], "treasure: swaps preserve physical box identity")
	board.phase = "choose"
	check(board.choose(2) and board.found == 1 and board.score == 70, "treasure: selection follows actual shuffled gear")
	check(not board.choose(2) and board.score == 70, "treasure: repeated choice gives no bonus")
	board.round_number = 5
	board.found = 3
	board.phase_clock = 0
	board._tick(0.01)
	check(board.ended, "treasure: fifth round terminates")
	game.queue_free()
	await process_frame

	game = load("res://scenes/minigames/CatchChips.tscn").instantiate()
	root.add_child(game)
	var abort_result = {"calls": 0, "score": -1, "aborted": false}
	game.finished.connect(func(points, _won, aborted):
		abort_result.calls += 1
		abort_result.score = points
		abort_result.aborted = aborted)
	game.abort()
	game.abort()
	await process_frame
	check(abort_result.calls == 1 and abort_result.score == 0 and abort_result.aborted, "host: cancelling instructions is one-shot and awards zero")
	game.queue_free()
	await process_frame
	print("MINIGAME TESTS: %d checks, %d failures" % [checks, failures])
	quit(1 if failures > 0 else 0)
